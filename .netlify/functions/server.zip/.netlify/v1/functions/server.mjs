
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);

var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// dist/server/assets/_tanstack-start-manifest_v-CJtY7xJJ.js
var tanstack_start_manifest_v_CJtY7xJJ_exports = {};
__export(tanstack_start_manifest_v_CJtY7xJJ_exports, {
  tsrStartManifest: () => tsrStartManifest
});
var tsrStartManifest;
var init_tanstack_start_manifest_v_CJtY7xJJ = __esm({
  "dist/server/assets/_tanstack-start-manifest_v-CJtY7xJJ.js"() {
    "use strict";
    tsrStartManifest = () => ({ routes: { __root__: { filePath: "F:/Work/wagesociety2.0/src/routes/__root.tsx", children: ["/", "/$username", "/admin", "/appeals", "/dashboard", "/directory", "/download", "/faq", "/live", "/login", "/merch", "/merch-studio", "/news", "/onboarding", "/signup", "/api/check-username", "/api/collab", "/api/create-payment-intent", "/api/kick-callback", "/api/kick-login", "/api/knowledge-vault", "/api/marketing-proof", "/api/news", "/api/news-upload", "/api/profile", "/api/profile-photo-upload", "/api/public-directory", "/api/public-profile", "/api/shop", "/api/stripe-webhook", "/api/admin/permissions", "/api/admin/roles", "/api/live/clips", "/api/live/streams", "/api/me/access", "/api/me/profile", "/api/merch-studio/earnings", "/api/merch-studio/submissions", "/api/merch-studio/upload", "/api/tools/$tool", "/api/admin/shop/merch", "/api/admin/shop/plans"], assets: [{ tag: "link", attrs: { rel: "stylesheet", href: "/assets/index-v6Qo_6_v.css", type: "text/css" } }], preloads: ["/assets/index-BjwLQ36g.js"] }, "/": { filePath: "F:/Work/wagesociety2.0/src/routes/index.tsx", children: void 0, assets: [], preloads: ["/assets/index-wUXwyrM0.js", "/assets/user-CVjxUnQh.js", "/assets/store-C06hBOn2.js", "/assets/users-DKgL6iwW.js"] }, "/$username": { filePath: "F:/Work/wagesociety2.0/src/routes/$username.tsx", children: void 0, assets: [], preloads: ["/assets/_username-CaN4Zj68.js", "/assets/loader-circle-HtWieuXl.js", "/assets/user-round-B8Abl98S.js", "/assets/external-link-B7XKwV_j.js"] }, "/admin": { filePath: "F:/Work/wagesociety2.0/src/routes/admin.tsx", children: ["/admin/shop", "/admin/users"], assets: [], preloads: ["/assets/admin-BW-imgyF.js", "/assets/useLocation-B3gljOW3.js", "/assets/arrow-left-8hceZqCS.js", "/assets/users-DKgL6iwW.js", "/assets/store-C06hBOn2.js", "/assets/radio-tower-IuVSHspZ.js"] }, "/appeals": { filePath: "F:/Work/wagesociety2.0/src/routes/appeals.tsx", children: void 0, assets: [], preloads: ["/assets/appeals-BkP03hbU.js"] }, "/dashboard": { filePath: "F:/Work/wagesociety2.0/src/routes/dashboard.tsx", children: ["/dashboard/tools/$tool"], assets: [], preloads: ["/assets/dashboard-CI6aj1qo.js", "/assets/useLocation-B3gljOW3.js", "/assets/authRedirect-eYMB2Yj7.js", "/assets/loader-circle-HtWieuXl.js", "/assets/user-CVjxUnQh.js", "/assets/check-CAM2yZwz.js", "/assets/settings-CcdK_sof.js", "/assets/users-DKgL6iwW.js", "/assets/store-C06hBOn2.js"] }, "/directory": { filePath: "F:/Work/wagesociety2.0/src/routes/directory.tsx", children: void 0, assets: [], preloads: ["/assets/directory-B7tp4LLf.js", "/assets/users-DKgL6iwW.js", "/assets/search-CCPVgZdL.js", "/assets/loader-circle-HtWieuXl.js", "/assets/user-round-B8Abl98S.js"] }, "/download": { filePath: "F:/Work/wagesociety2.0/src/routes/download.tsx", children: void 0, assets: [], preloads: ["/assets/download-B0XbN77W.js"] }, "/faq": { filePath: "F:/Work/wagesociety2.0/src/routes/faq.tsx", children: void 0, assets: [], preloads: ["/assets/faq-CKsNDZyb.js", "/assets/chevron-down--_RoFs-L.js"] }, "/live": { filePath: "F:/Work/wagesociety2.0/src/routes/live.tsx", children: void 0, assets: [], preloads: ["/assets/live-D7IE9HMy.js", "/assets/radio-tower-IuVSHspZ.js", "/assets/external-link-B7XKwV_j.js"] }, "/login": { filePath: "F:/Work/wagesociety2.0/src/routes/login.tsx", children: void 0, assets: [], preloads: ["/assets/login-B4C6eCMV.js", "/assets/AuthPage-CCs5ybcw.js", "/assets/authRedirect-eYMB2Yj7.js", "/assets/arrow-left-8hceZqCS.js"] }, "/merch": { filePath: "F:/Work/wagesociety2.0/src/routes/merch.tsx", children: void 0, assets: [], preloads: ["/assets/merch-CHdFmfaz.js"] }, "/news": { filePath: "F:/Work/wagesociety2.0/src/routes/news.tsx", children: void 0, assets: [], preloads: ["/assets/news-CzMy6L6l.js"] }, "/onboarding": { filePath: "F:/Work/wagesociety2.0/src/routes/onboarding.tsx", children: void 0, assets: [], preloads: ["/assets/onboarding-DsG6G53Y.js", "/assets/loader-circle-HtWieuXl.js", "/assets/user-round-B8Abl98S.js"] }, "/signup": { filePath: "F:/Work/wagesociety2.0/src/routes/signup.tsx", children: void 0, assets: [], preloads: ["/assets/signup-0MWVCVbQ.js", "/assets/AuthPage-CCs5ybcw.js", "/assets/authRedirect-eYMB2Yj7.js", "/assets/arrow-left-8hceZqCS.js"] }, "/admin/shop": { filePath: "F:/Work/wagesociety2.0/src/routes/admin.shop.tsx", children: void 0, assets: [], preloads: ["/assets/admin.shop-CNQ5ayqr.js", "/assets/trash-2-BnMV7-8l.js"] }, "/admin/users": { filePath: "F:/Work/wagesociety2.0/src/routes/admin.users.tsx", children: void 0, assets: [], preloads: ["/assets/admin.users-CarqH2i9.js", "/assets/chevron-down--_RoFs-L.js", "/assets/check-CAM2yZwz.js"] }, "/dashboard/tools/$tool": { filePath: "F:/Work/wagesociety2.0/src/routes/dashboard.tools.$tool.tsx", children: void 0, assets: [], preloads: ["/assets/dashboard.tools._tool-BMY-6MS1.js", "/assets/arrow-left-8hceZqCS.js", "/assets/search-CCPVgZdL.js", "/assets/external-link-B7XKwV_j.js", "/assets/chevron-down--_RoFs-L.js", "/assets/trash-2-BnMV7-8l.js"] } }, clientEntry: "/assets/index-BjwLQ36g.js" });
  }
});

// dist/server/assets/AuthPage-BmnuUX2O.js
import { jsx, jsxs, Fragment } from "react/jsx-runtime";
import { useNavigate, Link } from "@tanstack/react-router";
import { ArrowLeft, BadgeCheck } from "lucide-react";
import { useState, useRef, useEffect } from "react";
function isNativeApp() {
  try {
    return typeof window !== "undefined" && typeof window.Capacitor !== "undefined" && window.Capacitor.isNativePlatform();
  } catch {
    return false;
  }
}
function getPostAuthPath(metadata) {
  return metadata?.onboarding_completed === true ? "/dashboard" : "/onboarding";
}
function AuthPage({ view }) {
  const navigate = useNavigate();
  const [error, setError] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [notice, setNotice] = useState("");
  const [usernameStatus, setUsernameStatus] = useState("idle");
  const [usernameMessage, setUsernameMessage] = useState("");
  const usernameDebounceRef = useRef(null);
  const [busyAction, setBusyAction] = useState(null);
  const isSignup = view === "signup";
  useEffect(() => {
    void (async () => {
      if (view === "login" && isLocalhostClient()) {
        startLocalRootSession();
        void navigate({ to: "/dashboard" });
        return;
      }
      try {
        const supabase = getSupabaseBrowserClient();
        const { data } = await supabase.auth.getSession();
        if (data.session?.user) {
          const userMeta = data.session.user.user_metadata || void 0;
          void navigate({ to: getPostAuthPath(userMeta) });
        }
      } catch {
      }
    })();
  }, [navigate, view]);
  const handleOAuth = async (provider) => {
    try {
      setError("");
      setBusyAction("login");
      const supabase = getSupabaseBrowserClient();
      if (isNativeApp()) {
        const { data, error: authError2 } = await supabase.auth.signInWithOAuth({
          provider,
          options: {
            redirectTo: NATIVE_OAUTH_REDIRECT,
            skipBrowserRedirect: true
          }
        });
        if (authError2) throw authError2;
        if (data?.url) {
          const { Browser } = await import("@capacitor/browser");
          await Browser.open({ url: data.url });
        }
        setBusyAction(null);
        return;
      }
      const { error: authError } = await supabase.auth.signInWithOAuth({
        provider,
        options: {
          redirectTo: getClientAuthRedirectUrl("/dashboard")
        }
      });
      if (authError) throw authError;
    } catch (err) {
      setError(err instanceof Error ? err.message : `Could not sign in with ${provider}.`);
      setBusyAction(null);
    }
  };
  const checkUsername = (value) => {
    if (usernameDebounceRef.current) clearTimeout(usernameDebounceRef.current);
    const trimmed = value.trim();
    if (!trimmed) {
      setUsernameStatus("idle");
      setUsernameMessage("");
      return;
    }
    const valid = /^[a-zA-Z0-9_-]{3,20}$/.test(trimmed);
    if (!valid) {
      setUsernameStatus("invalid");
      setUsernameMessage("3\u201320 characters. Letters, numbers, underscores, hyphens only.");
      return;
    }
    setUsernameStatus("checking");
    setUsernameMessage("");
    usernameDebounceRef.current = setTimeout(() => {
      void (async () => {
        try {
          const response = await fetch(`/api/check-username?username=${encodeURIComponent(trimmed)}`);
          if (!response.ok) {
            setUsernameStatus("idle");
            setUsernameMessage("Could not verify availability right now.");
            return;
          }
          const data = await response.json();
          if (data.available === true) {
            setUsernameStatus("available");
            setUsernameMessage("Username is available!");
          } else {
            setUsernameStatus("taken");
            setUsernameMessage(data.reason || "Username is already taken.");
          }
        } catch {
          setUsernameStatus("idle");
          setUsernameMessage("");
        }
      })();
    }, 500);
  };
  const handleSignup = async () => {
    try {
      setError("");
      setNotice("");
      if (!name.trim()) {
        setError("Please enter a username.");
        return;
      }
      if (usernameStatus === "invalid") {
        setError("Username format is invalid. Use 3\u201320 letters, numbers, underscores, or hyphens.");
        return;
      }
      if (usernameStatus === "taken") {
        setError("That username is already taken. Please choose another.");
        return;
      }
      if (usernameStatus !== "available") {
        const checkResponse = await fetch(`/api/check-username?username=${encodeURIComponent(name.trim())}`);
        if (!checkResponse.ok) {
          setUsernameStatus("idle");
        } else {
          const checkData = await checkResponse.json();
          if (!checkData.available) {
            setError(checkData.reason || "That username is already taken. Please choose another.");
            return;
          }
        }
      }
      setBusyAction("signup");
      const supabase = getSupabaseBrowserClient();
      const { data, error: authError } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            username: name.trim(),
            preferred_username: name.trim(),
            membership_plan: "free",
            onboarding_completed: false
          }
        }
      });
      if (authError) throw authError;
      if (data.session?.user) {
        await navigate({ to: "/onboarding" });
      } else {
        setNotice("Account created. Check your email to confirm, then sign in to continue onboarding.");
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not create account. Please try again.");
    } finally {
      setBusyAction(null);
    }
  };
  return /* @__PURE__ */ jsx("div", { className: "min-h-screen px-4 py-12 text-zinc-100", children: /* @__PURE__ */ jsxs("div", { className: "mx-auto max-w-6xl", children: [
    /* @__PURE__ */ jsxs("div", { className: "mb-8 flex flex-wrap items-center justify-between gap-4", children: [
      /* @__PURE__ */ jsx("h1", { className: "text-3xl font-black text-zinc-50 md:text-4xl", children: isSignup ? "Create Your Membership" : "Member Login" }),
      /* @__PURE__ */ jsxs(
        Link,
        {
          to: "/",
          className: "inline-flex items-center gap-2 rounded-lg border border-zinc-300/35 px-4 py-2 text-sm font-semibold text-zinc-100 transition hover:border-zinc-100",
          children: [
            /* @__PURE__ */ jsx(ArrowLeft, { size: 16 }),
            " Back Home"
          ]
        }
      )
    ] }),
    /* @__PURE__ */ jsxs("div", { className: `grid gap-8 ${isSignup ? "lg:grid-cols-[1.25fr_0.75fr]" : ""}`, children: [
      isSignup ? /* @__PURE__ */ jsxs("section", { className: "rounded-2xl border border-zinc-200/15 bg-zinc-900/60 p-6 md:p-8", children: [
        /* @__PURE__ */ jsx("p", { className: "text-xs font-semibold uppercase tracking-[0.2em] text-zinc-400", children: "How Signup Works" }),
        /* @__PURE__ */ jsx("h2", { className: "mt-3 text-3xl font-bold text-zinc-50", children: "Every new account starts on FREE" }),
        /* @__PURE__ */ jsxs("div", { className: "mt-6 space-y-3 rounded-2xl border border-zinc-200/15 bg-zinc-950/40 p-5 text-sm text-zinc-300", children: [
          /* @__PURE__ */ jsxs("p", { className: "flex items-start gap-2", children: [
            /* @__PURE__ */ jsx(BadgeCheck, { size: 14, className: "mt-0.5 text-orange-200" }),
            " Create your account or connect OAuth."
          ] }),
          /* @__PURE__ */ jsxs("p", { className: "flex items-start gap-2", children: [
            /* @__PURE__ */ jsx(BadgeCheck, { size: 14, className: "mt-0.5 text-orange-200" }),
            " Get instant FREE access by default."
          ] }),
          /* @__PURE__ */ jsxs("p", { className: "flex items-start gap-2", children: [
            /* @__PURE__ */ jsx(BadgeCheck, { size: 14, className: "mt-0.5 text-orange-200" }),
            " Complete onboarding: username + profile setup."
          ] }),
          /* @__PURE__ */ jsxs("p", { className: "flex items-start gap-2", children: [
            /* @__PURE__ */ jsx(BadgeCheck, { size: 14, className: "mt-0.5 text-orange-200" }),
            " Choose to upgrade during onboarding if you want paid access."
          ] })
        ] })
      ] }) : null,
      /* @__PURE__ */ jsxs("section", { className: "rounded-2xl border border-zinc-200/15 bg-zinc-900/60 p-6 md:p-8", children: [
        isSignup ? /* @__PURE__ */ jsxs(Fragment, { children: [
          /* @__PURE__ */ jsx("p", { className: "text-xs font-semibold uppercase tracking-[0.2em] text-zinc-400", children: "New Account" }),
          /* @__PURE__ */ jsx("h2", { className: "mt-3 text-2xl font-bold text-zinc-50", children: "Create your organization profile" })
        ] }) : /* @__PURE__ */ jsxs(Fragment, { children: [
          /* @__PURE__ */ jsx("p", { className: "text-xs font-semibold uppercase tracking-[0.2em] text-zinc-400", children: "Already a member?" }),
          /* @__PURE__ */ jsx("h2", { className: "mt-3 text-2xl font-bold text-zinc-50", children: "Sign in to your dashboard" })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "mt-6 space-y-4", children: [
          isSignup ? /* @__PURE__ */ jsxs("label", { className: "block", children: [
            /* @__PURE__ */ jsx("span", { className: "mb-2 block text-sm font-medium text-zinc-200", children: "Username" }),
            /* @__PURE__ */ jsx(
              "input",
              {
                type: "text",
                value: name,
                onChange: (event) => {
                  setName(event.target.value);
                  checkUsername(event.target.value);
                },
                className: `w-full rounded-lg border bg-zinc-950/60 px-3 py-2 text-zinc-100 outline-none transition ${usernameStatus === "available" ? "border-emerald-400/60 focus:border-emerald-300" : usernameStatus === "taken" || usernameStatus === "invalid" ? "border-rose-400/60 focus:border-rose-300" : "border-zinc-200/20 focus:border-orange-200/70"}`,
                placeholder: "your_username",
                maxLength: 20,
                autoComplete: "username"
              }
            ),
            usernameMessage ? /* @__PURE__ */ jsx("p", { className: `mt-1 text-xs ${usernameStatus === "available" ? "text-emerald-300" : "text-rose-300"}`, children: usernameStatus === "checking" ? "Checking availability..." : usernameMessage }) : usernameStatus === "checking" ? /* @__PURE__ */ jsx("p", { className: "mt-1 text-xs text-zinc-400", children: "Checking availability..." }) : null
          ] }) : null,
          isSignup ? /* @__PURE__ */ jsxs("label", { className: "block", children: [
            /* @__PURE__ */ jsx("span", { className: "mb-2 block text-sm font-medium text-zinc-200", children: "Email Address" }),
            /* @__PURE__ */ jsx(
              "input",
              {
                type: "text",
                value: email,
                onChange: (event) => setEmail(event.target.value),
                className: "w-full rounded-lg border border-zinc-200/20 bg-zinc-950/60 px-3 py-2 text-zinc-100 outline-none transition focus:border-orange-200/70",
                placeholder: "you@email.com"
              }
            )
          ] }) : null,
          isSignup ? /* @__PURE__ */ jsxs("label", { className: "block", children: [
            /* @__PURE__ */ jsx("span", { className: "mb-2 block text-sm font-medium text-zinc-200", children: "Password" }),
            /* @__PURE__ */ jsx(
              "input",
              {
                type: "password",
                value: password,
                onChange: (event) => setPassword(event.target.value),
                className: "w-full rounded-lg border border-zinc-200/20 bg-zinc-950/60 px-3 py-2 text-zinc-100 outline-none transition focus:border-orange-200/70",
                placeholder: "********"
              }
            )
          ] }) : null
        ] }),
        error ? /* @__PURE__ */ jsx("p", { className: "mt-4 rounded-lg border border-rose-400/40 bg-rose-500/10 px-3 py-2 text-sm text-rose-200", children: error }) : null,
        notice ? /* @__PURE__ */ jsx("p", { className: "mt-4 rounded-lg border border-emerald-400/40 bg-emerald-500/10 px-3 py-2 text-sm text-emerald-200", children: notice }) : null,
        /* @__PURE__ */ jsx("div", { className: "mt-6 grid gap-3", children: isSignup ? /* @__PURE__ */ jsx(
          "button",
          {
            type: "button",
            onClick: handleSignup,
            disabled: busyAction !== null || usernameStatus === "taken" || usernameStatus === "invalid" || usernameStatus === "checking",
            className: "rounded-lg bg-orange-300 px-4 py-2.5 font-semibold text-zinc-950 transition hover:bg-orange-200 disabled:cursor-not-allowed disabled:opacity-70",
            children: busyAction === "signup" ? "Creating account..." : usernameStatus === "checking" ? "Checking username..." : "Create Account"
          }
        ) : null }),
        /* @__PURE__ */ jsxs("div", { className: "mt-5", children: [
          /* @__PURE__ */ jsxs("div", { className: "relative flex items-center gap-3", children: [
            /* @__PURE__ */ jsx("div", { className: "h-px flex-1 bg-zinc-200/15" }),
            /* @__PURE__ */ jsx("span", { className: "text-xs text-zinc-500", children: "or continue with" }),
            /* @__PURE__ */ jsx("div", { className: "h-px flex-1 bg-zinc-200/15" })
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "mt-3 grid grid-cols-2 gap-2", children: [
            /* @__PURE__ */ jsxs(
              "button",
              {
                type: "button",
                onClick: () => handleOAuth("google"),
                disabled: busyAction !== null,
                className: "flex items-center justify-center gap-2 rounded-lg border border-zinc-200/20 bg-zinc-950/40 px-3 py-2.5 text-sm font-medium text-zinc-100 transition hover:border-zinc-100/50 disabled:cursor-not-allowed disabled:opacity-60",
                "aria-label": "Sign in with Google",
                children: [
                  /* @__PURE__ */ jsxs("svg", { width: "16", height: "16", viewBox: "0 0 24 24", "aria-hidden": "true", children: [
                    /* @__PURE__ */ jsx("path", { fill: "#4285F4", d: "M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" }),
                    /* @__PURE__ */ jsx("path", { fill: "#34A853", d: "M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" }),
                    /* @__PURE__ */ jsx("path", { fill: "#FBBC05", d: "M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z" }),
                    /* @__PURE__ */ jsx("path", { fill: "#EA4335", d: "M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" })
                  ] }),
                  "Google"
                ]
              }
            ),
            /* @__PURE__ */ jsxs(
              "button",
              {
                type: "button",
                onClick: () => handleOAuth("kick"),
                disabled: busyAction !== null,
                className: "flex items-center justify-center gap-2 rounded-lg border border-zinc-200/20 bg-zinc-950/40 px-3 py-2.5 text-sm font-medium text-zinc-100 transition hover:border-zinc-100/50 disabled:cursor-not-allowed disabled:opacity-60",
                "aria-label": "Sign in with Kick",
                children: [
                  /* @__PURE__ */ jsx("svg", { width: "16", height: "16", viewBox: "0 0 24 24", fill: "#53FC18", "aria-hidden": "true", children: /* @__PURE__ */ jsx("path", { d: "M2 2h5v8.5l5-8.5h6l-6 10 6 10h-6l-5-8.5V22H2z" }) }),
                  "Kick"
                ]
              }
            )
          ] })
        ] }),
        isSignup ? /* @__PURE__ */ jsxs("p", { className: "mt-4 text-xs text-zinc-400", children: [
          "Already have an account?",
          " ",
          /* @__PURE__ */ jsx(
            "button",
            {
              type: "button",
              onClick: () => void navigate({ to: "/login" }),
              className: "font-semibold text-orange-200 underline underline-offset-4 transition hover:text-orange-100",
              children: "Sign in instead"
            }
          )
        ] }) : null
      ] })
    ] })
  ] }) });
}
var NATIVE_OAUTH_REDIRECT;
var init_AuthPage_BmnuUX2O = __esm({
  "dist/server/assets/AuthPage-BmnuUX2O.js"() {
    "use strict";
    init_router_BDBFyAOM();
    NATIVE_OAUTH_REDIRECT = "com.wagesociety.android://login-callback";
  }
});

// dist/server/assets/signup-VQo6mkN6.js
var signup_VQo6mkN6_exports = {};
__export(signup_VQo6mkN6_exports, {
  component: () => SignupPage
});
import { jsx as jsx2 } from "react/jsx-runtime";
import "@tanstack/react-router";
import "lucide-react";
import "react";
import "@supabase/supabase-js";
import "stripe";
import "zod";
function SignupPage() {
  return /* @__PURE__ */ jsx2(AuthPage, { view: "signup" });
}
var init_signup_VQo6mkN6 = __esm({
  "dist/server/assets/signup-VQo6mkN6.js"() {
    "use strict";
    init_AuthPage_BmnuUX2O();
    init_router_BDBFyAOM();
  }
});

// dist/server/assets/onboarding-C-VsswxE.js
var onboarding_C_VsswxE_exports = {};
__export(onboarding_C_VsswxE_exports, {
  component: () => OnboardingPage
});
import { jsx as jsx3, jsxs as jsxs2 } from "react/jsx-runtime";
import { useNavigate as useNavigate2 } from "@tanstack/react-router";
import { Loader2, UserRound, Sparkles } from "lucide-react";
import { useState as useState2, useRef as useRef2, useEffect as useEffect2 } from "react";
import "@supabase/supabase-js";
import "stripe";
import "zod";
function OnboardingPage() {
  const navigate = useNavigate2();
  const [loading, setLoading] = useState2(true);
  const [saving, setSaving] = useState2(false);
  const [error, setError] = useState2("");
  const [email, setEmail] = useState2("");
  const [displayName, setDisplayName] = useState2("");
  const [avatarUrl, setAvatarUrl] = useState2("");
  const [avatarUploading, setAvatarUploading] = useState2(false);
  const [bio, setBio] = useState2("");
  const [skillsInput, setSkillsInput] = useState2("");
  const [usernameStatus, setUsernameStatus] = useState2("idle");
  const [usernameMessage, setUsernameMessage] = useState2("");
  const [upgradingPlan, setUpgradingPlan] = useState2(null);
  const [plans, setPlans] = useState2([]);
  const usernameDebounceRef = useRef2(null);
  useEffect2(() => {
    void (async () => {
      try {
        const supabase = getSupabaseBrowserClient();
        const {
          data: {
            user
          }
        } = await supabase.auth.getUser();
        if (!user?.email) {
          void navigate({
            to: "/login"
          });
          return;
        }
        const meta = user.user_metadata || {};
        if (meta.onboarding_completed === true) {
          void navigate({
            to: "/dashboard"
          });
          return;
        }
        if (!meta.membership_plan) {
          await supabase.auth.updateUser({
            data: {
              ...meta,
              membership_plan: "free",
              onboarding_completed: false
            }
          });
        }
        setEmail(user.email);
        const seedName = String(meta.username || "").trim() || String(meta.preferred_username || "").trim() || user.email.split("@")[0] || "";
        setDisplayName(seedName);
        const [profileResponse, plansResponse] = await Promise.all([authedFetch("/api/me/profile"), fetch("/api/shop")]);
        if (profileResponse.ok) {
          const profileData = await profileResponse.json();
          const profile = profileData.profile;
          if (profile) {
            setDisplayName(profile.display_name || seedName);
            setAvatarUrl(profile.avatar_url || "");
            setBio(profile.bio || "");
            setSkillsInput((profile.skills || []).join(", "));
          }
        }
        if (plansResponse.ok) {
          const plansData = await plansResponse.json();
          setPlans((plansData.membershipPlans || []).filter((plan) => plan.slug !== "free"));
        }
      } catch {
        setError("Could not load onboarding. Please refresh and try again.");
      } finally {
        setLoading(false);
      }
    })();
  }, [navigate]);
  const checkUsername = (value) => {
    if (usernameDebounceRef.current) clearTimeout(usernameDebounceRef.current);
    const trimmed = value.trim();
    if (!trimmed) {
      setUsernameStatus("idle");
      setUsernameMessage("");
      return;
    }
    if (!USERNAME_REGEX.test(trimmed)) {
      setUsernameStatus("invalid");
      setUsernameMessage("3\u201320 characters. Letters, numbers, underscores, hyphens only.");
      return;
    }
    setUsernameStatus("checking");
    setUsernameMessage("");
    usernameDebounceRef.current = setTimeout(() => {
      void (async () => {
        try {
          const response = await fetch(`/api/check-username?username=${encodeURIComponent(trimmed)}&currentEmail=${encodeURIComponent(email)}`);
          if (!response.ok) {
            setUsernameStatus("idle");
            setUsernameMessage("Could not verify availability right now.");
            return;
          }
          const data = await response.json();
          if (data.available === true) {
            setUsernameStatus("available");
            setUsernameMessage("Username is available!");
          } else {
            setUsernameStatus("taken");
            setUsernameMessage(data.reason || "Username is already taken.");
          }
        } catch {
          setUsernameStatus("idle");
          setUsernameMessage("");
        }
      })();
    }, 400);
  };
  const uploadAvatar = async (file) => {
    const maxSize = 8 * 1024 * 1024;
    const allowedTypes = /* @__PURE__ */ new Set(["image/jpeg", "image/png", "image/webp", "image/gif"]);
    if (file.size > maxSize) {
      setError("Image is too large. Maximum size is 8 MB.");
      return;
    }
    if (file.type && !allowedTypes.has(file.type)) {
      setError("Unsupported image type. Use JPG, PNG, WEBP, or GIF.");
      return;
    }
    setAvatarUploading(true);
    setError("");
    try {
      const formData = new FormData();
      formData.append("file", file);
      const uploadResponse = await authedFetch("/api/profile-photo-upload", {
        method: "POST",
        body: formData
      });
      const uploadData = await uploadResponse.json();
      if (!uploadResponse.ok || !uploadData.url) {
        setError(uploadData.error || "Could not upload profile photo.");
        return;
      }
      setAvatarUrl(uploadData.url);
    } catch {
      setError("Could not upload profile photo.");
    } finally {
      setAvatarUploading(false);
    }
  };
  const ensureUsernameAvailable = async () => {
    const trimmed = displayName.trim();
    if (!trimmed) return false;
    if (!USERNAME_REGEX.test(trimmed)) return false;
    const response = await fetch(`/api/check-username?username=${encodeURIComponent(trimmed)}&currentEmail=${encodeURIComponent(email)}`);
    if (!response.ok) {
      return true;
    }
    const data = await response.json();
    if (!data.available) {
      setError(data.reason || "That username is already taken. Please choose another.");
      return false;
    }
    return true;
  };
  const finishOnboarding = async () => {
    setSaving(true);
    setError("");
    try {
      const trimmedName = displayName.trim();
      if (!trimmedName) {
        setError("Username is required.");
        return;
      }
      if (!USERNAME_REGEX.test(trimmedName)) {
        setError("Username must be 3\u201320 characters with letters, numbers, underscores, or hyphens.");
        return;
      }
      if (!await ensureUsernameAvailable()) {
        return;
      }
      const profileResponse = await authedFetch("/api/me/profile", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          displayName: trimmedName,
          avatarUrl: avatarUrl.trim() || "",
          bio: bio.trim() || void 0,
          skills: skillsInput.split(",").map((item) => item.trim()).filter(Boolean)
        })
      });
      const profileData = await profileResponse.json();
      if (!profileResponse.ok) {
        setError(profileData.error || "Could not save profile. Please try again.");
        return;
      }
      const supabase = getSupabaseBrowserClient();
      const {
        data: {
          user
        }
      } = await supabase.auth.getUser();
      if (user) {
        const meta = user.user_metadata || {};
        const {
          error: updateError
        } = await supabase.auth.updateUser({
          data: {
            ...meta,
            username: trimmedName,
            preferred_username: trimmedName,
            membership_plan: String(meta.membership_plan || "free"),
            onboarding_completed: true
          }
        });
        if (updateError) {
          setError(updateError.message);
          return;
        }
      }
      await navigate({
        to: "/dashboard"
      });
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not complete onboarding.");
    } finally {
      setSaving(false);
    }
  };
  const upgradeNow = async (plan) => {
    try {
      setUpgradingPlan(plan.slug);
      setError("");
      const response = await authedFetch("/api/create-payment-intent", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          planSlug: plan.slug,
          email,
          name: displayName.trim() || void 0
        })
      });
      const data = await response.json();
      if (!response.ok || data.error) {
        setError(data.error || "Could not start upgrade checkout.");
        return;
      }
      if (data.checkoutUrl) {
        window.location.href = data.checkoutUrl;
        return;
      }
      if (data.successUrl) {
        window.location.href = data.successUrl;
        return;
      }
      if (data.updated || data.free) {
        await navigate({
          to: "/dashboard"
        });
      }
    } catch {
      setError("Could not start upgrade checkout.");
    } finally {
      setUpgradingPlan(null);
    }
  };
  if (loading) {
    return /* @__PURE__ */ jsx3("main", { className: "min-h-screen px-4 py-14 text-zinc-100", children: /* @__PURE__ */ jsx3("div", { className: "mx-auto max-w-4xl rounded-2xl border border-zinc-200/15 bg-zinc-900/60 p-8", children: /* @__PURE__ */ jsxs2("p", { className: "inline-flex items-center gap-2 text-sm text-zinc-300", children: [
      /* @__PURE__ */ jsx3(Loader2, { size: 15, className: "animate-spin" }),
      " Preparing onboarding..."
    ] }) }) });
  }
  return /* @__PURE__ */ jsx3("main", { className: "min-h-screen px-4 py-10 text-zinc-100", children: /* @__PURE__ */ jsxs2("div", { className: "mx-auto max-w-5xl space-y-6", children: [
    /* @__PURE__ */ jsxs2("section", { className: "rounded-3xl border border-zinc-200/15 bg-zinc-900/60 p-6 md:p-8", children: [
      /* @__PURE__ */ jsx3("p", { className: "text-xs font-semibold uppercase tracking-[0.2em] text-zinc-500", children: "Welcome to W.A.G.E." }),
      /* @__PURE__ */ jsx3("h1", { className: "mt-2 text-3xl font-black text-zinc-50", children: "Set up your account" }),
      /* @__PURE__ */ jsx3("p", { className: "mt-2 text-sm text-zinc-300", children: "Your account starts on the FREE plan. Finish username and profile setup now, then optionally upgrade." })
    ] }),
    /* @__PURE__ */ jsxs2("section", { className: "rounded-2xl border border-zinc-200/15 bg-zinc-900/60 p-6", children: [
      /* @__PURE__ */ jsx3("h2", { className: "text-xl font-bold text-zinc-50", children: "1. Choose your username + profile" }),
      /* @__PURE__ */ jsxs2("div", { className: "mt-4 grid gap-4 sm:grid-cols-2", children: [
        /* @__PURE__ */ jsxs2("div", { children: [
          /* @__PURE__ */ jsx3("label", { className: "mb-1.5 block text-xs font-medium text-zinc-400", children: "Username" }),
          /* @__PURE__ */ jsx3("input", { type: "text", value: displayName, onChange: (event) => {
            setDisplayName(event.target.value);
            checkUsername(event.target.value);
          }, maxLength: 20, autoComplete: "username", className: `w-full rounded-lg border bg-zinc-950/60 px-3 py-2 text-sm text-zinc-100 outline-none transition ${usernameStatus === "available" ? "border-emerald-400/60 focus:border-emerald-300" : usernameStatus === "taken" || usernameStatus === "invalid" ? "border-rose-400/60 focus:border-rose-300" : "border-zinc-200/20 focus:border-orange-200/70"}`, placeholder: "your_username" }),
          usernameStatus === "checking" ? /* @__PURE__ */ jsx3("p", { className: "mt-1 text-xs text-zinc-400", children: "Checking availability..." }) : usernameMessage ? /* @__PURE__ */ jsx3("p", { className: `mt-1 text-xs ${usernameStatus === "available" ? "text-emerald-300" : "text-rose-300"}`, children: usernameMessage }) : /* @__PURE__ */ jsx3("p", { className: "mt-1 text-xs text-zinc-500", children: "3\u201320 characters. Letters, numbers, underscores, hyphens." })
        ] }),
        /* @__PURE__ */ jsxs2("div", { children: [
          /* @__PURE__ */ jsx3("label", { className: "mb-1.5 block text-xs font-medium text-zinc-400", children: "Profile Photo (optional)" }),
          /* @__PURE__ */ jsxs2("div", { className: "flex flex-wrap items-center gap-3 rounded-lg border border-zinc-200/20 bg-zinc-950/40 p-3", children: [
            avatarUrl ? /* @__PURE__ */ jsx3("img", { src: avatarUrl, alt: "Avatar", className: "h-14 w-14 flex-shrink-0 rounded-full border border-zinc-200/20 object-cover" }) : /* @__PURE__ */ jsx3("div", { className: "flex h-14 w-14 flex-shrink-0 items-center justify-center rounded-full border border-zinc-200/20 bg-zinc-800 text-zinc-400", children: /* @__PURE__ */ jsx3(UserRound, { size: 18 }) }),
            /* @__PURE__ */ jsxs2("div", { className: "flex-1", children: [
              /* @__PURE__ */ jsx3("input", { type: "file", accept: "image/jpeg,image/png,image/webp,image/gif", disabled: avatarUploading, onChange: (event) => {
                const file = event.target.files?.[0];
                if (file) void uploadAvatar(file);
                event.currentTarget.value = "";
              }, className: "block w-full text-sm text-zinc-300 file:mr-3 file:rounded-md file:border-0 file:bg-orange-300 file:px-3 file:py-1.5 file:text-sm file:font-semibold file:text-zinc-950 hover:file:bg-orange-200 disabled:opacity-60" }),
              /* @__PURE__ */ jsx3("p", { className: "mt-1 text-xs text-zinc-500", children: "Upload JPG, PNG, WEBP, or GIF (max 8 MB)." }),
              avatarUploading ? /* @__PURE__ */ jsx3("p", { className: "mt-1 text-xs text-zinc-400", children: "Uploading photo..." }) : null
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxs2("div", { className: "sm:col-span-2", children: [
          /* @__PURE__ */ jsx3("label", { className: "mb-1.5 block text-xs font-medium text-zinc-400", children: "Bio (optional)" }),
          /* @__PURE__ */ jsx3("textarea", { value: bio, onChange: (event) => setBio(event.target.value), rows: 3, maxLength: 500, className: "w-full resize-none rounded-lg border border-zinc-200/20 bg-zinc-950/60 px-3 py-2 text-sm text-zinc-100 outline-none transition focus:border-orange-200/70", placeholder: "Tell members what you create and what you're building." })
        ] }),
        /* @__PURE__ */ jsxs2("div", { className: "sm:col-span-2", children: [
          /* @__PURE__ */ jsx3("label", { className: "mb-1.5 block text-xs font-medium text-zinc-400", children: "Skills (optional)" }),
          /* @__PURE__ */ jsx3("input", { type: "text", value: skillsInput, onChange: (event) => setSkillsInput(event.target.value), className: "w-full rounded-lg border border-zinc-200/20 bg-zinc-950/60 px-3 py-2 text-sm text-zinc-100 outline-none transition focus:border-orange-200/70", placeholder: "Video editing, Marketing, Live production" })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxs2("section", { className: "rounded-2xl border border-zinc-200/15 bg-zinc-900/60 p-6", children: [
      /* @__PURE__ */ jsxs2("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsx3(Sparkles, { size: 16, className: "text-orange-200" }),
        /* @__PURE__ */ jsx3("h2", { className: "text-xl font-bold text-zinc-50", children: "2. Upgrade now (optional)" })
      ] }),
      /* @__PURE__ */ jsx3("p", { className: "mt-2 text-sm text-zinc-300", children: "You're currently on FREE. Upgrade now or finish onboarding and upgrade later from your dashboard." }),
      plans.length > 0 ? /* @__PURE__ */ jsx3("div", { className: "mt-4 grid gap-3 md:grid-cols-2", children: plans.map((plan) => /* @__PURE__ */ jsxs2("article", { className: "rounded-xl border border-zinc-200/15 bg-zinc-950/40 p-4", children: [
        /* @__PURE__ */ jsxs2("div", { className: "flex items-center justify-between gap-2", children: [
          /* @__PURE__ */ jsx3("h3", { className: "text-base font-semibold text-zinc-100", children: plan.name }),
          /* @__PURE__ */ jsx3("p", { className: "text-sm font-bold text-orange-200", children: plan.display_price })
        ] }),
        /* @__PURE__ */ jsx3("p", { className: "mt-2 text-xs text-zinc-400", children: plan.description }),
        /* @__PURE__ */ jsx3("button", { type: "button", onClick: () => {
          void upgradeNow(plan);
        }, disabled: upgradingPlan !== null, className: "mt-3 rounded-lg border border-zinc-100/25 px-3 py-1.5 text-xs font-semibold text-zinc-100 transition hover:border-orange-200/70 disabled:opacity-60", children: upgradingPlan === plan.slug ? "Starting..." : `Upgrade to ${plan.name}` })
      ] }, plan.id)) }) : /* @__PURE__ */ jsx3("p", { className: "mt-3 text-sm text-zinc-500", children: "Upgrade plans are unavailable right now. You can continue with FREE and upgrade later." })
    ] }),
    error ? /* @__PURE__ */ jsx3("p", { className: "rounded-xl border border-rose-400/40 bg-rose-500/10 px-4 py-3 text-sm text-rose-200", children: error }) : null,
    /* @__PURE__ */ jsxs2("div", { className: "flex flex-wrap gap-3", children: [
      /* @__PURE__ */ jsx3("button", { type: "button", onClick: () => {
        void finishOnboarding();
      }, disabled: saving, className: "rounded-lg bg-orange-300 px-5 py-2.5 text-sm font-semibold text-zinc-950 transition hover:bg-orange-200 disabled:opacity-70", children: saving ? "Saving..." : "Finish Onboarding" }),
      /* @__PURE__ */ jsx3("button", { type: "button", onClick: () => {
        void finishOnboarding();
      }, className: "rounded-lg border border-zinc-100/25 px-5 py-2.5 text-sm font-semibold text-zinc-100 transition hover:border-orange-200/70", children: "Continue with FREE for now" })
    ] })
  ] }) });
}
var USERNAME_REGEX;
var init_onboarding_C_VsswxE = __esm({
  "dist/server/assets/onboarding-C-VsswxE.js"() {
    "use strict";
    init_router_BDBFyAOM();
    USERNAME_REGEX = /^[a-zA-Z0-9_-]{3,20}$/;
  }
});

// dist/server/assets/news-LsgI8TbW.js
var news_LsgI8TbW_exports = {};
__export(news_LsgI8TbW_exports, {
  component: () => NewsSection
});
import { jsxs as jsxs3, jsx as jsx4 } from "react/jsx-runtime";
import { useState as useState3, useRef as useRef3, useEffect as useEffect3 } from "react";
import "@tanstack/react-router";
import "@supabase/supabase-js";
import "lucide-react";
import "stripe";
import "zod";
function NewsPostForm({ onPost }) {
  const [title, setTitle] = useState3("");
  const [body, setBody] = useState3("");
  const [imageUrl, setImageUrl] = useState3("");
  const [videoUrl, setVideoUrl] = useState3("");
  const [embedLinks, setEmbedLinks] = useState3("");
  const [imageFiles, setImageFiles] = useState3([]);
  const [videoFiles, setVideoFiles] = useState3([]);
  const imageInputRef = useRef3(null);
  const videoInputRef = useRef3(null);
  const [loading, setLoading] = useState3(false);
  const [error, setError] = useState3(null);
  const uploadFile = async (file) => {
    const formData = new FormData();
    formData.append("file", file);
    const res = await authedFetch("/api/news-upload", { method: "POST", body: formData });
    if (!res.ok) {
      const data2 = await res.json();
      throw new Error(data2.error || "Upload failed");
    }
    const data = await res.json();
    return data.url;
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    const finalImageUrls = imageUrl.split(",").map((item) => item.trim()).filter(Boolean);
    const finalVideoUrls = videoUrl.split(",").map((item) => item.trim()).filter(Boolean);
    const finalEmbedLinks = embedLinks.split("\n").map((item) => item.trim()).filter(Boolean);
    try {
      for (const file of imageFiles) {
        const uploadedUrl = await uploadFile(file);
        finalImageUrls.push(uploadedUrl);
      }
      for (const file of videoFiles) {
        const uploadedUrl = await uploadFile(file);
        finalVideoUrls.push(uploadedUrl);
      }
    } catch (err) {
      const message = err instanceof Error ? err.message : "Upload failed.";
      setError(message);
      setLoading(false);
      return;
    }
    const res = await authedFetch("/api/news", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        title,
        body,
        image_urls: finalImageUrls,
        video_urls: finalVideoUrls,
        embed_links: finalEmbedLinks
      })
    });
    if (!res.ok) {
      const data = await res.json();
      setError(data.error || "Failed to publish blog post");
    } else {
      setTitle("");
      setBody("");
      setImageUrl("");
      setVideoUrl("");
      setEmbedLinks("");
      setImageFiles([]);
      setVideoFiles([]);
      if (imageInputRef.current) imageInputRef.current.value = "";
      if (videoInputRef.current) videoInputRef.current.value = "";
      if (onPost) onPost();
    }
    setLoading(false);
  };
  return /* @__PURE__ */ jsxs3("form", { onSubmit: handleSubmit, className: "bg-zinc-800 p-6 rounded-lg mb-8", children: [
    /* @__PURE__ */ jsx4("h2", { className: "text-lg font-semibold mb-4", children: "Write a Blog Post" }),
    error && /* @__PURE__ */ jsx4("div", { className: "text-red-400 mb-2", children: error }),
    /* @__PURE__ */ jsx4(
      "input",
      {
        className: "block w-full mb-2 p-2 rounded bg-zinc-900 text-zinc-100",
        placeholder: "Title",
        value: title,
        onChange: (e) => setTitle(e.target.value),
        required: true
      }
    ),
    /* @__PURE__ */ jsx4(
      "textarea",
      {
        className: "block w-full mb-2 p-2 rounded bg-zinc-900 text-zinc-100",
        placeholder: "Body",
        value: body,
        onChange: (e) => setBody(e.target.value),
        rows: 4,
        required: true
      }
    ),
    /* @__PURE__ */ jsxs3("div", { className: "mb-2", children: [
      /* @__PURE__ */ jsx4("label", { className: "block text-zinc-400 mb-1", children: "Photo files (optional):" }),
      /* @__PURE__ */ jsx4(
        "input",
        {
          type: "file",
          accept: "image/*",
          multiple: true,
          ref: imageInputRef,
          onChange: (e) => {
            const files = Array.from(e.target.files || []);
            setImageFiles(files);
          },
          className: "block w-full mb-1 p-2 rounded bg-zinc-900 text-zinc-100"
        }
      ),
      imageFiles.length > 0 ? /* @__PURE__ */ jsxs3("p", { className: "mb-2 text-xs text-zinc-400", children: [
        imageFiles.length,
        " image file(s) selected"
      ] }) : null,
      /* @__PURE__ */ jsx4(
        "input",
        {
          className: "block w-full p-2 rounded bg-zinc-900 text-zinc-100",
          placeholder: "Additional image URLs (comma-separated)",
          value: imageUrl,
          onChange: (e) => {
            setImageUrl(e.target.value);
          },
          type: "text"
        }
      )
    ] }),
    /* @__PURE__ */ jsxs3("div", { className: "mb-2", children: [
      /* @__PURE__ */ jsx4("label", { className: "block text-zinc-400 mb-1", children: "Video files (optional):" }),
      /* @__PURE__ */ jsx4(
        "input",
        {
          type: "file",
          accept: "video/*",
          multiple: true,
          ref: videoInputRef,
          onChange: (e) => {
            const files = Array.from(e.target.files || []);
            setVideoFiles(files);
          },
          className: "block w-full mb-1 p-2 rounded bg-zinc-900 text-zinc-100"
        }
      ),
      videoFiles.length > 0 ? /* @__PURE__ */ jsxs3("p", { className: "mb-2 text-xs text-zinc-400", children: [
        videoFiles.length,
        " video file(s) selected"
      ] }) : null,
      /* @__PURE__ */ jsx4(
        "input",
        {
          className: "block w-full p-2 rounded bg-zinc-900 text-zinc-100",
          placeholder: "Additional video URLs (comma-separated)",
          value: videoUrl,
          onChange: (e) => {
            setVideoUrl(e.target.value);
          },
          type: "text"
        }
      )
    ] }),
    /* @__PURE__ */ jsxs3("div", { className: "mb-4", children: [
      /* @__PURE__ */ jsx4("label", { className: "block text-zinc-400 mb-1", children: "Links to embed (one URL per line)" }),
      /* @__PURE__ */ jsx4(
        "textarea",
        {
          className: "block w-full p-2 rounded bg-zinc-900 text-zinc-100",
          rows: 3,
          placeholder: "https://youtube.com/...\\nhttps://x.com/...",
          value: embedLinks,
          onChange: (e) => setEmbedLinks(e.target.value)
        }
      )
    ] }),
    /* @__PURE__ */ jsx4(
      "button",
      {
        type: "submit",
        className: "bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded disabled:opacity-50",
        disabled: loading,
        children: loading ? "Publishing..." : "Publish Post"
      }
    )
  ] });
}
function isEmbeddableVideo(url) {
  try {
    const parsed = new URL(url);
    const host = parsed.hostname.toLowerCase();
    if (host.includes("youtube.com") || host === "youtu.be") return true;
    if (host.includes("vimeo.com")) return true;
    return false;
  } catch {
    return false;
  }
}
function toEmbedUrl(url) {
  try {
    const parsed = new URL(url);
    const host = parsed.hostname.toLowerCase();
    if (host.includes("youtube.com")) {
      const id = parsed.searchParams.get("v");
      if (id) return `https://www.youtube.com/embed/${id}`;
    }
    if (host === "youtu.be") {
      const id = parsed.pathname.split("/").filter(Boolean)[0];
      if (id) return `https://www.youtube.com/embed/${id}`;
    }
    if (host.includes("vimeo.com")) {
      const id = parsed.pathname.split("/").filter(Boolean)[0];
      if (id) return `https://player.vimeo.com/video/${id}`;
    }
    return null;
  } catch {
    return null;
  }
}
function NewsSection() {
  const [posts, setPosts] = useState3([]);
  const [loading, setLoading] = useState3(true);
  const [canPost, setCanPost] = useState3(false);
  const fetchPosts = async () => {
    setLoading(true);
    const response = await fetch("/api/news");
    const data = await response.json();
    if (response.ok && Array.isArray(data)) {
      setPosts(data);
    }
    setLoading(false);
  };
  useEffect3(() => {
    void fetchPosts();
  }, []);
  useEffect3(() => {
    void (async () => {
      try {
        const supabase = getSupabaseBrowserClient();
        const {
          data
        } = await supabase.auth.getSession();
        if (!data.session) {
          setCanPost(false);
          return;
        }
        const response = await authedFetch("/api/me/access");
        if (!response.ok) {
          setCanPost(false);
          return;
        }
        const access = await response.json();
        const allowedRoles = /* @__PURE__ */ new Set(["superadmin", "admin", "manager", "staff", "helper", "user"]);
        setCanPost(allowedRoles.has(access.role) && access.role !== "banned" && access.permissions.includes("view_creator_tools"));
      } catch {
        setCanPost(false);
      }
    })();
  }, []);
  return /* @__PURE__ */ jsxs3("div", { className: "max-w-2xl mx-auto py-8", children: [
    /* @__PURE__ */ jsx4("h1", { className: "text-3xl font-bold mb-6", children: "Blog" }),
    canPost && /* @__PURE__ */ jsx4(NewsPostForm, { onPost: () => void fetchPosts() }),
    loading ? /* @__PURE__ */ jsx4("div", { children: "Loading..." }) : posts.length === 0 ? /* @__PURE__ */ jsx4("div", { children: "No blog posts yet." }) : /* @__PURE__ */ jsx4("ul", { className: "space-y-8", children: posts.map((post) => /* @__PURE__ */ jsxs3("li", { className: "bg-zinc-900 rounded-lg p-6 shadow", children: [
      /* @__PURE__ */ jsx4("h2", { className: "text-xl font-semibold mb-2", children: post.title }),
      /* @__PURE__ */ jsxs3("div", { className: "text-zinc-400 text-sm mb-2", children: [
        "By ",
        post.author,
        " on ",
        new Date(post.created_at).toLocaleString()
      ] }),
      (post.image_urls || []).map((url) => /* @__PURE__ */ jsx4("img", { src: url, alt: "Blog", className: "mb-4 rounded max-h-64 object-contain" }, url)),
      (post.video_urls || []).map((url) => /* @__PURE__ */ jsx4("video", { src: url, controls: true, className: "mb-4 rounded max-h-96 w-full" }, url)),
      (post.embed_links || []).length > 0 ? /* @__PURE__ */ jsxs3("div", { className: "mb-4 space-y-2 rounded-md border border-zinc-700 bg-zinc-950/60 p-3", children: [
        /* @__PURE__ */ jsx4("p", { className: "text-xs uppercase tracking-wide text-zinc-400", children: "Attached links" }),
        /* @__PURE__ */ jsx4("ul", { className: "space-y-2 text-sm", children: (post.embed_links || []).map((link) => /* @__PURE__ */ jsxs3("li", { children: [
          /* @__PURE__ */ jsx4("a", { href: link, target: "_blank", rel: "noreferrer", className: "text-blue-300 hover:text-blue-200 underline break-all", children: link }),
          isEmbeddableVideo(link) ? /* @__PURE__ */ jsx4("iframe", { src: toEmbedUrl(link) || link, className: "mt-2 h-52 w-full rounded border border-zinc-700", title: `Embedded media for ${post.title}`, loading: "lazy", allow: "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture", allowFullScreen: true }) : null
        ] }, link)) })
      ] }) : null,
      /* @__PURE__ */ jsx4("div", { className: "whitespace-pre-line text-zinc-200", children: post.body })
    ] }, post.id)) })
  ] });
}
var init_news_LsgI8TbW = __esm({
  "dist/server/assets/news-LsgI8TbW.js"() {
    "use strict";
    init_router_BDBFyAOM();
  }
});

// dist/server/assets/merch-CrgHgdMh.js
var merch_CrgHgdMh_exports = {};
__export(merch_CrgHgdMh_exports, {
  component: () => MerchPage
});
import { jsx as jsx5, jsxs as jsxs4 } from "react/jsx-runtime";
import { Link as Link2 } from "@tanstack/react-router";
import { useState as useState4, useEffect as useEffect4 } from "react";
function MerchPage() {
  const [items, setItems] = useState4([]);
  const [loading, setLoading] = useState4(true);
  useEffect4(() => {
    void (async () => {
      try {
        const response = await fetch("/api/shop");
        const data = await response.json();
        if (!response.ok) {
          setItems([]);
          return;
        }
        setItems(data.merchItems || []);
      } finally {
        setLoading(false);
      }
    })();
  }, []);
  return /* @__PURE__ */ jsx5("div", { className: "min-h-screen px-4 py-12 text-zinc-100", children: /* @__PURE__ */ jsxs4("div", { className: "mx-auto max-w-6xl space-y-6", children: [
    /* @__PURE__ */ jsx5("header", { className: "rounded-2xl border border-zinc-200/15 bg-zinc-900/60 p-6 md:p-8", children: /* @__PURE__ */ jsxs4("div", { className: "flex flex-wrap items-center justify-between gap-4", children: [
      /* @__PURE__ */ jsxs4("div", { children: [
        /* @__PURE__ */ jsx5("p", { className: "text-xs font-semibold uppercase tracking-[0.2em] text-zinc-400", children: "Organization Store" }),
        /* @__PURE__ */ jsx5("h1", { className: "mt-2 text-3xl font-black text-zinc-50 md:text-4xl", children: "W.A.G.E. Society Merch" }),
        /* @__PURE__ */ jsx5("p", { className: "mt-3 max-w-2xl text-zinc-300", children: "Gear for creators, marketers, and entrepreneurs executing daily." })
      ] }),
      /* @__PURE__ */ jsx5(Link2, { to: "/dashboard", className: "rounded-lg border border-zinc-100/25 px-4 py-2 text-sm font-semibold text-zinc-100 transition hover:border-orange-200/70 hover:text-orange-100", children: "Home" })
    ] }) }),
    loading ? /* @__PURE__ */ jsx5("p", { className: "text-zinc-300", children: "Loading merch..." }) : null,
    /* @__PURE__ */ jsxs4("section", { className: "grid gap-5 md:grid-cols-2 xl:grid-cols-4", children: [
      items.map((item) => /* @__PURE__ */ jsxs4("article", { className: "rounded-2xl border border-zinc-200/15 bg-zinc-900/60 p-5", children: [
        /* @__PURE__ */ jsx5("h2", { className: "text-xl font-bold text-zinc-50", children: item.name }),
        /* @__PURE__ */ jsx5("p", { className: "mt-2 text-sm text-zinc-300", children: item.description }),
        /* @__PURE__ */ jsx5("p", { className: "mt-4 text-2xl font-black text-orange-200", children: item.price }),
        /* @__PURE__ */ jsx5("button", { type: "button", className: "mt-4 w-full rounded-lg border border-zinc-100/25 py-2 font-semibold text-zinc-100 transition hover:border-orange-200/70 hover:text-orange-100", children: "Coming Soon" })
      ] }, item.name)),
      !loading && items.length === 0 ? /* @__PURE__ */ jsxs4("article", { className: "rounded-2xl border border-zinc-200/15 bg-zinc-900/60 p-5 md:col-span-2 xl:col-span-4", children: [
        /* @__PURE__ */ jsx5("h2", { className: "text-xl font-bold text-zinc-50", children: "Coming soon" }),
        /* @__PURE__ */ jsx5("p", { className: "mt-2 text-sm text-zinc-300", children: "Merch drops are on the way. Check back soon." })
      ] }) : null
    ] })
  ] }) });
}
var init_merch_CrgHgdMh = __esm({
  "dist/server/assets/merch-CrgHgdMh.js"() {
    "use strict";
  }
});

// dist/server/assets/login-DBOozA1Y.js
var login_DBOozA1Y_exports = {};
__export(login_DBOozA1Y_exports, {
  component: () => LoginPage
});
import { jsx as jsx6 } from "react/jsx-runtime";
import "@tanstack/react-router";
import "lucide-react";
import "react";
import "@supabase/supabase-js";
import "stripe";
import "zod";
function LoginPage() {
  return /* @__PURE__ */ jsx6(AuthPage, { view: "login" });
}
var init_login_DBOozA1Y = __esm({
  "dist/server/assets/login-DBOozA1Y.js"() {
    "use strict";
    init_AuthPage_BmnuUX2O();
    init_router_BDBFyAOM();
  }
});

// dist/server/assets/live-DqGiignv.js
var live_DqGiignv_exports = {};
__export(live_DqGiignv_exports, {
  component: () => LivePage
});
import { jsx as jsx7, jsxs as jsxs5 } from "react/jsx-runtime";
import { Link as Link3 } from "@tanstack/react-router";
import { RadioTower, ExternalLink } from "lucide-react";
import { useState as useState5, useEffect as useEffect5 } from "react";
import "@supabase/supabase-js";
import "stripe";
import "zod";
function LivePage() {
  const [streams, setStreams] = useState5([]);
  const [loading, setLoading] = useState5(true);
  const [error, setError] = useState5("");
  const [canManage, setCanManage] = useState5(false);
  const [canUseAutoclipper, setCanUseAutoclipper] = useState5(false);
  const [autoclipperError, setAutoclipperError] = useState5("");
  const [autoJobs, setAutoJobs] = useState5([]);
  const [autoLoading, setAutoLoading] = useState5(true);
  const [autoBusy, setAutoBusy] = useState5(false);
  const [updatingJobId, setUpdatingJobId] = useState5(null);
  const formatNumber = (value) => {
    if (value === null || Number.isNaN(value)) return "Unknown";
    return new Intl.NumberFormat().format(value);
  };
  const formatStreamLabel = (stream) => {
    if (stream.title) return stream.title;
    if (stream.platform !== "youtube") {
      return `${stream.platform.toUpperCase()} \xB7 ${stream.stream_key}`;
    }
    if (stream.stream_key.startsWith("handle:")) {
      return `YOUTUBE \xB7 ${stream.stream_key.slice("handle:".length)}`;
    }
    if (stream.stream_key.startsWith("channel:")) {
      return `YOUTUBE \xB7 Channel ${stream.stream_key.slice("channel:".length)}`;
    }
    if (stream.stream_key.startsWith("user:")) {
      return `YOUTUBE \xB7 ${stream.stream_key.slice("user:".length)}`;
    }
    if (stream.stream_key.startsWith("custom:")) {
      return `YOUTUBE \xB7 ${stream.stream_key.slice("custom:".length)}`;
    }
    return `YOUTUBE \xB7 ${stream.stream_key}`;
  };
  const loadStreams = async () => {
    try {
      setError("");
      const response = await authedFetch("/api/live/streams");
      const data = await response.json();
      if (!response.ok) {
        setError(data.error || "Failed to load livestreams");
        return;
      }
      const liveData = data;
      setStreams(liveData.streams || []);
      setCanManage(liveData.canManage);
      setCanUseAutoclipper(Boolean(liveData.canUseAutoclipper));
      return Boolean(liveData.canUseAutoclipper);
    } catch {
      setError("Failed to load livestreams");
      return false;
    }
  };
  const loadAutoclipperJobs = async () => {
    try {
      setAutoclipperError("");
      const response = await authedFetch("/api/live/clips");
      const data = await response.json();
      if (!response.ok) {
        setAutoclipperError(data.error || "Failed to load autoclipper queue");
        return;
      }
      setAutoJobs(data.jobs || []);
    } catch {
      setAutoclipperError("Failed to load autoclipper queue");
    } finally {
      setAutoLoading(false);
    }
  };
  useEffect5(() => {
    void (async () => {
      setLoading(true);
      const hasAutoclipperAccess = await loadStreams();
      if (hasAutoclipperAccess) {
        await loadAutoclipperJobs();
      } else {
        setAutoJobs([]);
        setAutoLoading(false);
      }
      setLoading(false);
    })();
  }, []);
  const triggerAutoclip = async () => {
    try {
      setAutoBusy(true);
      setError("");
      const response = await authedFetch("/api/live/clips", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          commandText: "!clip",
          autoPost: true,
          autoCaption: true,
          platforms: ["x", "kick", "instagram"],
          clipWindowMinutes: 5
        })
      });
      const data = await response.json();
      if (!response.ok) {
        setError(data.error || "Failed to trigger autoclip");
        return;
      }
      await loadAutoclipperJobs();
    } catch {
      setError("Failed to trigger autoclip");
    } finally {
      setAutoBusy(false);
    }
  };
  const updateAutoclipStatus = async (id, status) => {
    try {
      setUpdatingJobId(id);
      setError("");
      const response = await authedFetch("/api/live/clips", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          id,
          status
        })
      });
      const data = await response.json();
      if (!response.ok) {
        setError(data.error || "Failed to update clip status");
        return;
      }
      await loadAutoclipperJobs();
    } catch {
      setError("Failed to update clip status");
    } finally {
      setUpdatingJobId(null);
    }
  };
  return /* @__PURE__ */ jsx7("div", { className: "min-h-screen px-4 py-12 text-zinc-100", children: /* @__PURE__ */ jsxs5("div", { className: "mx-auto max-w-6xl space-y-6", children: [
    /* @__PURE__ */ jsx7("header", { className: "rounded-2xl border border-zinc-200/15 bg-zinc-900/60 p-6 md:p-8", children: /* @__PURE__ */ jsxs5("div", { className: "flex flex-wrap items-center justify-between gap-4", children: [
      /* @__PURE__ */ jsxs5("div", { children: [
        /* @__PURE__ */ jsx7("p", { className: "text-xs font-semibold uppercase tracking-[0.2em] text-zinc-400", children: "Live Control Center" }),
        /* @__PURE__ */ jsx7("h1", { className: "mt-2 text-3xl font-black text-zinc-50 md:text-4xl", children: "Organization Livestreams" }),
        /* @__PURE__ */ jsx7("p", { className: "mt-3 max-w-2xl text-zinc-300", children: "Streams are pulled automatically from member-linked Kick, Twitch, and YouTube accounts." })
      ] }),
      /* @__PURE__ */ jsxs5("div", { className: "flex gap-3", children: [
        /* @__PURE__ */ jsx7(Link3, { to: "/dashboard", className: "rounded-lg border border-zinc-100/25 px-4 py-2 text-sm font-semibold text-zinc-100 transition hover:border-orange-200/70 hover:text-orange-100", children: "Home" }),
        /* @__PURE__ */ jsx7(Link3, { to: "/dashboard", className: "rounded-lg border border-zinc-100/25 px-4 py-2 text-sm font-semibold text-zinc-100 transition hover:border-orange-200/70 hover:text-orange-100", children: "Dashboard" })
      ] })
    ] }) }),
    error ? /* @__PURE__ */ jsx7("p", { className: "rounded-lg border border-rose-400/40 bg-rose-500/10 px-3 py-2 text-sm text-rose-200", children: error }) : null,
    canUseAutoclipper ? /* @__PURE__ */ jsxs5("section", { className: "rounded-2xl border border-zinc-200/15 bg-zinc-900/60 p-6", children: [
      /* @__PURE__ */ jsxs5("div", { className: "flex flex-wrap items-start justify-between gap-3", children: [
        /* @__PURE__ */ jsxs5("div", { children: [
          /* @__PURE__ */ jsx7("h2", { className: "text-xl font-bold text-zinc-50", children: "Autoclipper" }),
          /* @__PURE__ */ jsxs5("p", { className: "mt-2 text-sm text-zinc-300", children: [
            "Chat users run ",
            /* @__PURE__ */ jsx7("span", { className: "font-semibold text-orange-200", children: "!clip" }),
            " and the bot auto-creates a 5-minute clip job, auto-captions it, and auto-queues social posts."
          ] }),
          /* @__PURE__ */ jsx7("p", { className: "mt-2 text-xs text-zinc-500", children: "Discord/chat bot integration endpoint: /api/live/clips (header x-autoclipper-secret required)." })
        ] }),
        /* @__PURE__ */ jsx7("button", { type: "button", onClick: () => {
          void triggerAutoclip();
        }, disabled: autoBusy, className: "rounded-lg bg-orange-300 px-4 py-2.5 text-sm font-semibold text-zinc-950 transition hover:bg-orange-200 disabled:cursor-not-allowed disabled:opacity-70", children: autoBusy ? "Triggering..." : "Trigger !clip (Test)" })
      ] }),
      /* @__PURE__ */ jsxs5("div", { className: "mt-4 rounded-xl border border-zinc-200/10 bg-zinc-950/40 p-4", children: [
        /* @__PURE__ */ jsx7("p", { className: "text-xs font-semibold uppercase tracking-[0.2em] text-zinc-500", children: "Clip Queue" }),
        autoclipperError ? /* @__PURE__ */ jsx7("p", { className: "mt-2 rounded-md border border-rose-400/40 bg-rose-500/10 px-3 py-2 text-xs text-rose-200", children: autoclipperError }) : null,
        autoLoading ? /* @__PURE__ */ jsx7("p", { className: "mt-2 text-sm text-zinc-400", children: "Loading clip jobs..." }) : autoJobs.length === 0 ? /* @__PURE__ */ jsx7("p", { className: "mt-2 text-sm text-zinc-500", children: "No clip jobs yet. Send !clip in chat or click Trigger !clip." }) : /* @__PURE__ */ jsx7("div", { className: "mt-3 space-y-2", children: autoJobs.map((job) => /* @__PURE__ */ jsx7("div", { className: "rounded-lg border border-zinc-200/10 bg-zinc-900/50 p-3", children: /* @__PURE__ */ jsxs5("div", { className: "flex flex-wrap items-start justify-between gap-2", children: [
          /* @__PURE__ */ jsxs5("div", { children: [
            /* @__PURE__ */ jsxs5("p", { className: "text-sm font-semibold text-zinc-100", children: [
              job.command,
              " \u2022 ",
              job.clipWindowMinutes,
              "m \u2022 ",
              job.source
            ] }),
            /* @__PURE__ */ jsxs5("p", { className: "text-xs text-zinc-400", children: [
              "By ",
              job.requestedBy,
              " \xB7 Platforms: ",
              job.platforms.join(", ") || "none"
            ] }),
            job.caption ? /* @__PURE__ */ jsx7("p", { className: "mt-1 text-xs text-zinc-300", children: job.caption }) : null,
            job.queuedPostId ? /* @__PURE__ */ jsx7("p", { className: "mt-1 text-[11px] text-emerald-300", children: "Queued for social posting." }) : null,
            job.clipUrl ? /* @__PURE__ */ jsx7("a", { href: String(job.clipUrl), target: "_blank", rel: "noreferrer", className: "mt-1 inline-flex text-xs text-orange-200 hover:text-orange-100", children: "Open clip URL" }) : null
          ] }),
          /* @__PURE__ */ jsxs5("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsx7("span", { className: `rounded-full px-2 py-0.5 text-xs font-semibold ${job.status === "posted" ? "bg-emerald-300/10 text-emerald-300" : job.status === "failed" ? "bg-rose-300/10 text-rose-300" : job.status === "ready" ? "bg-sky-300/10 text-sky-300" : "bg-zinc-200/10 text-zinc-400"}`, children: job.status }),
            canManage ? /* @__PURE__ */ jsxs5("select", { value: job.status, onChange: (event) => {
              void updateAutoclipStatus(job.id, event.target.value);
            }, disabled: updatingJobId === job.id, className: "rounded-md border border-zinc-200/20 bg-zinc-950/70 px-2 py-1 text-xs text-zinc-100 outline-none", children: [
              /* @__PURE__ */ jsx7("option", { value: "queued", children: "queued" }),
              /* @__PURE__ */ jsx7("option", { value: "processing", children: "processing" }),
              /* @__PURE__ */ jsx7("option", { value: "ready", children: "ready" }),
              /* @__PURE__ */ jsx7("option", { value: "posted", children: "posted" }),
              /* @__PURE__ */ jsx7("option", { value: "failed", children: "failed" })
            ] }) : null
          ] })
        ] }) }, job.id)) })
      ] })
    ] }) : null,
    /* @__PURE__ */ jsxs5("section", { className: "space-y-3", children: [
      loading ? /* @__PURE__ */ jsx7("p", { className: "text-zinc-300", children: "Loading livestreams..." }) : null,
      !loading && streams.length === 0 ? /* @__PURE__ */ jsx7("article", { className: "rounded-2xl border border-zinc-200/15 bg-zinc-900/60 p-5 text-zinc-300", children: "No linked livestream profiles found yet." }) : null,
      streams.map((stream) => {
        const isLive = stream.status === "live";
        return /* @__PURE__ */ jsx7("article", { className: "rounded-2xl border border-zinc-200/15 bg-zinc-900/60 p-5 transition hover:border-orange-300/40", children: /* @__PURE__ */ jsxs5("div", { className: "flex flex-wrap items-start justify-between gap-3", children: [
          /* @__PURE__ */ jsxs5("a", { href: stream.url, target: "_blank", rel: "noreferrer", className: "group block min-w-0 flex-1", children: [
            /* @__PURE__ */ jsxs5("div", { className: "flex items-center gap-2", children: [
              /* @__PURE__ */ jsx7(RadioTower, { size: 16, className: isLive ? "text-rose-300" : "text-zinc-400" }),
              /* @__PURE__ */ jsx7("p", { className: "truncate text-lg font-semibold text-zinc-50 group-hover:text-orange-100", children: formatStreamLabel(stream) }),
              /* @__PURE__ */ jsx7(ExternalLink, { size: 16, className: "text-zinc-400 group-hover:text-orange-200" })
            ] }),
            /* @__PURE__ */ jsx7("p", { className: "mt-1 truncate text-sm text-zinc-300", children: stream.url })
          ] }),
          /* @__PURE__ */ jsxs5("div", { className: "flex flex-col items-end gap-2", children: [
            /* @__PURE__ */ jsx7("div", { className: "flex items-center gap-2", children: /* @__PURE__ */ jsx7("span", { className: `rounded-full border px-3 py-1 text-xs font-semibold uppercase tracking-wide ${isLive ? "border-rose-300/60 bg-rose-500/10 text-rose-200" : "border-zinc-500/50 bg-zinc-800/40 text-zinc-300"}`, children: isLive ? "Live" : "Offline" }) }),
            isLive ? /* @__PURE__ */ jsxs5("p", { className: "text-xs text-zinc-300", children: [
              "Viewers: ",
              formatNumber(stream.viewer_count)
            ] }) : null
          ] })
        ] }) }, stream.id);
      })
    ] })
  ] }) });
}
var init_live_DqGiignv = __esm({
  "dist/server/assets/live-DqGiignv.js"() {
    "use strict";
    init_router_BDBFyAOM();
  }
});

// dist/server/assets/faq-Bcw04J07.js
var faq_Bcw04J07_exports = {};
__export(faq_Bcw04J07_exports, {
  component: () => FAQ
});
import { jsx as jsx8, jsxs as jsxs6 } from "react/jsx-runtime";
import { useState as useState6 } from "react";
import { ChevronDown } from "lucide-react";
function FAQ() {
  return /* @__PURE__ */ jsx8("div", { className: "min-h-screen px-4 py-20 text-zinc-100", children: /* @__PURE__ */ jsxs6("div", { className: "mx-auto max-w-3xl", children: [
    /* @__PURE__ */ jsx8("h1", { className: "text-center text-4xl font-black md:text-5xl", children: "W.A.G.E. Society Organization FAQ" }),
    /* @__PURE__ */ jsx8("p", { className: "mx-auto mt-4 max-w-2xl text-center text-zinc-300", children: "Answers about membership tracks, authentication, growth channels, live training, and creator business tools." }),
    /* @__PURE__ */ jsx8("div", { className: "mt-14 space-y-3", children: faqs.map((faq) => /* @__PURE__ */ jsx8(Accordion, { question: faq.question, answer: faq.answer }, faq.question)) })
  ] }) });
}
function Accordion({
  question,
  answer
}) {
  const [open, setOpen] = useState6(false);
  const contentId = `faq-${question.toLowerCase().replace(/[^a-z0-9]+/g, "-")}`;
  return /* @__PURE__ */ jsxs6("div", { className: "overflow-hidden rounded-lg border border-zinc-200/15 bg-zinc-900/70", children: [
    /* @__PURE__ */ jsxs6("button", { onClick: () => setOpen(!open), "aria-expanded": open, "aria-controls": contentId, className: "flex w-full items-center justify-between px-5 py-4 text-left transition hover:bg-zinc-800/70", children: [
      /* @__PURE__ */ jsx8("span", { className: "text-lg font-semibold text-zinc-100", children: question }),
      /* @__PURE__ */ jsx8(ChevronDown, { size: 20, className: `text-zinc-300 transition-transform ${open ? "rotate-180" : ""}` })
    ] }),
    open && /* @__PURE__ */ jsx8("div", { id: contentId, className: "px-5 pb-5 leading-relaxed text-zinc-300", children: answer })
  ] });
}
var faqs;
var init_faq_Bcw04J07 = __esm({
  "dist/server/assets/faq-Bcw04J07.js"() {
    "use strict";
    faqs = [{
      question: "What is W.A.G.E. Society?",
      answer: "W.A.G.E. Society is a member-driven organization for content creators, online marketers, and entrepreneurs. It combines strategy resources, community accountability, and execution systems in one environment."
    }, {
      question: "How does member authentication work?",
      answer: "Members sign in through a secure login flow that unlocks private organization areas. Access controls can be configured for different membership tracks, moderators, and leadership groups."
    }, {
      question: "Do you provide collaboration channels for growth?",
      answer: "Yes. Members get access to collaboration channels for campaign feedback, launch planning, offer testing, and peer accountability sessions."
    }, {
      question: "Can members share marketing assets and playbooks?",
      answer: "Yes. Members can share scripts, templates, funnels, swipe files, and curated links in structured channels designed for fast implementation."
    }, {
      question: "Are there live sessions and trainings?",
      answer: "Yes. The organization runs live workshops, office hours, and strategy roundtables with schedules and reminders so members can join in real time."
    }, {
      question: "What topics are covered inside the organization?",
      answer: "Core topics include content systems, online marketing, offers, audience growth, sales funnels, automation, and entrepreneurship operations."
    }, {
      question: "Who is this platform designed for?",
      answer: "It is designed for creators, marketers, founders, and operators who want a focused organization where learning, implementation, and revenue growth happen together."
    }];
  }
});

// dist/server/assets/download-CCZ7f8Cx.js
var download_CCZ7f8Cx_exports = {};
__export(download_CCZ7f8Cx_exports, {
  component: () => DownloadPage
});
import { jsx as jsx9, jsxs as jsxs7 } from "react/jsx-runtime";
import { Smartphone, Download } from "lucide-react";
function DownloadPage() {
  return /* @__PURE__ */ jsx9("div", { className: "min-h-screen bg-zinc-950 text-white", children: /* @__PURE__ */ jsxs7("div", { className: "mx-auto max-w-2xl px-6 py-20 text-center", children: [
    /* @__PURE__ */ jsx9("div", { className: "mb-6 flex justify-center", children: /* @__PURE__ */ jsx9("div", { className: "rounded-2xl bg-orange-500/10 p-5 ring-1 ring-orange-500/30", children: /* @__PURE__ */ jsx9(Smartphone, { className: "h-12 w-12 text-orange-400" }) }) }),
    /* @__PURE__ */ jsx9("h1", { className: "mb-3 text-4xl font-bold tracking-tight", children: "W.A.G.E. Society App" }),
    /* @__PURE__ */ jsx9("p", { className: "mb-12 text-lg text-zinc-400", children: "Take the community with you. Access your dashboard, live streams, news, and tools from your mobile device." }),
    /* @__PURE__ */ jsxs7("div", { className: "grid gap-4 sm:grid-cols-2", children: [
      /* @__PURE__ */ jsxs7("div", { className: "flex flex-col items-center gap-3 rounded-2xl bg-zinc-900 p-8 ring-1 ring-zinc-800", children: [
        /* @__PURE__ */ jsx9(AndroidLogo, {}),
        /* @__PURE__ */ jsxs7("div", { children: [
          /* @__PURE__ */ jsx9("div", { className: "text-xs font-medium uppercase tracking-widest text-zinc-500", children: "Available for" }),
          /* @__PURE__ */ jsx9("div", { className: "text-xl font-bold", children: "Android" })
        ] }),
        /* @__PURE__ */ jsx9("div", { className: "w-full", children: /* @__PURE__ */ jsxs7("a", { href: "/wage-society.apk", download: true, className: "group flex items-center justify-center gap-2 rounded-xl bg-zinc-800 px-4 py-3 text-sm font-medium text-zinc-300 ring-1 ring-zinc-700 transition hover:bg-zinc-700 hover:text-white", children: [
          /* @__PURE__ */ jsx9(Download, { className: "h-4 w-4" }),
          "Download APK (sideload)"
        ] }) })
      ] }),
      /* @__PURE__ */ jsxs7("div", { className: "flex flex-col items-center gap-3 rounded-2xl bg-zinc-900 p-8 ring-1 ring-zinc-800", children: [
        /* @__PURE__ */ jsx9(AppleLogo, {}),
        /* @__PURE__ */ jsxs7("div", { children: [
          /* @__PURE__ */ jsx9("div", { className: "text-xs font-medium uppercase tracking-widest text-zinc-500", children: "Install on" }),
          /* @__PURE__ */ jsx9("div", { className: "text-xl font-bold", children: "iPhone / iPad" })
        ] }),
        /* @__PURE__ */ jsxs7("div", { className: "rounded-xl bg-zinc-800 px-4 py-3 ring-1 ring-zinc-700 w-full", children: [
          /* @__PURE__ */ jsx9("p", { className: "mb-1 text-xs font-semibold uppercase tracking-wider text-zinc-500", children: "Install via Safari" }),
          /* @__PURE__ */ jsxs7("ol", { className: "list-inside list-decimal space-y-1 text-left text-xs text-zinc-400", children: [
            /* @__PURE__ */ jsxs7("li", { children: [
              "Open ",
              /* @__PURE__ */ jsx9("span", { className: "text-zinc-200", children: "wagesociety.com" }),
              " in Safari"
            ] }),
            /* @__PURE__ */ jsxs7("li", { children: [
              "Tap the ",
              /* @__PURE__ */ jsx9("span", { className: "text-zinc-200", children: "Share" }),
              " button"
            ] }),
            /* @__PURE__ */ jsxs7("li", { children: [
              "Choose ",
              /* @__PURE__ */ jsx9("span", { className: "text-zinc-200", children: "Add to Home Screen" })
            ] })
          ] })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxs7("div", { className: "mt-8 rounded-xl bg-zinc-900 px-6 py-4 text-left ring-1 ring-zinc-800", children: [
      /* @__PURE__ */ jsx9("p", { className: "mb-1 text-sm font-semibold text-orange-400", children: "APK sideload instructions" }),
      /* @__PURE__ */ jsxs7("ol", { className: "list-inside list-decimal space-y-1 text-sm text-zinc-400", children: [
        /* @__PURE__ */ jsxs7("li", { children: [
          "Tap ",
          /* @__PURE__ */ jsx9("span", { className: "font-medium text-white", children: "Download APK" }),
          " above."
        ] }),
        /* @__PURE__ */ jsx9("li", { children: "Open the file from your notification bar or file manager." }),
        /* @__PURE__ */ jsxs7("li", { children: [
          "If prompted, go to",
          " ",
          /* @__PURE__ */ jsx9("span", { className: "font-medium text-white", children: "Settings \u2192 Apps \u2192 Special app access \u2192 Install unknown apps" }),
          " ",
          "and allow your browser or file manager."
        ] }),
        /* @__PURE__ */ jsxs7("li", { children: [
          "Tap ",
          /* @__PURE__ */ jsx9("span", { className: "font-medium text-white", children: "Install" }),
          " and launch the app."
        ] })
      ] })
    ] })
  ] }) });
}
function AndroidLogo() {
  return /* @__PURE__ */ jsx9("svg", { viewBox: "0 0 24 24", className: "h-10 w-10 fill-[#3DDC84]", "aria-label": "Android", children: /* @__PURE__ */ jsx9("path", { d: "M17.523 15.341a.9.9 0 1 1-.001 1.8.9.9 0 0 1 0-1.8m-11.046 0a.9.9 0 1 1 0 1.801.9.9 0 0 1 0-1.8M17.7 9.3l1.575-2.727a.328.328 0 0 0-.12-.449.328.328 0 0 0-.449.12l-1.595 2.762A9.83 9.83 0 0 0 12 8.1c-1.476 0-2.876.316-4.112.906L6.294 6.244a.328.328 0 0 0-.449-.12.328.328 0 0 0-.12.449L7.3 9.3C4.91 10.664 3.3 13.193 3.3 16.1h17.4c0-2.907-1.61-5.436-3-6.8" }) });
}
function AppleLogo() {
  return /* @__PURE__ */ jsx9("svg", { viewBox: "0 0 24 24", className: "h-10 w-10 fill-zinc-400", "aria-label": "Apple", children: /* @__PURE__ */ jsx9("path", { d: "M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.8-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M13 3.5c.73-.83 1.94-1.46 2.94-1.5.13 1.17-.34 2.35-1.04 3.19-.69.85-1.83 1.51-2.95 1.42-.15-1.15.41-2.35 1.05-3.11" }) });
}
var init_download_CCZ7f8Cx = __esm({
  "dist/server/assets/download-CCZ7f8Cx.js"() {
    "use strict";
  }
});

// dist/server/assets/directory-j20xSbNp.js
var directory_j20xSbNp_exports = {};
__export(directory_j20xSbNp_exports, {
  component: () => DirectoryPage
});
import { jsx as jsx10, jsxs as jsxs8 } from "react/jsx-runtime";
import { Link as Link4 } from "@tanstack/react-router";
import { Users, Search, Loader2 as Loader22, UserRound as UserRound2 } from "lucide-react";
import { useState as useState7, useEffect as useEffect6, useMemo } from "react";
import "@supabase/supabase-js";
import "stripe";
import "zod";
function DirectoryPage() {
  const [loading, setLoading] = useState7(true);
  const [entries, setEntries] = useState7([]);
  const [error, setError] = useState7("");
  const [query, setQuery] = useState7("");
  const [user, setUser] = useState7(null);
  const [authLoading, setAuthLoading] = useState7(true);
  useEffect6(() => {
    let mounted = true;
    void (async () => {
      setLoading(true);
      setError("");
      try {
        const response = await authedFetch("/api/public-directory?limit=500");
        const data = await response.json();
        if (!response.ok) {
          if (!mounted) return;
          setError(data.error || "Could not load creator directory.");
          setEntries([]);
          return;
        }
        if (!mounted) return;
        setEntries(Array.isArray(data.entries) ? data.entries : []);
      } catch {
        if (!mounted) return;
        setError("Could not load creator directory.");
        setEntries([]);
      } finally {
        if (mounted) setLoading(false);
      }
    })();
    return () => {
      mounted = false;
    };
  }, []);
  useEffect6(() => {
    const supabase = getSupabaseBrowserClient();
    const checkAuth = async () => {
      if (isLocalRootSessionActive()) {
        setUser(getLocalRootUser());
        setAuthLoading(false);
        return;
      }
      try {
        const {
          data
        } = await supabase.auth.getSession();
        setUser(data.session?.user || null);
      } catch {
        setUser(null);
      } finally {
        setAuthLoading(false);
      }
    };
    void checkAuth();
    const {
      data: {
        subscription
      }
    } = supabase.auth.onAuthStateChange((_event, session) => {
      if (isLocalRootSessionActive()) {
        setUser(getLocalRootUser());
        setAuthLoading(false);
        return;
      }
      setUser(session?.user || null);
      setAuthLoading(false);
    });
    return () => {
      subscription.unsubscribe();
    };
  }, []);
  const filteredEntries = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return entries;
    return entries.filter((entry) => {
      const haystack = `${entry.username} ${entry.displayName} ${entry.bio || ""}`.toLowerCase();
      return haystack.includes(q);
    });
  }, [entries, query]);
  return /* @__PURE__ */ jsx10("main", { className: "min-h-screen px-4 py-10 text-zinc-100", children: /* @__PURE__ */ jsx10("div", { className: "mx-auto max-w-5xl", children: /* @__PURE__ */ jsxs8("section", { className: "rounded-3xl border border-zinc-200/15 bg-zinc-900/60 p-6 md:p-8", children: [
    /* @__PURE__ */ jsxs8("div", { className: "flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between", children: [
      /* @__PURE__ */ jsxs8("div", { children: [
        /* @__PURE__ */ jsxs8("p", { className: "inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.2em] text-zinc-500", children: [
          /* @__PURE__ */ jsx10(Users, { size: 13 }),
          " Public Directory"
        ] }),
        /* @__PURE__ */ jsx10("h1", { className: "mt-2 text-3xl font-black text-zinc-50", children: "Creator Directory" }),
        /* @__PURE__ */ jsx10("p", { className: "mt-2 text-sm text-zinc-300", children: "Browse all signed-up members and visit their public profiles." })
      ] }),
      /* @__PURE__ */ jsxs8("div", { className: "flex flex-wrap gap-2", children: [
        /* @__PURE__ */ jsx10(Link4, { to: "/", className: "rounded-lg border border-zinc-100/25 px-4 py-2 text-sm font-semibold text-zinc-100 transition hover:border-orange-200/70", children: "Home" }),
        !authLoading && (user ? /* @__PURE__ */ jsx10(Link4, { to: "/dashboard", className: "rounded-lg bg-orange-300 px-4 py-2 text-sm font-semibold text-zinc-950 transition hover:bg-orange-200", children: "Dashboard" }) : /* @__PURE__ */ jsx10(Link4, { to: "/signup", className: "rounded-lg bg-orange-300 px-4 py-2 text-sm font-semibold text-zinc-950 transition hover:bg-orange-200", children: "Join W.A.G.E." }))
      ] })
    ] }),
    /* @__PURE__ */ jsxs8("div", { className: "mt-6", children: [
      /* @__PURE__ */ jsx10("label", { className: "mb-2 block text-xs font-semibold uppercase tracking-[0.15em] text-zinc-500", children: "Search" }),
      /* @__PURE__ */ jsxs8("div", { className: "flex items-center gap-2 rounded-xl border border-zinc-200/20 bg-zinc-950/60 px-3 py-2", children: [
        /* @__PURE__ */ jsx10(Search, { size: 14, className: "text-zinc-500" }),
        /* @__PURE__ */ jsx10("input", { type: "text", value: query, onChange: (event) => setQuery(event.target.value), placeholder: "Search by username, display name, or bio", className: "w-full bg-transparent text-sm text-zinc-100 outline-none placeholder:text-zinc-500" })
      ] })
    ] }),
    loading ? /* @__PURE__ */ jsxs8("p", { className: "mt-6 inline-flex items-center gap-2 text-sm text-zinc-300", children: [
      /* @__PURE__ */ jsx10(Loader22, { size: 14, className: "animate-spin" }),
      " Loading members..."
    ] }) : error ? /* @__PURE__ */ jsx10("p", { className: "mt-6 rounded-xl border border-rose-400/40 bg-rose-500/10 px-4 py-3 text-sm text-rose-200", children: error }) : filteredEntries.length === 0 ? /* @__PURE__ */ jsx10("p", { className: "mt-6 rounded-xl border border-zinc-200/15 bg-zinc-950/50 px-4 py-3 text-sm text-zinc-400", children: "No members found." }) : /* @__PURE__ */ jsx10("ul", { className: "mt-6 grid gap-3", children: filteredEntries.map((entry) => /* @__PURE__ */ jsx10("li", { children: /* @__PURE__ */ jsxs8(Link4, { to: "/$username", params: {
      username: entry.username
    }, className: "flex items-start gap-3 rounded-2xl border border-zinc-200/15 bg-zinc-950/45 p-4 transition hover:border-orange-200/60 hover:bg-zinc-900/80", children: [
      entry.avatarUrl ? /* @__PURE__ */ jsx10("img", { src: entry.avatarUrl, alt: `${entry.displayName} avatar`, className: "h-12 w-12 flex-shrink-0 rounded-full border border-zinc-200/20 object-cover" }) : /* @__PURE__ */ jsx10("div", { className: "flex h-12 w-12 flex-shrink-0 items-center justify-center rounded-full border border-zinc-200/20 bg-zinc-800", children: /* @__PURE__ */ jsx10(UserRound2, { size: 16, className: "text-zinc-500" }) }),
      /* @__PURE__ */ jsxs8("div", { className: "min-w-0 flex-1", children: [
        /* @__PURE__ */ jsxs8("div", { className: "flex flex-wrap items-center gap-2", children: [
          /* @__PURE__ */ jsx10("p", { className: "truncate text-sm font-semibold text-zinc-100", children: entry.displayName }),
          /* @__PURE__ */ jsxs8("span", { className: "rounded-full border border-zinc-200/20 bg-zinc-900 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-[0.1em] text-zinc-400", children: [
            "@",
            entry.username
          ] })
        ] }),
        /* @__PURE__ */ jsx10("p", { className: "mt-1 line-clamp-2 text-xs text-zinc-400", children: entry.bio || "No bio available yet." }),
        /* @__PURE__ */ jsxs8("p", { className: "mt-2 text-[11px] uppercase tracking-[0.12em] text-zinc-500", children: [
          "Connected Accounts: ",
          entry.connectedCount
        ] })
      ] }),
      /* @__PURE__ */ jsx10("span", { className: "rounded-lg border border-zinc-100/25 px-2.5 py-1 text-xs font-semibold text-zinc-200", children: "View Profile" })
    ] }) }, entry.username)) })
  ] }) }) });
}
var init_directory_j20xSbNp = __esm({
  "dist/server/assets/directory-j20xSbNp.js"() {
    "use strict";
    init_router_BDBFyAOM();
  }
});

// dist/server/assets/dashboard-BD7PNkS0.js
var dashboard_BD7PNkS0_exports = {};
__export(dashboard_BD7PNkS0_exports, {
  component: () => DashboardGate
});
import { jsxs as jsxs9, jsx as jsx11, Fragment as Fragment2 } from "react/jsx-runtime";
import { useLocation, useNavigate as useNavigate3, Outlet, Link as Link5 } from "@tanstack/react-router";
import { useState as useState8, useRef as useRef4, useEffect as useEffect7 } from "react";
import { Loader2 as Loader23, User, Link2 as Link22, Check, AlertCircle, Save, Megaphone, Newspaper, LayoutDashboard, Settings, Shield, CreditCard, CalendarDays, DollarSign, ClipboardList, Users as Users2, NotebookPen, Radio, Store, Target } from "lucide-react";
import "@supabase/supabase-js";
import "stripe";
import "zod";
function toTitleCase(value) {
  return value.split(/[\s_-]+/).filter(Boolean).map((word) => word[0]?.toUpperCase() + word.slice(1)).join(" ");
}
function providerOptionFromKey(key) {
  const normalized = key.trim().toLowerCase();
  const fallback = FALLBACK_OAUTH_PROVIDERS.find((provider) => provider.key === normalized);
  if (fallback) return fallback;
  const customName = normalized.startsWith("custom:") ? normalized.slice("custom:".length) : normalized;
  const label = toTitleCase(customName) || normalized;
  return {
    key: normalized,
    label,
    description: `Link your ${label} account`
  };
}
function mergeProviderOptions(fromServer, user) {
  const options = /* @__PURE__ */ new Map();
  for (const provider of fromServer ?? []) {
    const key = String(provider.key || "").trim().toLowerCase();
    if (!key) continue;
    options.set(key, {
      key,
      label: String(provider.label || "").trim() || providerOptionFromKey(key).label,
      description: String(provider.description || "").trim() || providerOptionFromKey(key).description
    });
  }
  for (const identity of user?.identities ?? []) {
    const key = String(identity.provider || "").trim().toLowerCase();
    if (!key || key === "email") continue;
    if (!options.has(key)) {
      options.set(key, providerOptionFromKey(key));
    }
  }
  if (options.size === 0) {
    for (const provider of FALLBACK_OAUTH_PROVIDERS) {
      options.set(provider.key, provider);
    }
  }
  if (!options.has("google")) {
    options.set("google", providerOptionFromKey("google"));
  }
  if (!options.has("custom:kick") && !options.has("kick")) {
    options.set("custom:kick", providerOptionFromKey("custom:kick"));
  }
  return Array.from(options.values()).sort((a, b) => a.label.localeCompare(b.label));
}
function deriveUsername(user, memberEmail) {
  const fromUsername = String(user?.user_metadata?.username || "").trim();
  const fromPreferred = String(user?.user_metadata?.preferred_username || "").trim();
  const fromEmail = String(user?.email || memberEmail || "").split("@")[0].trim();
  return fromUsername || fromPreferred || fromEmail || "";
}
function ProfileSettings({ member }) {
  const [profile, setProfile] = useState8(null);
  const [displayName, setDisplayName] = useState8("");
  const [usernameStatus, setUsernameStatus] = useState8("idle");
  const [usernameMessage, setUsernameMessage] = useState8("");
  const usernameDebounceRef = useRef4(null);
  const [avatarUrl, setAvatarUrl] = useState8("");
  const [avatarUploading, setAvatarUploading] = useState8(false);
  const [bio, setBio] = useState8("");
  const [skillsInput, setSkillsInput] = useState8("");
  const [kickConnectedUrl, setKickConnectedUrl] = useState8(null);
  const [kickConnectedUsername, setKickConnectedUsername] = useState8(null);
  const [youtubeConnected, setYoutubeConnected] = useState8(false);
  const [youtubeOptions, setYoutubeOptions] = useState8([]);
  const [selectedYouTubeChannel, setSelectedYouTubeChannel] = useState8("");
  const [loading, setLoading] = useState8(true);
  const [saving, setSaving] = useState8(false);
  const [saved, setSaved] = useState8(false);
  const [error, setError] = useState8("");
  const [user, setUser] = useState8(null);
  const [linkingProvider, setLinkingProvider] = useState8(null);
  const [oauthProviders, setOauthProviders] = useState8(FALLBACK_OAUTH_PROVIDERS);
  useEffect7(() => {
    void (async () => {
      try {
        const supabase = getSupabaseBrowserClient();
        const [profileResponse, { data: { user: currentUser } }] = await Promise.all([
          authedFetch("/api/me/profile"),
          supabase.auth.getUser()
        ]);
        const metadataName = deriveUsername(currentUser, member.email);
        if (profileResponse.ok) {
          const data = await profileResponse.json();
          const p = data.profile;
          setProfile(p);
          setOauthProviders(mergeProviderOptions(data.oauth_providers, currentUser));
          setDisplayName(p.display_name || metadataName);
          setAvatarUrl(p.avatar_url || "");
          setBio(p.bio || "");
          setSkillsInput((p.skills || []).join(", "));
          const streamAccounts = data.stream_accounts;
          setKickConnectedUrl(streamAccounts?.kick?.url || null);
          setKickConnectedUsername(streamAccounts?.kick?.username || null);
          setYoutubeConnected(Boolean(streamAccounts?.youtube?.connected));
          const nextYouTubeOptions = streamAccounts?.youtube?.options || [];
          setYoutubeOptions(nextYouTubeOptions);
          const selected = streamAccounts?.youtube?.selected || nextYouTubeOptions[0]?.key || "";
          setSelectedYouTubeChannel(selected);
        } else {
          setOauthProviders(mergeProviderOptions(void 0, currentUser));
          setDisplayName(metadataName);
        }
        setUser(currentUser);
      } catch {
        setError("Failed to load profile.");
      } finally {
        setLoading(false);
      }
    })();
  }, []);
  const handleSave = async () => {
    setSaving(true);
    setError("");
    setSaved(false);
    const trimmed = displayName.trim();
    if (trimmed && !/^[a-zA-Z0-9_-]{3,20}$/.test(trimmed)) {
      setError("Username must be 3\u201320 characters: letters, numbers, underscores, or hyphens only.");
      setSaving(false);
      return;
    }
    if (usernameStatus === "taken") {
      setError("That username is already taken. Please choose another.");
      setSaving(false);
      return;
    }
    const response = await authedFetch("/api/me/profile", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        displayName: displayName.trim() || void 0,
        avatarUrl: avatarUrl.trim() || "",
        bio: bio.trim() || void 0,
        skills: skillsInput.split(",").map((s) => s.trim()).filter(Boolean),
        selectedYouTubeChannel: youtubeConnected ? selectedYouTubeChannel || null : null,
        connectedKickUsername: kickConnectedUsername || null
      })
    });
    if (response.ok) {
      const data = await response.json();
      setProfile(data.profile);
      setSaved(true);
      setTimeout(() => setSaved(false), 3e3);
    } else {
      const data = await response.json();
      setError(data.error || "Save failed.");
    }
    setSaving(false);
  };
  const linkIdentity = async (provider) => {
    const normalizedProvider = provider.trim().toLowerCase();
    if (!normalizedProvider) return;
    setLinkingProvider(provider);
    setError("");
    try {
      const redirectTo = getClientAuthRedirectUrl(`/dashboard?view=settings&linked=${normalizedProvider}`);
      let oauthUrl;
      try {
        oauthUrl = await getIdentityLinkUrl(normalizedProvider, redirectTo);
      } catch (primaryError) {
        const alternateProvider = normalizedProvider === "custom:kick" ? "kick" : normalizedProvider === "kick" ? "custom:kick" : null;
        if (!alternateProvider) throw primaryError;
        oauthUrl = await getIdentityLinkUrl(alternateProvider, redirectTo);
      }
      sessionStorage.setItem("dashboard_return_tab", "settings");
      window.location.href = oauthUrl;
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to initiate OAuth linking.");
      setLinkingProvider(null);
    }
  };
  const isLinked = (provider) => {
    const normalizedProvider = provider.trim().toLowerCase();
    return user?.identities?.some((i) => String(i.provider || "").trim().toLowerCase() === normalizedProvider) ?? false;
  };
  const linkedIdentityProviders = (user?.identities || []).map((identity) => String(identity.provider || "").toLowerCase()).filter(Boolean);
  const checkUsername = (value) => {
    if (usernameDebounceRef.current) clearTimeout(usernameDebounceRef.current);
    const trimmed = value.trim();
    if (!trimmed || trimmed.toLowerCase() === String(profile?.display_name ?? "").trim().toLowerCase()) {
      setUsernameStatus("idle");
      setUsernameMessage("");
      return;
    }
    if (!/^[a-zA-Z0-9_-]{3,20}$/.test(trimmed)) {
      setUsernameStatus("invalid");
      setUsernameMessage("3\u201320 characters. Letters, numbers, underscores, hyphens only.");
      return;
    }
    setUsernameStatus("checking");
    setUsernameMessage("");
    usernameDebounceRef.current = setTimeout(() => {
      void (async () => {
        try {
          const res = await fetch(
            `/api/check-username?username=${encodeURIComponent(trimmed)}&currentEmail=${encodeURIComponent(member.email)}`
          );
          if (!res.ok) {
            setUsernameStatus("idle");
            setUsernameMessage("Could not verify availability right now.");
            return;
          }
          const data = await res.json();
          if (data.available === true) {
            setUsernameStatus("available");
            setUsernameMessage("Username is available!");
          } else {
            setUsernameStatus("taken");
            setUsernameMessage(data.reason || "Username is already taken.");
          }
        } catch {
          setUsernameStatus("idle");
          setUsernameMessage("");
        }
      })();
    }, 500);
  };
  const uploadAvatar = async (file) => {
    const maxSize = 8 * 1024 * 1024;
    const allowedTypes = /* @__PURE__ */ new Set(["image/jpeg", "image/png", "image/webp", "image/gif"]);
    if (file.size > maxSize) {
      setError("Image is too large. Maximum size is 8 MB.");
      return;
    }
    if (file.type && !allowedTypes.has(file.type)) {
      setError("Unsupported image type. Use JPG, PNG, WEBP, or GIF.");
      return;
    }
    setAvatarUploading(true);
    setError("");
    setSaved(false);
    try {
      const formData = new FormData();
      formData.append("file", file);
      const uploadResponse = await authedFetch("/api/profile-photo-upload", {
        method: "POST",
        body: formData
      });
      const uploadData = await uploadResponse.json();
      if (!uploadResponse.ok || !uploadData.url) {
        setError(uploadData.error || "Could not upload profile photo.");
        return;
      }
      const profileResponse = await authedFetch("/api/me/profile", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ avatarUrl: uploadData.url })
      });
      if (!profileResponse.ok) {
        const data = await profileResponse.json();
        setError(data.error || "Photo uploaded, but profile update failed.");
        setAvatarUrl(uploadData.url);
        return;
      }
      const profileData = await profileResponse.json();
      setProfile(profileData.profile);
      setAvatarUrl(profileData.profile.avatar_url || uploadData.url);
      setSaved(true);
      setTimeout(() => setSaved(false), 3e3);
    } catch {
      setError("Could not upload profile photo.");
    } finally {
      setAvatarUploading(false);
    }
  };
  if (loading) {
    return /* @__PURE__ */ jsxs9("div", { className: "flex items-center gap-2 text-zinc-400", children: [
      /* @__PURE__ */ jsx11(Loader23, { size: 16, className: "animate-spin" }),
      " Loading profile..."
    ] });
  }
  return /* @__PURE__ */ jsxs9("div", { className: "space-y-6", children: [
    /* @__PURE__ */ jsxs9("section", { className: "rounded-2xl border border-zinc-200/15 bg-zinc-900/60 p-5", children: [
      /* @__PURE__ */ jsxs9("div", { className: "mb-4 flex items-center gap-2", children: [
        /* @__PURE__ */ jsx11(User, { size: 16, className: "text-orange-200" }),
        /* @__PURE__ */ jsx11("h2", { className: "font-bold text-zinc-100", children: "Profile" })
      ] }),
      /* @__PURE__ */ jsxs9("div", { className: "grid gap-4 sm:grid-cols-2", children: [
        /* @__PURE__ */ jsxs9("div", { children: [
          /* @__PURE__ */ jsx11("label", { className: "mb-1.5 block text-xs font-medium text-zinc-400", children: "Username" }),
          /* @__PURE__ */ jsx11(
            "input",
            {
              type: "text",
              value: displayName,
              onChange: (e) => {
                setDisplayName(e.target.value);
                checkUsername(e.target.value);
              },
              maxLength: 20,
              placeholder: member.email.split("@")[0].slice(0, 20),
              autoComplete: "username",
              className: `w-full rounded-lg border bg-zinc-950/60 px-3 py-2 text-sm text-zinc-100 outline-none transition ${usernameStatus === "available" ? "border-emerald-400/60 focus:border-emerald-300" : usernameStatus === "taken" || usernameStatus === "invalid" ? "border-rose-400/60 focus:border-rose-300" : "border-zinc-200/20 focus:border-orange-200/70"}`
            }
          ),
          /* @__PURE__ */ jsx11("p", { className: "mt-0.5 text-xs text-zinc-500", children: "3\u201320 characters. Letters, numbers, _ and - only." }),
          usernameStatus === "checking" ? /* @__PURE__ */ jsx11("p", { className: "mt-0.5 text-xs text-zinc-400", children: "Checking availability..." }) : usernameMessage ? /* @__PURE__ */ jsx11("p", { className: `mt-0.5 text-xs ${usernameStatus === "available" ? "text-emerald-300" : "text-rose-300"}`, children: usernameMessage }) : null
        ] }),
        /* @__PURE__ */ jsxs9("div", { className: "sm:col-span-2", children: [
          /* @__PURE__ */ jsx11("label", { className: "mb-1.5 block text-xs font-medium text-zinc-400", children: "Profile Photo" }),
          /* @__PURE__ */ jsxs9("div", { className: "flex flex-wrap items-center gap-3 rounded-lg border border-zinc-200/20 bg-zinc-950/40 p-3", children: [
            avatarUrl ? /* @__PURE__ */ jsx11(
              "img",
              {
                src: avatarUrl,
                alt: "Avatar",
                className: "h-14 w-14 flex-shrink-0 rounded-full border border-zinc-200/20 object-cover"
              }
            ) : /* @__PURE__ */ jsx11("div", { className: "flex h-14 w-14 flex-shrink-0 items-center justify-center rounded-full border border-zinc-200/20 bg-zinc-800 text-xs text-zinc-500", children: member.email.slice(0, 2).toUpperCase() }),
            /* @__PURE__ */ jsxs9("div", { className: "flex-1", children: [
              /* @__PURE__ */ jsx11(
                "input",
                {
                  type: "file",
                  accept: "image/jpeg,image/png,image/webp,image/gif",
                  disabled: avatarUploading,
                  onChange: (e) => {
                    const file = e.target.files?.[0];
                    if (file) {
                      void uploadAvatar(file);
                    }
                    e.currentTarget.value = "";
                  },
                  className: "block w-full text-sm text-zinc-300 file:mr-3 file:rounded-md file:border-0 file:bg-orange-300 file:px-3 file:py-1.5 file:text-sm file:font-semibold file:text-zinc-950 hover:file:bg-orange-200 disabled:opacity-60"
                }
              ),
              /* @__PURE__ */ jsx11("p", { className: "mt-1 text-xs text-zinc-500", children: "Upload JPG, PNG, WEBP, or GIF (max 8 MB)." }),
              avatarUploading ? /* @__PURE__ */ jsx11("p", { className: "mt-1 text-xs text-zinc-400", children: "Uploading photo..." }) : null
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxs9("div", { className: "sm:col-span-2", children: [
          /* @__PURE__ */ jsx11("label", { className: "mb-1.5 block text-xs font-medium text-zinc-400", children: "Bio" }),
          /* @__PURE__ */ jsx11(
            "textarea",
            {
              value: bio,
              onChange: (e) => setBio(e.target.value),
              rows: 3,
              maxLength: 500,
              placeholder: "Tell the community who you are and what you do...",
              className: "w-full resize-none rounded-lg border border-zinc-200/20 bg-zinc-950/60 px-3 py-2 text-sm text-zinc-100 outline-none transition focus:border-orange-200/70"
            }
          ),
          /* @__PURE__ */ jsxs9("p", { className: "mt-0.5 text-right text-xs text-zinc-500", children: [
            bio.length,
            "/500"
          ] })
        ] }),
        /* @__PURE__ */ jsxs9("div", { className: "sm:col-span-2", children: [
          /* @__PURE__ */ jsxs9("label", { className: "mb-1.5 block text-xs font-medium text-zinc-400", children: [
            "Skills ",
            /* @__PURE__ */ jsx11("span", { className: "text-zinc-500", children: "(comma-separated)" })
          ] }),
          /* @__PURE__ */ jsx11(
            "input",
            {
              type: "text",
              value: skillsInput,
              onChange: (e) => setSkillsInput(e.target.value),
              placeholder: "Video editing, Mixing, Graphic design, Social media...",
              className: "w-full rounded-lg border border-zinc-200/20 bg-zinc-950/60 px-3 py-2 text-sm text-zinc-100 outline-none transition focus:border-orange-200/70"
            }
          ),
          skillsInput.trim() ? /* @__PURE__ */ jsx11("div", { className: "mt-2 flex flex-wrap gap-1.5", children: skillsInput.split(",").map((s) => s.trim()).filter(Boolean).map((skill) => /* @__PURE__ */ jsx11(
            "span",
            {
              className: "rounded-full border border-zinc-200/20 bg-zinc-800/60 px-2.5 py-0.5 text-xs text-zinc-300",
              children: skill
            },
            skill
          )) }) : null
        ] }),
        /* @__PURE__ */ jsxs9("div", { className: "sm:col-span-2", children: [
          /* @__PURE__ */ jsxs9("label", { className: "mb-1.5 block text-xs font-medium text-zinc-400", children: [
            "Livestream Sources ",
            /* @__PURE__ */ jsx11("span", { className: "text-zinc-500", children: "(from connected accounts)" })
          ] }),
          /* @__PURE__ */ jsxs9("div", { className: "space-y-3 rounded-lg border border-zinc-200/20 bg-zinc-950/40 p-3", children: [
            /* @__PURE__ */ jsxs9("div", { className: "rounded-lg border border-zinc-200/10 bg-zinc-900/50 p-3", children: [
              /* @__PURE__ */ jsx11("p", { className: "text-xs font-semibold uppercase tracking-wide text-zinc-400", children: "Kick" }),
              kickConnectedUrl ? /* @__PURE__ */ jsxs9("p", { className: "mt-1 text-sm text-zinc-200", children: [
                "Connected stream: ",
                /* @__PURE__ */ jsx11("a", { href: kickConnectedUrl, target: "_blank", rel: "noreferrer", className: "text-orange-200 underline", children: kickConnectedUrl })
              ] }) : /* @__PURE__ */ jsx11("p", { className: "mt-1 text-xs text-zinc-500", children: "No Kick account linked yet. Link your Kick account below to enable Kick streams." })
            ] }),
            /* @__PURE__ */ jsxs9("div", { className: "rounded-lg border border-zinc-200/10 bg-zinc-900/50 p-3", children: [
              /* @__PURE__ */ jsx11("p", { className: "text-xs font-semibold uppercase tracking-wide text-zinc-400", children: "YouTube" }),
              youtubeConnected ? /* @__PURE__ */ jsxs9(Fragment2, { children: [
                /* @__PURE__ */ jsx11("label", { className: "mt-2 block text-xs text-zinc-500", children: "Select the YouTube channel for your livestream profile" }),
                /* @__PURE__ */ jsx11(
                  "select",
                  {
                    value: selectedYouTubeChannel,
                    onChange: (e) => setSelectedYouTubeChannel(e.target.value),
                    className: "mt-1 w-full rounded-lg border border-zinc-200/20 bg-zinc-950/60 px-3 py-2 text-sm text-zinc-100 outline-none transition focus:border-orange-200/70",
                    children: youtubeOptions.length === 0 ? /* @__PURE__ */ jsx11("option", { value: "", children: "No channels detected from your Google connection" }) : youtubeOptions.map((option) => /* @__PURE__ */ jsx11("option", { value: option.key, children: option.label }, option.key))
                  }
                ),
                youtubeOptions.find((option) => option.key === selectedYouTubeChannel)?.url ? /* @__PURE__ */ jsxs9("p", { className: "mt-1 text-xs text-zinc-500", children: [
                  "Selected URL: ",
                  youtubeOptions.find((option) => option.key === selectedYouTubeChannel)?.url
                ] }) : null
              ] }) : /* @__PURE__ */ jsx11("p", { className: "mt-1 text-xs text-zinc-500", children: "No Google account linked yet. Link Google below to select a YouTube channel." })
            ] }),
            /* @__PURE__ */ jsx11("p", { className: "text-xs text-zinc-500", children: "Twitch will appear here automatically once you add the Twitch OAuth connection in Supabase." })
          ] })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxs9("section", { className: "rounded-2xl border border-zinc-200/15 bg-zinc-900/60 p-5", children: [
      /* @__PURE__ */ jsxs9("div", { className: "mb-1 flex items-center gap-2", children: [
        /* @__PURE__ */ jsx11(Link22, { size: 16, className: "text-orange-200" }),
        /* @__PURE__ */ jsx11("h2", { className: "font-bold text-zinc-100", children: "Linked Accounts" })
      ] }),
      /* @__PURE__ */ jsx11("p", { className: "mb-4 text-xs text-zinc-500", children: "Link your OAuth accounts to enable single sign-on and verify your identities." }),
      /* @__PURE__ */ jsxs9("div", { className: "space-y-2", children: [
        oauthProviders.map(({ key, label, description }) => {
          const linked = isLinked(key);
          return /* @__PURE__ */ jsxs9(
            "div",
            {
              className: "flex items-center justify-between rounded-xl border border-zinc-200/10 bg-zinc-800/40 px-4 py-3",
              children: [
                /* @__PURE__ */ jsxs9("div", { children: [
                  /* @__PURE__ */ jsx11("p", { className: "text-sm font-semibold text-zinc-100", children: label }),
                  /* @__PURE__ */ jsx11("p", { className: "text-xs text-zinc-500", children: description })
                ] }),
                linked ? /* @__PURE__ */ jsxs9("span", { className: "flex items-center gap-1.5 rounded-full border border-emerald-300/40 bg-emerald-300/5 px-3 py-1 text-xs font-semibold text-emerald-300", children: [
                  /* @__PURE__ */ jsx11(Check, { size: 11 }),
                  " Linked"
                ] }) : /* @__PURE__ */ jsxs9(
                  "button",
                  {
                    type: "button",
                    disabled: linkingProvider !== null,
                    onClick: () => {
                      void linkIdentity(key);
                    },
                    className: "inline-flex items-center gap-1.5 rounded-lg border border-zinc-200/25 px-3 py-1.5 text-xs font-semibold text-zinc-200 transition hover:border-orange-200/50 hover:text-orange-100 disabled:opacity-60",
                    children: [
                      linkingProvider === key ? /* @__PURE__ */ jsx11(Loader23, { size: 11, className: "animate-spin" }) : /* @__PURE__ */ jsx11(Link22, { size: 11 }),
                      linkingProvider === key ? "Connecting..." : "Link"
                    ]
                  }
                )
              ]
            },
            key
          );
        }),
        linkedIdentityProviders.length > 0 ? /* @__PURE__ */ jsxs9("div", { className: "rounded-xl border border-zinc-200/10 bg-zinc-800/30 px-4 py-3", children: [
          /* @__PURE__ */ jsx11("p", { className: "text-xs font-semibold uppercase tracking-wide text-zinc-400", children: "Currently linked via Supabase" }),
          /* @__PURE__ */ jsx11("p", { className: "mt-1 text-xs text-zinc-500", children: linkedIdentityProviders.join(", ") })
        ] }) : null
      ] })
    ] }),
    error ? /* @__PURE__ */ jsxs9("div", { className: "flex items-center gap-2 rounded-xl border border-rose-400/40 bg-rose-500/10 px-4 py-3 text-sm text-rose-200", children: [
      /* @__PURE__ */ jsx11(AlertCircle, { size: 16 }),
      " ",
      error
    ] }) : null,
    saved ? /* @__PURE__ */ jsxs9("div", { className: "flex items-center gap-2 rounded-xl border border-emerald-400/40 bg-emerald-500/10 px-4 py-3 text-sm text-emerald-200", children: [
      /* @__PURE__ */ jsx11(Check, { size: 16 }),
      " Profile saved successfully!"
    ] }) : null,
    /* @__PURE__ */ jsxs9(
      "button",
      {
        type: "button",
        onClick: () => {
          void handleSave();
        },
        disabled: saving,
        className: "inline-flex items-center gap-2 rounded-lg bg-orange-300 px-5 py-2.5 font-semibold text-zinc-950 transition hover:bg-orange-200 disabled:opacity-70",
        children: [
          saving ? /* @__PURE__ */ jsx11(Loader23, { size: 16, className: "animate-spin" }) : /* @__PURE__ */ jsx11(Save, { size: 16 }),
          saving ? "Saving..." : "Save Profile"
        ]
      }
    ),
    profile?.updated_at ? /* @__PURE__ */ jsxs9("p", { className: "text-xs text-zinc-500", children: [
      "Last updated ",
      new Date(profile.updated_at).toLocaleString()
    ] }) : null
  ] });
}
function getDashboardUsername(member) {
  const username = String(member?.user_metadata?.username || "").trim();
  const preferred = String(member?.user_metadata?.preferred_username || "").trim();
  const fromEmail = String(member?.email || "").split("@")[0].trim();
  return username || preferred || fromEmail || "Member";
}
function DashboardGate() {
  const location = useLocation();
  const navigate = useNavigate3();
  const [member, setMember] = useState8(null);
  const [ready, setReady] = useState8(false);
  const [error, setError] = useState8("");
  const [role, setRole] = useState8("user");
  const [actorRole, setActorRole] = useState8("user");
  const [viewingAs, setViewingAs] = useState8(null);
  const [permissions, setPermissions] = useState8([]);
  const [ban, setBan] = useState8(null);
  const [accessLoading, setAccessLoading] = useState8(true);
  useEffect7(() => {
    let mounted = true;
    if (isLocalRootSessionActive()) {
      setMember(getLocalRootUser());
      setRole("superadmin");
      setActorRole("superadmin");
      setPermissions(LOCAL_ROOT_PERMISSIONS);
      setAccessLoading(false);
      setReady(true);
      return () => {
        mounted = false;
      };
    }
    const supabase = getSupabaseBrowserClient();
    supabase.auth.getSession().then(({
      data
    }) => {
      if (!mounted) return;
      setMember(data.session?.user ?? null);
      setReady(true);
    }).catch(() => {
      if (!mounted) return;
      setReady(true);
    });
    const {
      data: {
        subscription
      }
    } = supabase.auth.onAuthStateChange((_event, session) => {
      setMember(session?.user ?? null);
      setReady(true);
      setError("");
    });
    return () => {
      mounted = false;
      subscription.unsubscribe();
    };
  }, []);
  useEffect7(() => {
    if (isLocalRootSessionActive()) {
      setAccessLoading(false);
      return;
    }
    if (!member) {
      setAccessLoading(false);
      return;
    }
    void (async () => {
      try {
        const response = await authedFetch("/api/me/access");
        if (!response.ok) {
          setAccessLoading(false);
          return;
        }
        const access = await response.json();
        setRole(access.role);
        setActorRole(access.actorRole || access.role);
        setViewingAs(access.viewingAs || null);
        setPermissions(access.permissions || []);
        setBan(access.ban || null);
      } catch {
      } finally {
        setAccessLoading(false);
      }
    })();
  }, [member]);
  const handleLogout = async () => {
    try {
      setStoredViewAsRole(null);
      if (isLocalRootSessionActive()) {
        endLocalRootSession();
        void navigate({
          to: "/login"
        });
        return;
      }
      const supabase = getSupabaseBrowserClient();
      const {
        error: error2
      } = await supabase.auth.signOut();
      if (error2) throw error2;
    } catch {
      setError("Could not log out. Please refresh and try again.");
    }
  };
  if (!ready) {
    return /* @__PURE__ */ jsx11("div", { className: "min-h-screen px-4 py-24 text-zinc-100", children: /* @__PURE__ */ jsxs9("div", { className: "mx-auto max-w-4xl rounded-2xl border border-zinc-200/15 bg-zinc-900/60 p-8 text-center", children: [
      /* @__PURE__ */ jsx11("p", { className: "text-sm uppercase tracking-[0.2em] text-zinc-400", children: "Checking membership status" }),
      /* @__PURE__ */ jsx11("h1", { className: "mt-4 text-3xl font-bold text-zinc-50", children: "Preparing your access..." })
    ] }) });
  }
  if (accessLoading) {
    return /* @__PURE__ */ jsx11("div", { className: "min-h-screen px-4 py-24 text-zinc-100", children: /* @__PURE__ */ jsxs9("div", { className: "mx-auto max-w-4xl rounded-2xl border border-zinc-200/15 bg-zinc-900/60 p-8 text-center", children: [
      /* @__PURE__ */ jsx11("p", { className: "text-sm uppercase tracking-[0.2em] text-zinc-400", children: "Loading permissions" }),
      /* @__PURE__ */ jsx11("h1", { className: "mt-4 text-3xl font-bold text-zinc-50", children: "Preparing your function access..." })
    ] }) });
  }
  if (!member) {
    void navigate({
      to: "/login"
    });
    return null;
  }
  if (location.pathname.startsWith("/dashboard/tools/")) {
    return /* @__PURE__ */ jsx11(Outlet, {});
  }
  return /* @__PURE__ */ jsx11(CreatorDashboard, { member, onLogout: handleLogout, role, actorRole, viewingAs, permissions, ban });
}
function CreatorDashboard({
  member,
  onLogout,
  role,
  actorRole,
  viewingAs,
  permissions,
  ban
}) {
  const [dashboardTab, setDashboardTab] = useState8("motd");
  useEffect7(() => {
    const params = new URLSearchParams(window.location.search);
    const viewParam = params.get("view");
    const storedTab = sessionStorage.getItem("dashboard_return_tab");
    sessionStorage.removeItem("dashboard_return_tab");
    const tab = viewParam || storedTab;
    if (tab === "settings" || tab === "news" || tab === "workspace" || tab === "motd") {
      setDashboardTab(tab);
    }
  }, []);
  const [latestNews, setLatestNews] = useState8([]);
  const [newsLoading, setNewsLoading] = useState8(false);
  const [plans, setPlans] = useState8(fallbackMembershipPlans);
  const [plansLoading, setPlansLoading] = useState8(true);
  const [upgradingPlan, setUpgradingPlan] = useState8(null);
  const [subscriptionError, setSubscriptionError] = useState8("");
  const [memberAvatarUrl, setMemberAvatarUrl] = useState8(null);
  const isSuperadmin = role === "superadmin";
  const canUseViewAs = actorRole === "superadmin" || canManageRole(actorRole, "user");
  const selectableRoles = ["admin", "manager", "staff", "moderator", "helper", "user", "banned"].filter((candidate) => {
    if (actorRole === "superadmin") return true;
    return canManageRole(actorRole, candidate);
  });
  const hasPermission = (permission) => {
    if (isSuperadmin) return true;
    return permissions.includes(permission);
  };
  const dashboardFunctions = [{
    icon: /* @__PURE__ */ jsx11(Megaphone, { size: 18 }),
    toolKey: "bulletin-board",
    title: "Bulletin Board",
    description: "Post launches, promotions, and collaboration requests to keep your team and peers aligned.",
    items: ["Announcement drafts", "Pinned growth opportunities", "Deadline reminders"],
    requiredPermission: "view_creator_tools"
  }, {
    icon: /* @__PURE__ */ jsx11(CalendarDays, { size: 18 }),
    toolKey: "content-calendar",
    title: "Content Calendar",
    description: "Plan videos, newsletters, social campaigns, and product drops across a weekly cadence.",
    items: ["Publishing cadence", "Campaign timeline", "Cross-platform sync"],
    requiredPermission: "view_creator_tools"
  }, {
    icon: /* @__PURE__ */ jsx11(DollarSign, { size: 18 }),
    toolKey: "revenue-tracker",
    title: "Revenue Tracker",
    description: "Track recurring income streams and monitor which offers convert best every month.",
    items: ["Membership revenue", "Funnel outcomes", "Offer performance"],
    requiredPermission: "view_revenue_tracker"
  }, {
    icon: /* @__PURE__ */ jsx11(ClipboardList, { size: 18 }),
    toolKey: "creator-task-board",
    title: "Creator Task Board",
    description: "Break goals into weekly sprint tasks and keep momentum with clear priorities.",
    items: ["This-week priorities", "Pending reviews", "Automation backlog"],
    requiredPermission: "view_creator_tools"
  }, {
    icon: /* @__PURE__ */ jsx11(Users2, { size: 18 }),
    toolKey: "collaboration-hub",
    title: "Collaboration Hub",
    description: "Coordinate partner campaigns, joint launches, and audience growth collaborations.",
    items: ["Partner shortlist", "Joint launch plans", "Shared asset links"],
    requiredPermission: "view_creator_tools"
  }, {
    icon: /* @__PURE__ */ jsx11(NotebookPen, { size: 18 }),
    toolKey: "knowledge-vault",
    title: "Knowledge Vault",
    description: "Store swipe files, scripts, hooks, and reusable frameworks for repeatable execution.",
    items: ["Best-performing hooks", "Marketing scripts", "Template library"],
    requiredPermission: "view_creator_tools"
  }, {
    icon: /* @__PURE__ */ jsx11(Radio, { size: 18 }),
    toolKey: "promotion-hub",
    title: "Promotion Hub",
    description: "Compose and schedule posts to Kick, Twitch, X, Instagram, and Threads from one place.",
    items: ["Write once, post anywhere", "Schedule your queue", "Platform-tailored previews"],
    requiredPermission: "view_creator_tools"
  }, {
    icon: /* @__PURE__ */ jsx11(Store, { size: 18 }),
    toolKey: "merch-studio",
    title: "Merch Studio",
    description: "Submit your merch mockups, track admin review status, and monitor your earnings splits.",
    items: ["Design submissions", "Approval status", "Earnings & payouts"],
    requiredPermission: "view_merch"
  }, {
    icon: /* @__PURE__ */ jsx11(Target, { size: 18 }),
    toolKey: "creator-growth-system",
    title: "Creator Growth System",
    description: "Build and track your creator operating system across 5 modules: broadcast, hub, monetization, distribution, and operations.",
    items: ["Creator System Score", "5-module checklist", "Next action guidance"],
    requiredPermission: "view_creator_tools"
  }];
  const visibleFunctions = dashboardFunctions.filter((fn) => hasPermission(fn.requiredPermission));
  const dashboardDisplayName = getDashboardUsername(member);
  useEffect7(() => {
    if (isLocalRootSessionActive()) return;
    void (async () => {
      try {
        const response = await authedFetch("/api/me/profile");
        if (!response.ok) return;
        const data = await response.json();
        setMemberAvatarUrl(data.profile?.avatar_url || null);
      } catch {
      }
    })();
  }, []);
  useEffect7(() => {
    if (isLocalRootSessionActive()) {
      setPlansLoading(false);
      return;
    }
    void (async () => {
      try {
        const response = await fetch("/api/shop");
        if (!response.ok) return;
        const data = await response.json();
        if (data.membershipPlans?.length) setPlans(data.membershipPlans);
      } catch {
      } finally {
        setPlansLoading(false);
      }
    })();
  }, []);
  useEffect7(() => {
    if (isLocalRootSessionActive()) {
      setLatestNews([]);
      setNewsLoading(false);
      return;
    }
    void (async () => {
      setNewsLoading(true);
      try {
        const response = await fetch("/api/news");
        if (!response.ok) return;
        const data = await response.json();
        setLatestNews(Array.isArray(data) ? data.slice(0, 5) : []);
      } catch {
        setLatestNews([]);
      } finally {
        setNewsLoading(false);
      }
    })();
  }, []);
  if (role === "banned") {
    return /* @__PURE__ */ jsx11(BannedDashboard, { member, onLogout, ban });
  }
  const applyViewAs = (targetRole) => {
    if (!canUseViewAs) return;
    setStoredViewAsRole(targetRole ? targetRole : null);
    if (typeof window !== "undefined") {
      window.location.reload();
    }
  };
  const updateMembership = async (plan) => {
    const email = String(member?.email || "").trim().toLowerCase();
    if (!email) {
      setSubscriptionError("Missing account email. Please refresh and try again.");
      return;
    }
    try {
      setUpgradingPlan(plan.slug);
      setSubscriptionError("");
      const response = await authedFetch("/api/create-payment-intent", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          planSlug: plan.slug,
          email,
          name: getDashboardUsername(member)
        })
      });
      const data = await response.json();
      if (!response.ok || data.error) {
        setSubscriptionError(data.error || "Could not update your subscription right now.");
        return;
      }
      if (data.checkoutUrl) {
        window.location.href = data.checkoutUrl;
        return;
      }
      if (data.successUrl) {
        window.location.href = data.successUrl;
        return;
      }
      if (data.updated || data.free) {
        window.location.reload();
      }
    } catch {
      setSubscriptionError("Could not update your subscription right now.");
    } finally {
      setUpgradingPlan(null);
    }
  };
  return /* @__PURE__ */ jsx11("div", { className: "min-h-screen px-4 py-12 text-zinc-100", children: /* @__PURE__ */ jsxs9("div", { className: "mx-auto max-w-6xl", children: [
    /* @__PURE__ */ jsxs9("header", { className: "rounded-2xl border border-zinc-200/15 bg-zinc-900/60 p-6 md:p-8", children: [
      /* @__PURE__ */ jsx11("div", { className: "flex flex-wrap items-center justify-between gap-4", children: /* @__PURE__ */ jsxs9("div", { children: [
        /* @__PURE__ */ jsxs9("div", { className: "flex items-center gap-4", children: [
          memberAvatarUrl ? /* @__PURE__ */ jsx11("img", { src: memberAvatarUrl, alt: dashboardDisplayName, className: "h-16 w-16 flex-shrink-0 rounded-full border border-zinc-200/20 object-cover" }) : /* @__PURE__ */ jsx11("div", { className: "flex h-16 w-16 flex-shrink-0 items-center justify-center rounded-full border border-zinc-200/20 bg-zinc-800 text-xl font-bold text-zinc-400", children: dashboardDisplayName.slice(0, 1).toUpperCase() }),
          /* @__PURE__ */ jsxs9("div", { children: [
            /* @__PURE__ */ jsx11("p", { className: "text-xs font-semibold uppercase tracking-[0.2em] text-zinc-400", children: "Organization Dashboard" }),
            /* @__PURE__ */ jsxs9("h1", { className: "mt-1 text-3xl font-black text-zinc-50 md:text-4xl", children: [
              "Welcome back, ",
              dashboardDisplayName
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsx11("p", { className: "mt-3 max-w-2xl text-zinc-300", children: "Run your creator pipeline, marketing campaigns, and entrepreneurial execution with a focused operating system." }),
        /* @__PURE__ */ jsxs9("div", { className: "mt-4 flex flex-wrap gap-2 text-xs", children: [
          /* @__PURE__ */ jsxs9("span", { className: "rounded-full border border-zinc-500/40 px-3 py-1 uppercase tracking-wide text-zinc-300", children: [
            "Role: ",
            formatRoleLabel(role)
          ] }),
          viewingAs ? /* @__PURE__ */ jsxs9("span", { className: "rounded-full border border-rose-400/60 px-3 py-1 uppercase tracking-wide text-rose-200", children: [
            "Viewing As: ",
            formatRoleLabel(viewingAs)
          ] }) : null,
          isSuperadmin ? /* @__PURE__ */ jsx11("span", { className: "rounded-full border border-orange-300/60 px-3 py-1 uppercase tracking-wide text-orange-100", children: "Full Access" }) : null
        ] }),
        canUseViewAs ? /* @__PURE__ */ jsxs9("div", { className: "mt-4 max-w-sm rounded-xl border border-rose-400/35 bg-rose-500/10 p-3", children: [
          /* @__PURE__ */ jsx11("p", { className: "text-xs font-semibold uppercase tracking-[0.2em] text-rose-200", children: "View As Mode" }),
          /* @__PURE__ */ jsxs9("div", { className: "mt-2 flex items-center gap-2", children: [
            /* @__PURE__ */ jsxs9("select", { value: viewingAs || "", onChange: (event) => applyViewAs(event.target.value), className: "w-full rounded-lg border border-rose-300/35 bg-zinc-950/60 px-3 py-2 text-sm text-zinc-100 outline-none transition focus:border-rose-200", children: [
              /* @__PURE__ */ jsx11("option", { value: "", children: "Off (your role)" }),
              selectableRoles.map((previewRole) => /* @__PURE__ */ jsx11("option", { value: previewRole, children: formatRoleLabel(previewRole) }, previewRole))
            ] }),
            viewingAs ? /* @__PURE__ */ jsx11("button", { type: "button", onClick: () => applyViewAs(""), className: "rounded-lg border border-rose-300/45 px-3 py-2 text-xs font-semibold uppercase tracking-wide text-rose-100 transition hover:border-rose-200", children: "Reset" }) : null
          ] })
        ] }) : null
      ] }) }),
      /* @__PURE__ */ jsxs9("div", { className: "mt-6 border-t border-zinc-200/10 pt-4", children: [
        /* @__PURE__ */ jsx11("p", { className: "mb-3 text-[11px] font-semibold uppercase tracking-[0.16em] text-zinc-500", children: "Dashboard Sections" }),
        /* @__PURE__ */ jsx11("div", { className: "-mx-1 overflow-x-auto px-1", children: /* @__PURE__ */ jsxs9("div", { className: "flex min-w-max gap-1 rounded-xl border border-zinc-200/15 bg-zinc-900/60 p-1", children: [
          /* @__PURE__ */ jsxs9("button", { type: "button", onClick: () => setDashboardTab("motd"), className: `flex items-center gap-2 rounded-lg px-4 py-2 text-sm font-semibold transition ${dashboardTab === "motd" ? "bg-orange-300 text-zinc-950" : "text-zinc-300 hover:text-zinc-50"}`, children: [
            /* @__PURE__ */ jsx11(Megaphone, { size: 15 }),
            "MOTD"
          ] }),
          /* @__PURE__ */ jsxs9("button", { type: "button", onClick: () => setDashboardTab("news"), className: `flex items-center gap-2 rounded-lg px-4 py-2 text-sm font-semibold transition ${dashboardTab === "news" ? "bg-orange-300 text-zinc-950" : "text-zinc-300 hover:text-zinc-50"}`, children: [
            /* @__PURE__ */ jsx11(Newspaper, { size: 15 }),
            "Latest News"
          ] }),
          /* @__PURE__ */ jsxs9("button", { type: "button", onClick: () => setDashboardTab("workspace"), className: `flex items-center gap-2 rounded-lg px-4 py-2 text-sm font-semibold transition ${dashboardTab === "workspace" ? "bg-orange-300 text-zinc-950" : "text-zinc-300 hover:text-zinc-50"}`, children: [
            /* @__PURE__ */ jsx11(LayoutDashboard, { size: 15 }),
            "Workspace"
          ] }),
          /* @__PURE__ */ jsxs9("button", { type: "button", onClick: () => setDashboardTab("settings"), className: `flex items-center gap-2 rounded-lg px-4 py-2 text-sm font-semibold transition ${dashboardTab === "settings" ? "bg-orange-300 text-zinc-950" : "text-zinc-300 hover:text-zinc-50"}`, children: [
            /* @__PURE__ */ jsx11(Settings, { size: 15 }),
            "Settings"
          ] }),
          hasPermission("access_admin_dashboard") && /* @__PURE__ */ jsxs9(Link5, { to: "/admin", className: "flex items-center gap-2 rounded-lg px-4 py-2 text-sm font-semibold text-zinc-300 transition hover:text-zinc-50", children: [
            /* @__PURE__ */ jsx11(Shield, { size: 15 }),
            "Admin"
          ] })
        ] }) })
      ] })
    ] }),
    dashboardTab === "motd" ? /* @__PURE__ */ jsx11("section", { className: "mt-6", children: /* @__PURE__ */ jsxs9("article", { className: "rounded-2xl border border-zinc-200/15 bg-zinc-900/60 p-6", children: [
      /* @__PURE__ */ jsx11("p", { className: "text-xs font-semibold uppercase tracking-[0.2em] text-zinc-400", children: "MOTD" }),
      /* @__PURE__ */ jsx11("h2", { className: "mt-2 text-2xl font-bold text-zinc-50", children: "Build momentum today" }),
      /* @__PURE__ */ jsx11("p", { className: "mt-3 max-w-3xl text-zinc-300", children: "Ship one meaningful piece of content, complete one revenue task, and check in with one collaborator before your day ends." })
    ] }) }) : null,
    dashboardTab === "news" ? /* @__PURE__ */ jsxs9("section", { className: "mt-6 space-y-4", children: [
      /* @__PURE__ */ jsxs9("div", { children: [
        /* @__PURE__ */ jsx11("h2", { className: "text-2xl font-bold text-zinc-50", children: "Latest News" }),
        /* @__PURE__ */ jsx11("p", { className: "mt-1 text-sm text-zinc-300", children: "Recent organization announcements and updates." })
      ] }),
      newsLoading ? /* @__PURE__ */ jsx11("p", { className: "text-sm text-zinc-300", children: "Loading latest news..." }) : null,
      !newsLoading && latestNews.length === 0 ? /* @__PURE__ */ jsxs9("article", { className: "rounded-2xl border border-zinc-200/15 bg-zinc-900/60 p-5", children: [
        /* @__PURE__ */ jsx11("h3", { className: "text-lg font-semibold text-zinc-50", children: "No news posted yet" }),
        /* @__PURE__ */ jsx11("p", { className: "mt-2 text-sm text-zinc-300", children: "Announcements will appear here as soon as staff publishes updates." })
      ] }) : null,
      /* @__PURE__ */ jsx11("div", { className: "space-y-3", children: latestNews.map((post) => /* @__PURE__ */ jsxs9("article", { className: "rounded-2xl border border-zinc-200/15 bg-zinc-900/60 p-5", children: [
        /* @__PURE__ */ jsx11("h3", { className: "text-lg font-semibold text-zinc-50", children: post.title }),
        /* @__PURE__ */ jsxs9("p", { className: "mt-1 text-xs text-zinc-400", children: [
          post.author ? `By ${post.author}` : "W.A.G.E. Society",
          " \xB7 ",
          new Date(post.created_at).toLocaleString()
        ] }),
        /* @__PURE__ */ jsx11("p", { className: "mt-3 whitespace-pre-line text-sm leading-relaxed text-zinc-300", children: post.body })
      ] }, post.id)) })
    ] }) : null,
    dashboardTab === "workspace" ? /* @__PURE__ */ jsxs9("section", { className: "mt-6", children: [
      /* @__PURE__ */ jsxs9("div", { className: "mb-4", children: [
        /* @__PURE__ */ jsx11("h2", { className: "text-2xl font-bold text-zinc-50", children: "Workspace" }),
        /* @__PURE__ */ jsx11("p", { className: "mt-1 text-sm text-zinc-300", children: "Your assigned creator modules are listed below." })
      ] }),
      /* @__PURE__ */ jsxs9("div", { className: "grid gap-5 md:grid-cols-2 lg:grid-cols-3", children: [
        visibleFunctions.map((fn) => /* @__PURE__ */ jsx11(ResourceCard, { icon: fn.icon, toolKey: fn.toolKey, title: fn.title, description: fn.description, items: fn.items }, fn.title)),
        !visibleFunctions.length ? /* @__PURE__ */ jsxs9("article", { className: "rounded-2xl border border-zinc-200/15 bg-zinc-900/60 p-5 md:col-span-2 lg:col-span-3", children: [
          /* @__PURE__ */ jsx11("h2", { className: "text-xl font-bold text-zinc-50", children: "No Functions Assigned Yet" }),
          /* @__PURE__ */ jsx11("p", { className: "mt-2 text-sm text-zinc-300", children: "Your account has no dashboard functions enabled yet. Ask an admin or superadmin to grant permissions." })
        ] }) : null
      ] })
    ] }) : null,
    dashboardTab === "settings" ? /* @__PURE__ */ jsxs9("section", { className: "mt-6 space-y-6", children: [
      /* @__PURE__ */ jsx11(ProfileSettings, { member }),
      /* @__PURE__ */ jsxs9("div", { className: "grid gap-6 md:grid-cols-2", children: [
        /* @__PURE__ */ jsxs9("article", { className: "rounded-2xl border border-zinc-200/15 bg-zinc-900/60 p-6", children: [
          /* @__PURE__ */ jsxs9("div", { className: "flex items-center gap-3", children: [
            /* @__PURE__ */ jsx11("div", { className: "inline-flex rounded-md border border-zinc-200/20 bg-zinc-950/70 p-2 text-orange-200", children: /* @__PURE__ */ jsx11(CreditCard, { size: 18 }) }),
            /* @__PURE__ */ jsxs9("div", { children: [
              /* @__PURE__ */ jsx11("h2", { className: "text-lg font-bold text-zinc-50", children: "Subscription" }),
              /* @__PURE__ */ jsx11("p", { className: "text-xs text-zinc-400", children: "Manage your membership plan" })
            ] })
          ] }),
          plansLoading ? /* @__PURE__ */ jsx11("p", { className: "mt-4 text-sm text-zinc-400", children: "Loading plans..." }) : /* @__PURE__ */ jsx11("div", { className: "mt-4 space-y-2", children: plans.map((plan) => {
            const isCurrent = member.user_metadata?.membership_plan === plan.slug || plan.slug === "free" && !member.user_metadata?.membership_plan;
            return /* @__PURE__ */ jsxs9("div", { className: `rounded-xl border p-4 transition ${isCurrent ? "border-orange-200/60 bg-orange-200/10" : "border-zinc-200/15 bg-zinc-950/40"}`, children: [
              /* @__PURE__ */ jsxs9("div", { className: "flex items-center justify-between gap-3", children: [
                /* @__PURE__ */ jsxs9("div", { className: "min-w-0", children: [
                  /* @__PURE__ */ jsxs9("div", { className: "flex items-center gap-2", children: [
                    /* @__PURE__ */ jsx11("p", { className: "font-semibold text-zinc-50", children: plan.name }),
                    isCurrent ? /* @__PURE__ */ jsx11("span", { className: "rounded-full bg-orange-300 px-2 py-0.5 text-xs font-bold text-zinc-950", children: "Current" }) : null
                  ] }),
                  /* @__PURE__ */ jsx11("p", { className: "text-sm font-black text-orange-200", children: plan.display_price }),
                  /* @__PURE__ */ jsx11("p", { className: "mt-0.5 text-xs text-zinc-400", children: plan.description })
                ] }),
                !isCurrent ? /* @__PURE__ */ jsx11("button", { type: "button", onClick: () => {
                  void updateMembership(plan);
                }, disabled: Boolean(upgradingPlan), className: "flex-shrink-0 rounded-lg border border-zinc-100/25 px-3 py-1.5 text-xs font-semibold text-zinc-300 transition hover:border-orange-200/70 hover:text-orange-100 disabled:cursor-not-allowed disabled:opacity-60", children: upgradingPlan === plan.slug ? "Processing..." : plan.slug === "free" ? "Downgrade" : "Choose Plan" }) : null
              ] }),
              plan.features.length > 0 ? /* @__PURE__ */ jsx11("ul", { className: "mt-2 flex flex-wrap gap-x-3 gap-y-0.5", children: plan.features.map((feature) => /* @__PURE__ */ jsxs9("li", { className: "flex items-center gap-1 text-xs text-zinc-400", children: [
                /* @__PURE__ */ jsx11("span", { className: "text-orange-300", children: "*" }),
                " ",
                feature
              ] }, feature)) }) : null
            ] }, plan.slug);
          }) }),
          subscriptionError ? /* @__PURE__ */ jsx11("p", { className: "mt-3 rounded-lg border border-rose-400/40 bg-rose-500/10 px-3 py-2 text-xs text-rose-200", children: subscriptionError }) : null,
          /* @__PURE__ */ jsx11("p", { className: "mt-3 text-xs text-zinc-500", children: "Payments are processed securely via Stripe. Cancel anytime from your billing settings." })
        ] }),
        /* @__PURE__ */ jsxs9("article", { className: "rounded-2xl border border-zinc-200/15 bg-zinc-900/60 p-6", children: [
          /* @__PURE__ */ jsxs9("div", { className: "flex items-center gap-3", children: [
            /* @__PURE__ */ jsx11("div", { className: "inline-flex rounded-md border border-zinc-200/20 bg-zinc-950/70 p-2 text-orange-200", children: /* @__PURE__ */ jsx11(Settings, { size: 18 }) }),
            /* @__PURE__ */ jsxs9("div", { children: [
              /* @__PURE__ */ jsx11("h2", { className: "text-lg font-bold text-zinc-50", children: "Account" }),
              /* @__PURE__ */ jsx11("p", { className: "text-xs text-zinc-400", children: "Your profile and sign-in details" })
            ] })
          ] }),
          /* @__PURE__ */ jsxs9("div", { className: "mt-4 rounded-xl border border-zinc-200/15 bg-zinc-950/60 p-4 space-y-2", children: [
            memberAvatarUrl ? /* @__PURE__ */ jsxs9("div", { className: "flex items-center gap-3", children: [
              /* @__PURE__ */ jsx11("img", { src: memberAvatarUrl, alt: getDashboardUsername(member), className: "h-12 w-12 rounded-full border border-zinc-200/20 object-cover" }),
              /* @__PURE__ */ jsxs9("p", { className: "text-xs text-zinc-500", children: [
                "Change your photo in",
                " ",
                /* @__PURE__ */ jsx11("button", { type: "button", onClick: () => setDashboardTab("settings"), className: "text-orange-200 underline hover:text-orange-100", children: "Profile Settings" })
              ] })
            ] }) : null,
            /* @__PURE__ */ jsxs9("div", { children: [
              /* @__PURE__ */ jsx11("p", { className: "text-xs font-medium text-zinc-400", children: "Email" }),
              /* @__PURE__ */ jsx11("p", { className: "mt-0.5 text-sm text-zinc-100", children: member.email || "\u2014" })
            ] }),
            /* @__PURE__ */ jsxs9("div", { children: [
              /* @__PURE__ */ jsx11("p", { className: "text-xs font-medium text-zinc-400", children: "Username" }),
              /* @__PURE__ */ jsx11("p", { className: "mt-0.5 text-sm text-zinc-100", children: getDashboardUsername(member) })
            ] }),
            /* @__PURE__ */ jsxs9("div", { children: [
              /* @__PURE__ */ jsx11("p", { className: "text-xs font-medium text-zinc-400", children: "Role" }),
              /* @__PURE__ */ jsx11("p", { className: "mt-0.5 text-sm text-zinc-100", children: formatRoleLabel(role) })
            ] })
          ] }),
          /* @__PURE__ */ jsx11("p", { className: "mt-4 text-xs text-zinc-500", children: "To update your email or password, contact an admin or use the password reset flow." })
        ] })
      ] })
    ] }) : null
  ] }) });
}
function BannedDashboard({
  member,
  onLogout,
  ban
}) {
  const bannedUntilLabel = ban?.bannedUntil ? new Date(ban.bannedUntil).toLocaleString() : "Forever";
  return /* @__PURE__ */ jsx11("div", { className: "min-h-screen px-4 py-12 text-zinc-100", children: /* @__PURE__ */ jsxs9("div", { className: "mx-auto max-w-4xl rounded-2xl border border-rose-400/30 bg-rose-500/10 p-6 md:p-8", children: [
    /* @__PURE__ */ jsx11("p", { className: "text-xs font-semibold uppercase tracking-[0.2em] text-rose-200", children: "Account Restricted" }),
    /* @__PURE__ */ jsx11("h1", { className: "mt-3 text-3xl font-black text-zinc-50 md:text-4xl", children: "You are currently banned" }),
    /* @__PURE__ */ jsxs9("p", { className: "mt-4 text-base leading-relaxed text-zinc-200", children: [
      member.email || "This account",
      " was banned by ",
      ban?.bannedBy || "an administrator",
      " for",
      " ",
      ban?.banReason || "a policy violation",
      " until ",
      bannedUntilLabel,
      ". Click here to",
      " ",
      /* @__PURE__ */ jsx11(Link5, { to: "/appeals", className: "font-semibold text-rose-100 underline underline-offset-4 transition hover:text-white", children: "appeal" }),
      "."
    ] }),
    /* @__PURE__ */ jsxs9("div", { className: "mt-6 flex flex-wrap gap-3", children: [
      /* @__PURE__ */ jsx11(Link5, { to: "/dashboard", className: "rounded-lg border border-zinc-100/25 px-4 py-2 text-sm font-semibold text-zinc-100 transition hover:border-rose-200/70 hover:text-rose-100", children: "Return Home" }),
      /* @__PURE__ */ jsx11("button", { type: "button", onClick: () => {
        void onLogout();
      }, className: "rounded-lg border border-zinc-100/25 px-4 py-2 text-sm font-semibold text-zinc-100 transition hover:border-rose-200/70 hover:text-rose-100", children: "Logout" })
    ] })
  ] }) });
}
function ResourceCard({
  icon,
  toolKey,
  title,
  description,
  items
}) {
  const navigate = useNavigate3();
  return /* @__PURE__ */ jsx11("button", { type: "button", onClick: () => {
    void navigate({
      to: "/dashboard/tools/$tool",
      params: {
        tool: toolKey
      }
    });
  }, className: "group block w-full rounded-2xl border border-zinc-200/15 bg-zinc-900/60 p-5 text-left transition hover:border-orange-300/50", children: /* @__PURE__ */ jsxs9("article", { children: [
    /* @__PURE__ */ jsx11("div", { className: "mb-3 inline-flex rounded-md border border-zinc-200/20 bg-zinc-950/70 p-2 text-orange-200", children: icon }),
    /* @__PURE__ */ jsx11("h2", { className: "text-xl font-bold text-zinc-50 group-hover:text-orange-100", children: title }),
    /* @__PURE__ */ jsx11("p", { className: "mt-2 text-sm leading-relaxed text-zinc-300", children: description }),
    /* @__PURE__ */ jsx11("ul", { className: "mt-4 space-y-2 text-sm text-zinc-200", children: items.map((item) => /* @__PURE__ */ jsxs9("li", { className: "flex gap-2", children: [
      /* @__PURE__ */ jsx11("span", { className: "text-orange-200", children: "*" }),
      /* @__PURE__ */ jsx11("span", { children: item })
    ] }, item)) })
  ] }) });
}
var FALLBACK_OAUTH_PROVIDERS, LOCAL_ROOT_PERMISSIONS, fallbackMembershipPlans;
var init_dashboard_BD7PNkS0 = __esm({
  "dist/server/assets/dashboard-BD7PNkS0.js"() {
    "use strict";
    init_router_BDBFyAOM();
    FALLBACK_OAUTH_PROVIDERS = [
      { key: "discord", label: "Discord", description: "Link your Discord account" },
      { key: "google", label: "Google / YouTube", description: "Link your Google account" },
      { key: "custom:kick", label: "Kick", description: "Link your Kick account" },
      { key: "apple", label: "Apple", description: "Link your Apple account" },
      { key: "facebook", label: "Facebook", description: "Link your Facebook account" }
    ];
    LOCAL_ROOT_PERMISSIONS = ["view_dashboard", "view_creator_tools", "view_revenue_tracker", "view_live_streams", "use_autoclipper", "manage_livestreams", "view_merch", "manage_users", "manage_permissions", "access_admin_dashboard"];
    fallbackMembershipPlans = [{
      id: "fallback-free",
      slug: "free",
      name: "FREE",
      display_price: "$0",
      description: "Very limited access for basic account setup and browsing.",
      features: ["Log in and account access", "Connect social/OAuth accounts", "Browse public sections"]
    }];
  }
});

// dist/server/assets/appeals-BbY3GHSm.js
var appeals_BbY3GHSm_exports = {};
__export(appeals_BbY3GHSm_exports, {
  component: () => AppealsPage
});
import { jsx as jsx12, jsxs as jsxs10 } from "react/jsx-runtime";
import { Link as Link6 } from "@tanstack/react-router";
function AppealsPage() {
  return /* @__PURE__ */ jsx12("div", { className: "min-h-screen px-4 py-12 text-zinc-100", children: /* @__PURE__ */ jsxs10("div", { className: "mx-auto max-w-3xl rounded-2xl border border-zinc-200/15 bg-zinc-900/60 p-6 md:p-8", children: [
    /* @__PURE__ */ jsx12("p", { className: "text-xs font-semibold uppercase tracking-[0.2em] text-zinc-400", children: "Access Appeal" }),
    /* @__PURE__ */ jsx12("h1", { className: "mt-3 text-3xl font-black text-zinc-50 md:text-4xl", children: "Request a ban review" }),
    /* @__PURE__ */ jsx12("p", { className: "mt-4 text-base leading-relaxed text-zinc-300", children: "If you believe your restriction was issued in error, send an appeal with your account email, the context behind the incident, and any supporting evidence. Appeals should be reviewed by an administrator or superadmin." }),
    /* @__PURE__ */ jsxs10("div", { className: "mt-6 rounded-xl border border-zinc-200/10 bg-zinc-950/50 p-5", children: [
      /* @__PURE__ */ jsx12("p", { className: "text-sm font-semibold text-zinc-100", children: "Recommended appeal details" }),
      /* @__PURE__ */ jsxs10("ul", { className: "mt-3 space-y-2 text-sm text-zinc-300", children: [
        /* @__PURE__ */ jsx12("li", { children: "Your account email" }),
        /* @__PURE__ */ jsx12("li", { children: "The date of the restriction" }),
        /* @__PURE__ */ jsx12("li", { children: "A concise explanation of what happened" }),
        /* @__PURE__ */ jsx12("li", { children: "Any evidence or context an admin should review" })
      ] })
    ] }),
    /* @__PURE__ */ jsxs10("div", { className: "mt-6 flex flex-wrap gap-3", children: [
      /* @__PURE__ */ jsx12("a", { href: "mailto:appeals@wagesociety.com?subject=W.A.G.E.%20Society%20Appeal", className: "rounded-lg bg-orange-300 px-4 py-2.5 text-sm font-semibold text-zinc-950 transition hover:bg-orange-200", children: "Email Appeals Team" }),
      /* @__PURE__ */ jsx12(Link6, { to: "/dashboard", className: "rounded-lg border border-zinc-100/25 px-4 py-2.5 text-sm font-semibold text-zinc-100 transition hover:border-orange-200/70 hover:text-orange-100", children: "Return Home" })
    ] })
  ] }) });
}
var init_appeals_BbY3GHSm = __esm({
  "dist/server/assets/appeals-BbY3GHSm.js"() {
    "use strict";
  }
});

// dist/server/assets/admin-DakHXV1g.js
var admin_DakHXV1g_exports = {};
__export(admin_DakHXV1g_exports, {
  component: () => AdminHubPage
});
import { jsx as jsx13, jsxs as jsxs11 } from "react/jsx-runtime";
import { useLocation as useLocation2, Outlet as Outlet2, Link as Link7 } from "@tanstack/react-router";
import { ArrowLeft as ArrowLeft2, Users as Users3, Store as Store2, RadioTower as RadioTower2, CircleHelp } from "lucide-react";
function AdminHubPage() {
  const location = useLocation2();
  if (location.pathname.startsWith("/admin/")) {
    return /* @__PURE__ */ jsx13(Outlet2, {});
  }
  return /* @__PURE__ */ jsx13("div", { className: "min-h-screen px-4 py-12 text-zinc-100", children: /* @__PURE__ */ jsxs11("div", { className: "mx-auto max-w-6xl space-y-6", children: [
    /* @__PURE__ */ jsx13("header", { className: "rounded-2xl border border-zinc-200/15 bg-zinc-900/60 p-6 md:p-8", children: /* @__PURE__ */ jsxs11("div", { className: "flex flex-wrap items-center justify-between gap-4", children: [
      /* @__PURE__ */ jsxs11("div", { children: [
        /* @__PURE__ */ jsx13("p", { className: "text-xs font-semibold uppercase tracking-[0.2em] text-zinc-400", children: "Organization Control Center" }),
        /* @__PURE__ */ jsx13("h1", { className: "mt-2 text-3xl font-black text-zinc-50 md:text-4xl", children: "Admin Hub" }),
        /* @__PURE__ */ jsx13("p", { className: "mt-3 max-w-2xl text-zinc-300", children: "One button per function. Use this panel to jump directly to each admin operation." })
      ] }),
      /* @__PURE__ */ jsx13("div", { className: "flex gap-3", children: /* @__PURE__ */ jsxs11(Link7, { to: "/dashboard", className: "inline-flex items-center gap-2 rounded-lg border border-zinc-300/35 px-4 py-2 text-sm font-semibold text-zinc-100 transition hover:border-zinc-100", children: [
        /* @__PURE__ */ jsx13(ArrowLeft2, { size: 16 }),
        " Dashboard"
      ] }) })
    ] }) }),
    /* @__PURE__ */ jsx13("section", { className: "grid gap-4 md:grid-cols-2 lg:grid-cols-3", children: adminLinks.map((item) => {
      const Icon = item.icon;
      return /* @__PURE__ */ jsxs11(Link7, { to: item.to, className: "group rounded-xl border border-zinc-200/15 bg-zinc-900/60 p-5 transition hover:border-orange-300/50", children: [
        /* @__PURE__ */ jsx13("div", { className: "mb-3 inline-flex rounded-md border border-zinc-200/20 bg-zinc-950/70 p-2 text-orange-200 transition group-hover:border-orange-300/40", children: /* @__PURE__ */ jsx13(Icon, { size: 18 }) }),
        /* @__PURE__ */ jsx13("h2", { className: "text-xl font-bold text-zinc-50", children: item.title }),
        /* @__PURE__ */ jsx13("p", { className: "mt-2 text-sm text-zinc-300", children: item.description }),
        /* @__PURE__ */ jsx13("span", { className: "mt-4 inline-flex rounded-lg border border-zinc-100/25 px-3 py-1.5 text-xs font-semibold uppercase tracking-wide text-zinc-100 transition group-hover:border-orange-300/55 group-hover:text-orange-100", children: "Open" })
      ] }, item.title);
    }) })
  ] }) });
}
var adminLinks;
var init_admin_DakHXV1g = __esm({
  "dist/server/assets/admin-DakHXV1g.js"() {
    "use strict";
    adminLinks = [{
      title: "Users & Permissions",
      description: "Manage member roles, bans, and permission matrix controls.",
      to: "/admin/users",
      icon: Users3
    }, {
      title: "Shop CRUD",
      description: "Create and edit merch items and membership plans.",
      to: "/admin/shop",
      icon: Store2
    }, {
      title: "Livestreams",
      description: "Add/remove stream channels and monitor live status.",
      to: "/live",
      icon: RadioTower2
    }, {
      title: "FAQ Page",
      description: "Open the FAQ page used by members and visitors.",
      to: "/faq",
      icon: CircleHelp
    }];
  }
});

// dist/server/assets/_username-Bqi7lS2z.js
var username_Bqi7lS2z_exports = {};
__export(username_Bqi7lS2z_exports, {
  component: () => PublicProfilePage
});
import { jsx as jsx14, jsxs as jsxs12, Fragment as Fragment3 } from "react/jsx-runtime";
import { Link as Link8 } from "@tanstack/react-router";
import { Loader2 as Loader24, UserRound as UserRound3, ExternalLink as ExternalLink2 } from "lucide-react";
import { useState as useState9, useEffect as useEffect8, useMemo as useMemo2 } from "react";
import "@supabase/supabase-js";
import "stripe";
import "zod";
function PublicProfilePage() {
  const {
    username
  } = Route$x.useParams();
  const [loading, setLoading] = useState9(true);
  const [profile, setProfile] = useState9(null);
  const [error, setError] = useState9("");
  const [user, setUser] = useState9(null);
  const [authLoading, setAuthLoading] = useState9(true);
  useEffect8(() => {
    let mounted = true;
    void (async () => {
      setLoading(true);
      setError("");
      try {
        const response = await fetch(`/api/public-profile?username=${encodeURIComponent(username)}`);
        const data = await response.json();
        if (!response.ok || !data.profile) {
          if (!mounted) return;
          setProfile(null);
          setError(data.error || "Profile not found.");
          return;
        }
        if (!mounted) return;
        setProfile(data.profile);
      } catch {
        if (!mounted) return;
        setProfile(null);
        setError("Could not load profile right now.");
      } finally {
        if (mounted) setLoading(false);
      }
    })();
    return () => {
      mounted = false;
    };
  }, [username]);
  useEffect8(() => {
    const supabase = getSupabaseBrowserClient();
    const checkAuth = async () => {
      if (isLocalRootSessionActive()) {
        setUser(getLocalRootUser());
        setAuthLoading(false);
        return;
      }
      try {
        const {
          data
        } = await supabase.auth.getSession();
        setUser(data.session?.user || null);
      } catch {
        setUser(null);
      } finally {
        setAuthLoading(false);
      }
    };
    void checkAuth();
    const {
      data: {
        subscription
      }
    } = supabase.auth.onAuthStateChange((_event, session) => {
      if (isLocalRootSessionActive()) {
        setUser(getLocalRootUser());
        setAuthLoading(false);
        return;
      }
      setUser(session?.user || null);
      setAuthLoading(false);
    });
    return () => {
      subscription.unsubscribe();
    };
  }, []);
  const connectedCount = useMemo2(() => profile?.connectedAccounts.length || 0, [profile?.connectedAccounts]);
  if (loading) {
    return /* @__PURE__ */ jsx14("main", { className: "min-h-screen px-4 py-16 text-zinc-100", children: /* @__PURE__ */ jsx14("div", { className: "mx-auto max-w-4xl rounded-2xl border border-zinc-200/15 bg-zinc-900/60 p-8", children: /* @__PURE__ */ jsxs12("p", { className: "inline-flex items-center gap-2 text-sm text-zinc-300", children: [
      /* @__PURE__ */ jsx14(Loader24, { size: 14, className: "animate-spin" }),
      " Loading creator profile..."
    ] }) }) });
  }
  if (!profile) {
    return /* @__PURE__ */ jsx14("main", { className: "min-h-screen px-4 py-16 text-zinc-100", children: /* @__PURE__ */ jsxs12("div", { className: "mx-auto max-w-3xl rounded-2xl border border-zinc-200/15 bg-zinc-900/60 p-8 text-center", children: [
      /* @__PURE__ */ jsx14("h1", { className: "text-3xl font-black text-zinc-50", children: "Profile Not Found" }),
      /* @__PURE__ */ jsx14("p", { className: "mt-3 text-sm text-zinc-300", children: error || "This profile may not exist yet." }),
      /* @__PURE__ */ jsxs12("div", { className: "mt-6 flex justify-center gap-3", children: [
        /* @__PURE__ */ jsx14(Link8, { to: "/", className: "rounded-lg border border-zinc-100/25 px-4 py-2 text-sm font-semibold text-zinc-100 transition hover:border-orange-200/70", children: "Home" }),
        !authLoading && (user ? /* @__PURE__ */ jsx14(Link8, { to: "/dashboard", className: "rounded-lg bg-orange-300 px-4 py-2 text-sm font-semibold text-zinc-950 transition hover:bg-orange-200", children: "Dashboard" }) : /* @__PURE__ */ jsx14(Link8, { to: "/signup", className: "rounded-lg bg-orange-300 px-4 py-2 text-sm font-semibold text-zinc-950 transition hover:bg-orange-200", children: "Join W.A.G.E." }))
      ] })
    ] }) });
  }
  return /* @__PURE__ */ jsx14("main", { className: "min-h-screen px-4 py-10 text-zinc-100", children: /* @__PURE__ */ jsx14("div", { className: "mx-auto max-w-5xl", children: /* @__PURE__ */ jsxs12("section", { className: "rounded-3xl border border-zinc-200/15 bg-zinc-900/60 p-6 md:p-8", children: [
    /* @__PURE__ */ jsxs12("div", { className: "flex flex-col gap-6 md:flex-row md:items-start md:justify-between", children: [
      /* @__PURE__ */ jsxs12("div", { className: "flex items-start gap-4", children: [
        profile.avatarUrl ? /* @__PURE__ */ jsx14("img", { src: profile.avatarUrl, alt: `${profile.displayName} avatar`, className: "h-20 w-20 rounded-full border border-zinc-200/20 object-cover" }) : /* @__PURE__ */ jsx14("div", { className: "flex h-20 w-20 items-center justify-center rounded-full border border-zinc-200/20 bg-zinc-800", children: /* @__PURE__ */ jsx14(UserRound3, { size: 26, className: "text-zinc-400" }) }),
        /* @__PURE__ */ jsxs12("div", { children: [
          /* @__PURE__ */ jsx14("p", { className: "text-xs font-semibold uppercase tracking-[0.2em] text-zinc-500", children: "Creator Profile" }),
          /* @__PURE__ */ jsx14("h1", { className: "mt-1 text-3xl font-black text-zinc-50", children: profile.displayName }),
          /* @__PURE__ */ jsxs12("p", { className: "mt-1 text-sm text-orange-200", children: [
            "@",
            profile.username
          ] }),
          /* @__PURE__ */ jsxs12("p", { className: "mt-2 text-sm text-zinc-300", children: [
            "Connected Accounts: ",
            /* @__PURE__ */ jsx14("span", { className: "font-semibold text-zinc-100", children: connectedCount })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsx14("div", { className: "flex flex-wrap gap-2", children: !authLoading && (user ? /* @__PURE__ */ jsx14(Link8, { to: "/dashboard", className: "rounded-lg bg-orange-300 px-4 py-2 text-sm font-semibold text-zinc-950 transition hover:bg-orange-200", children: "Dashboard" }) : /* @__PURE__ */ jsxs12(Fragment3, { children: [
        /* @__PURE__ */ jsx14(Link8, { to: "/signup", className: "rounded-lg bg-orange-300 px-4 py-2 text-sm font-semibold text-zinc-950 transition hover:bg-orange-200", children: "Join / Connect" }),
        /* @__PURE__ */ jsx14(Link8, { to: "/login", className: "rounded-lg border border-zinc-100/25 px-4 py-2 text-sm font-semibold text-zinc-100 transition hover:border-orange-200/70", children: "Log In" })
      ] })) })
    ] }),
    /* @__PURE__ */ jsxs12("div", { className: "mt-6 grid gap-6 md:grid-cols-[1.15fr_0.85fr]", children: [
      /* @__PURE__ */ jsxs12("article", { className: "rounded-2xl border border-zinc-200/15 bg-zinc-950/50 p-5", children: [
        /* @__PURE__ */ jsx14("h2", { className: "text-lg font-bold text-zinc-50", children: "Bio" }),
        /* @__PURE__ */ jsx14("p", { className: "mt-2 whitespace-pre-line text-sm leading-relaxed text-zinc-300", children: profile.bio || "This creator has not added a bio yet." }),
        /* @__PURE__ */ jsx14("h3", { className: "mt-6 text-sm font-semibold uppercase tracking-[0.16em] text-zinc-400", children: "Skills" }),
        profile.skills.length ? /* @__PURE__ */ jsx14("div", { className: "mt-3 flex flex-wrap gap-2", children: profile.skills.map((skill) => /* @__PURE__ */ jsx14("span", { className: "rounded-full border border-zinc-200/20 bg-zinc-900 px-3 py-1 text-xs text-zinc-200", children: skill }, skill)) }) : /* @__PURE__ */ jsx14("p", { className: "mt-2 text-sm text-zinc-500", children: "No skills listed yet." })
      ] }),
      /* @__PURE__ */ jsxs12("article", { className: "rounded-2xl border border-zinc-200/15 bg-zinc-950/50 p-5", children: [
        /* @__PURE__ */ jsx14("h2", { className: "text-lg font-bold text-zinc-50", children: "Connected Accounts" }),
        profile.connectedAccounts.length ? /* @__PURE__ */ jsx14("ul", { className: "mt-3 space-y-2", children: profile.connectedAccounts.map((account) => /* @__PURE__ */ jsx14("li", { className: "rounded-xl border border-zinc-200/15 bg-zinc-900/70 p-3", children: /* @__PURE__ */ jsxs12("div", { className: "flex items-center justify-between gap-3", children: [
          /* @__PURE__ */ jsxs12("div", { children: [
            /* @__PURE__ */ jsx14("p", { className: "text-sm font-semibold text-zinc-100", children: account.providerLabel }),
            /* @__PURE__ */ jsx14("p", { className: "text-xs text-zinc-400", children: account.handle ? `@${account.handle.replace(/^@/, "")}` : "Connected" })
          ] }),
          account.url ? /* @__PURE__ */ jsxs12("a", { href: account.url, target: "_blank", rel: "noopener noreferrer", className: "inline-flex items-center gap-1 rounded-lg border border-zinc-100/20 px-2.5 py-1 text-xs font-semibold text-zinc-100 transition hover:border-orange-200/70 hover:text-orange-100", children: [
            "Open ",
            /* @__PURE__ */ jsx14(ExternalLink2, { size: 12 })
          ] }) : /* @__PURE__ */ jsx14("span", { className: "text-xs text-zinc-500", children: "No public URL" })
        ] }) }, `${account.provider}-${account.handle || account.providerLabel}`)) }) : /* @__PURE__ */ jsx14("p", { className: "mt-2 text-sm text-zinc-500", children: "No connected accounts are public yet." })
      ] })
    ] })
  ] }) }) });
}
var init_username_Bqi7lS2z = __esm({
  "dist/server/assets/_username-Bqi7lS2z.js"() {
    "use strict";
    init_router_BDBFyAOM();
  }
});

// dist/server/assets/index-Ck-N9V5O.js
var index_Ck_N9V5O_exports = {};
__export(index_Ck_N9V5O_exports, {
  component: () => Home
});
import { jsxs as jsxs13, Fragment as Fragment4, jsx as jsx15 } from "react/jsx-runtime";
import { useRouter, Link as Link9 } from "@tanstack/react-router";
import { User as User2, LogOut, UserPlus, LogIn, Store as Store3, Tv, Users as Users4, Newspaper as Newspaper2, ArrowRight } from "lucide-react";
import { useState as useState10, useEffect as useEffect9 } from "react";
import "@supabase/supabase-js";
import "stripe";
import "zod";
function Home() {
  const [email, setEmail] = useState10("");
  const [liveAlerts, setLiveAlerts] = useState10(true);
  const [newsletter, setNewsletter] = useState10(true);
  const [productUpdates, setProductUpdates] = useState10(false);
  const [communityUpdates, setCommunityUpdates] = useState10(false);
  const [subscribing, setSubscribing] = useState10(false);
  const [subscribeError, setSubscribeError] = useState10("");
  const [subscribeSuccess, setSubscribeSuccess] = useState10("");
  const [user, setUser] = useState10(null);
  const [authLoading, setAuthLoading] = useState10(true);
  const router2 = useRouter();
  useEffect9(() => {
    const checkAuth = async () => {
      if (isLocalRootSessionActive()) {
        const localUser = getLocalRootUser();
        setUser(localUser);
        setEmail(localUser.email);
        setAuthLoading(false);
        return;
      }
      try {
        const supabase = getSupabaseBrowserClient();
        const {
          data
        } = await supabase.auth.getSession();
        setUser(data.session?.user || null);
        if (data.session?.user?.email) {
          setEmail(data.session.user.email);
        }
      } catch {
        setUser(null);
      } finally {
        setAuthLoading(false);
      }
    };
    checkAuth();
  }, []);
  const handleLogout = async () => {
    const supabase = getSupabaseBrowserClient();
    await supabase.auth.signOut();
    setUser(null);
    await router2.navigate({
      to: "/"
    });
  };
  const handleSubscribe = async (event) => {
    event.preventDefault();
    setSubscribeError("");
    setSubscribeSuccess("");
    if (!email.trim()) {
      setSubscribeError("Please enter an email address.");
      return;
    }
    if (!liveAlerts && !newsletter && !productUpdates && !communityUpdates) {
      setSubscribeError("Choose at least one alert type.");
      return;
    }
    try {
      setSubscribing(true);
      const response = await fetch("/api/marketing-proof", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          email: email.trim(),
          liveAlerts,
          newsletter,
          productUpdates,
          communityUpdates,
          source: "homepage"
        })
      });
      const data = await response.json();
      if (!response.ok) {
        setSubscribeError(data.error || "Could not subscribe right now.");
        return;
      }
      setSubscribeSuccess("Subscribed. You will receive the alerts you selected.");
      setEmail("");
    } catch {
      setSubscribeError("Could not subscribe right now.");
    } finally {
      setSubscribing(false);
    }
  };
  return /* @__PURE__ */ jsxs13(Fragment4, { children: [
    /* @__PURE__ */ jsxs13("section", { className: "mt-8 rounded-3xl border border-orange-200/20 bg-gradient-to-br from-zinc-900 via-zinc-900 to-zinc-950 p-6 sm:p-8 lg:p-10", children: [
      /* @__PURE__ */ jsx15("p", { className: "inline-flex rounded-full border border-orange-300/30 bg-orange-300/10 px-3 py-1 text-xs font-semibold uppercase tracking-[0.16em] text-orange-100", children: "Public Portal" }),
      /* @__PURE__ */ jsx15("h1", { className: "mt-4 max-w-3xl text-3xl font-black leading-tight text-zinc-50 sm:text-4xl lg:text-5xl", children: "One place for creators to connect, watch live, discover members, and grow." }),
      /* @__PURE__ */ jsx15("p", { className: "mt-4 max-w-2xl text-sm leading-relaxed text-zinc-300 sm:text-base", children: "Whether visitors are authenticated or not, they can access public sections, explore creators, and jump into the content that matters most." }),
      /* @__PURE__ */ jsx15("div", { className: "mt-6 flex flex-wrap gap-3", children: !authLoading && user ? /* @__PURE__ */ jsxs13(Fragment4, { children: [
        /* @__PURE__ */ jsxs13(Link9, { to: "/dashboard", className: "inline-flex items-center gap-2 rounded-xl bg-orange-300 px-4 py-2.5 text-sm font-semibold text-zinc-950 transition hover:bg-orange-200", children: [
          /* @__PURE__ */ jsx15(User2, { size: 15 }),
          " Profile"
        ] }),
        /* @__PURE__ */ jsxs13("button", { type: "button", onClick: () => {
          void handleLogout();
        }, className: "inline-flex items-center gap-2 rounded-xl border border-zinc-100/25 px-4 py-2.5 text-sm font-semibold text-zinc-100 transition hover:border-orange-200/60", children: [
          /* @__PURE__ */ jsx15(LogOut, { size: 15 }),
          " Logout"
        ] })
      ] }) : !authLoading ? /* @__PURE__ */ jsxs13(Fragment4, { children: [
        /* @__PURE__ */ jsxs13(Link9, { to: "/signup", className: "inline-flex items-center gap-2 rounded-xl bg-orange-300 px-4 py-2.5 text-sm font-semibold text-zinc-950 transition hover:bg-orange-200", children: [
          /* @__PURE__ */ jsx15(UserPlus, { size: 15 }),
          " Create Account"
        ] }),
        /* @__PURE__ */ jsxs13(Link9, { to: "/login", className: "inline-flex items-center gap-2 rounded-xl border border-zinc-100/25 px-4 py-2.5 text-sm font-semibold text-zinc-100 transition hover:border-orange-200/60", children: [
          /* @__PURE__ */ jsx15(LogIn, { size: 15 }),
          " Login"
        ] })
      ] }) : null })
    ] }),
    /* @__PURE__ */ jsx15("section", { className: "mt-7 grid gap-4 sm:grid-cols-2 lg:grid-cols-4", children: publicDestinations.map((item) => {
      const Icon = item.icon;
      return /* @__PURE__ */ jsxs13(Link9, { to: item.to, className: "group rounded-2xl border border-zinc-200/15 bg-zinc-900/70 p-5 transition hover:border-orange-200/55 hover:bg-zinc-900", children: [
        /* @__PURE__ */ jsx15("span", { className: "inline-flex rounded-lg border border-zinc-100/15 bg-zinc-800/80 p-2 text-orange-200", children: /* @__PURE__ */ jsx15(Icon, { size: 16 }) }),
        /* @__PURE__ */ jsx15("h2", { className: "mt-4 text-lg font-bold text-zinc-50", children: item.title }),
        /* @__PURE__ */ jsx15("p", { className: "mt-2 text-sm text-zinc-400", children: item.description }),
        /* @__PURE__ */ jsxs13("span", { className: "mt-4 inline-flex items-center gap-1 text-xs font-semibold uppercase tracking-[0.12em] text-orange-100", children: [
          "Open ",
          /* @__PURE__ */ jsx15(ArrowRight, { size: 13, className: "transition group-hover:translate-x-0.5" })
        ] })
      ] }, item.to);
    }) }),
    !authLoading && user && /* @__PURE__ */ jsxs13("section", { className: "mt-7 rounded-2xl border border-zinc-200/15 bg-zinc-900/70 p-5 sm:p-6", children: [
      /* @__PURE__ */ jsx15("h2", { className: "text-lg font-bold text-zinc-50", children: "Get Email Alerts" }),
      /* @__PURE__ */ jsx15("p", { className: "mt-1 text-sm text-zinc-400", children: "Subscribe for live alerts, newsletters, and website updates." }),
      /* @__PURE__ */ jsxs13("form", { onSubmit: handleSubscribe, className: "mt-4 space-y-3", children: [
        /* @__PURE__ */ jsx15("input", { type: "email", value: email, readOnly: true, className: "w-full rounded-lg border border-zinc-200/20 bg-zinc-800/50 px-3 py-2 text-sm text-zinc-300 outline-none" }),
        /* @__PURE__ */ jsxs13("div", { className: "grid gap-2 text-sm text-zinc-300 sm:grid-cols-2 lg:grid-cols-4", children: [
          /* @__PURE__ */ jsxs13("label", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsx15("input", { type: "checkbox", checked: liveAlerts, onChange: (event) => setLiveAlerts(event.target.checked) }),
            "Live alerts"
          ] }),
          /* @__PURE__ */ jsxs13("label", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsx15("input", { type: "checkbox", checked: newsletter, onChange: (event) => setNewsletter(event.target.checked) }),
            "Newsletter"
          ] }),
          /* @__PURE__ */ jsxs13("label", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsx15("input", { type: "checkbox", checked: productUpdates, onChange: (event) => setProductUpdates(event.target.checked) }),
            "Product updates"
          ] }),
          /* @__PURE__ */ jsxs13("label", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsx15("input", { type: "checkbox", checked: communityUpdates, onChange: (event) => setCommunityUpdates(event.target.checked) }),
            "Community updates"
          ] })
        ] }),
        subscribeError ? /* @__PURE__ */ jsx15("p", { className: "text-xs text-rose-300", children: subscribeError }) : null,
        subscribeSuccess ? /* @__PURE__ */ jsx15("p", { className: "text-xs text-emerald-300", children: subscribeSuccess }) : null,
        /* @__PURE__ */ jsx15("button", { type: "submit", disabled: subscribing, className: "w-full rounded-lg bg-orange-300 px-4 py-2.5 text-sm font-semibold text-zinc-950 transition hover:bg-orange-200 disabled:opacity-70 sm:w-auto", children: subscribing ? "Subscribing..." : "Subscribe" })
      ] })
    ] })
  ] });
}
var publicDestinations;
var init_index_Ck_N9V5O = __esm({
  "dist/server/assets/index-Ck-N9V5O.js"() {
    "use strict";
    init_router_BDBFyAOM();
    publicDestinations = [{
      title: "Shop",
      description: "Browse memberships and merch available to all visitors.",
      to: "/merch",
      icon: Store3
    }, {
      title: "Livestream",
      description: "View the live section and stream activity feed.",
      to: "/live",
      icon: Tv
    }, {
      title: "Directory",
      description: "Discover creators and open their public profiles.",
      to: "/directory",
      icon: Users4
    }, {
      title: "Blog",
      description: "Read public updates, announcements, and posts.",
      to: "/news",
      icon: Newspaper2
    }];
  }
});

// dist/server/assets/admin.users-CcJsv1Wm.js
var admin_users_CcJsv1Wm_exports = {};
__export(admin_users_CcJsv1Wm_exports, {
  component: () => AdminUsersPage
});
import { jsx as jsx16, jsxs as jsxs14, Fragment as Fragment5 } from "react/jsx-runtime";
import { Link as Link10 } from "@tanstack/react-router";
import { ArrowLeft as ArrowLeft3, UserCog, ChevronDown as ChevronDown2, Check as Check2, Users as Users5, Ban, ShieldCheck } from "lucide-react";
import { useState as useState11, useMemo as useMemo3, useEffect as useEffect10 } from "react";
import "@supabase/supabase-js";
import "stripe";
import "zod";
function AdminUsersPage() {
  const [roles, setRoles] = useState11([]);
  const [permissionMatrix, setPermissionMatrix] = useState11([]);
  const [loading, setLoading] = useState11(true);
  const [error, setError] = useState11("");
  const [requesterEmail, setRequesterEmail] = useState11("");
  const [requestSource, setRequestSource] = useState11("");
  const [requesterRole, setRequesterRole] = useState11("user");
  const [requesterPermissions, setRequesterPermissions] = useState11([]);
  const [formEmail, setFormEmail] = useState11("");
  const [memberSearchOpen, setMemberSearchOpen] = useState11(false);
  const [formRole, setFormRole] = useState11("manager");
  const [banReason, setBanReason] = useState11("");
  const [bannedUntil, setBannedUntil] = useState11("");
  const [submitting, setSubmitting] = useState11(false);
  const [submitSuccess, setSubmitSuccess] = useState11(false);
  const [availablePlans, setAvailablePlans] = useState11(["free"]);
  const [planDraftByEmail, setPlanDraftByEmail] = useState11({});
  const [planSavingEmail, setPlanSavingEmail] = useState11("");
  const [activePermRole, setActivePermRole] = useState11("admin");
  const [permSavingKey, setPermSavingKey] = useState11("");
  const isLocalSuperadmin = useMemo3(() => requestSource === "localhost-bypass", [requestSource]);
  const canManagePerms = requesterRole === "superadmin" || isLocalSuperadmin || requesterPermissions.includes("manage_permissions");
  const canManageUsers = requesterRole === "superadmin" || isLocalSuperadmin || requesterPermissions.includes("manage_users");
  const memberSuggestions = useMemo3(() => {
    const query = formEmail.trim().toLowerCase();
    const rows = roles.map((row) => {
      const local = row.email.split("@")[0] || "";
      const fallbackName = local.split(/[._-]+/).filter(Boolean).map((part) => `${part.slice(0, 1).toUpperCase()}${part.slice(1).toLowerCase()}`).join(" ");
      const name = row.display_name?.trim() || fallbackName;
      return {
        email: row.email,
        name,
        search: `${row.email} ${name}`.toLowerCase()
      };
    }).sort((a, b) => a.email.localeCompare(b.email));
    if (!query) return rows.slice(0, 8);
    return rows.filter((row) => row.search.includes(query)).slice(0, 8);
  }, [roles, formEmail]);
  const loadRoles = async () => {
    const res = await authedFetch("/api/admin/roles");
    const json = await res.json();
    if (!res.ok) {
      setError(json.error || "Failed to load members");
      return;
    }
    const nextRoles = json.roles || [];
    setRoles(nextRoles);
    setPlanDraftByEmail((prev) => {
      const next = {
        ...prev
      };
      for (const row of nextRoles) {
        if (!row.email) continue;
        const currentPlan = String(row.membership_plan || "free").trim().toLowerCase();
        next[row.email] = currentPlan || "free";
      }
      return next;
    });
    setRequesterEmail(json.requester?.email || "");
    setRequestSource(json.requester?.source || "");
    setRequesterRole(json.requester?.role || "user");
    setRequesterPermissions(json.requester?.permissions || []);
  };
  const loadPlans = async () => {
    const res = await authedFetch("/api/admin/shop/plans");
    const json = await res.json();
    if (!res.ok) return;
    const planSlugs = Array.isArray(json.plans) ? json.plans.filter((plan) => plan.is_active !== false).map((plan) => String(plan.slug || "").trim().toLowerCase()).filter((slug) => Boolean(slug)) : [];
    const unique = Array.from(/* @__PURE__ */ new Set(["free", ...planSlugs]));
    setAvailablePlans(unique);
  };
  const loadPermissions = async () => {
    const res = await authedFetch("/api/admin/permissions");
    const json = await res.json();
    if (!res.ok) {
      setError(json.error || "Failed to load permissions");
      return;
    }
    setPermissionMatrix(json.matrix || []);
  };
  useEffect10(() => {
    void (async () => {
      setLoading(true);
      setError("");
      try {
        await Promise.all([loadRoles(), loadPermissions(), loadPlans()]);
      } catch (err) {
        setError(err instanceof Error ? err.message : "Failed to load admin user data");
      } finally {
        setLoading(false);
      }
    })();
  }, []);
  const submitRole = async (event) => {
    event.preventDefault();
    setSubmitting(true);
    setError("");
    setSubmitSuccess(false);
    const res = await authedFetch("/api/admin/roles", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        targetEmail: formEmail,
        role: formRole,
        banReason: formRole === "banned" ? banReason.trim() || null : null,
        bannedUntil: formRole === "banned" && bannedUntil ? new Date(bannedUntil).toISOString() : null
      })
    });
    const json = await res.json();
    if (!res.ok) {
      setError(json.error || "Failed to update role");
      setSubmitting(false);
      return;
    }
    setFormEmail("");
    setFormRole("manager");
    setBanReason("");
    setBannedUntil("");
    setSubmitSuccess(true);
    setTimeout(() => setSubmitSuccess(false), 3e3);
    await loadRoles();
    setSubmitting(false);
  };
  const togglePermission = async (role, permissionKey, enabled) => {
    if (!canManagePerms) return;
    setPermSavingKey(`${role}:${permissionKey}`);
    setError("");
    const res = await authedFetch("/api/admin/permissions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        role,
        permissionKey,
        enabled
      })
    });
    const json = await res.json();
    if (!res.ok) setError(json.error || "Failed to update permission");
    else await loadPermissions();
    setPermSavingKey("");
  };
  const updateSubscription = async (email) => {
    if (!canManageUsers) return;
    const requestedPlan = String(planDraftByEmail[email] || "free").trim().toLowerCase();
    if (!requestedPlan) {
      setError("Please select a valid subscription plan.");
      return;
    }
    setPlanSavingEmail(email);
    setError("");
    const res = await authedFetch("/api/admin/roles", {
      method: "PUT",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        targetEmail: email,
        membershipPlan: requestedPlan
      })
    });
    const json = await res.json();
    if (!res.ok) {
      const detailText = Array.isArray(json.details) ? json.details.filter((item) => typeof item === "string").join(" ") : "";
      setError([json.error || "Failed to update subscription plan", detailText].filter(Boolean).join(" "));
      setPlanSavingEmail("");
      return;
    }
    await loadRoles();
    setPlanSavingEmail("");
  };
  const activeRoleField = `${activePermRole}_enabled`;
  return /* @__PURE__ */ jsx16("div", { className: "min-h-screen px-4 py-12 text-zinc-100", children: /* @__PURE__ */ jsxs14("div", { className: "mx-auto max-w-5xl space-y-6", children: [
    /* @__PURE__ */ jsxs14("header", { className: "rounded-2xl border border-zinc-200/15 bg-zinc-900/60 p-6", children: [
      /* @__PURE__ */ jsxs14("div", { className: "flex flex-wrap items-center justify-between gap-4", children: [
        /* @__PURE__ */ jsxs14("div", { children: [
          /* @__PURE__ */ jsx16("p", { className: "text-xs font-semibold uppercase tracking-widest text-zinc-500", children: "Admin / Users" }),
          /* @__PURE__ */ jsx16("h1", { className: "mt-1.5 text-3xl font-black text-zinc-50", children: "Users & Permissions" })
        ] }),
        /* @__PURE__ */ jsxs14("div", { className: "flex gap-2", children: [
          /* @__PURE__ */ jsxs14(Link10, { to: "/admin", className: "inline-flex items-center gap-2 rounded-lg border border-zinc-300/30 px-4 py-2 text-sm font-semibold text-zinc-100 transition hover:border-zinc-100", children: [
            /* @__PURE__ */ jsx16(ArrowLeft3, { size: 14 }),
            " Admin"
          ] }),
          /* @__PURE__ */ jsx16(Link10, { to: "/dashboard", className: "rounded-lg border border-zinc-300/30 px-4 py-2 text-sm font-semibold text-zinc-100 transition hover:border-zinc-100", children: "Dashboard" })
        ] })
      ] }),
      /* @__PURE__ */ jsxs14("div", { className: "mt-3 flex flex-wrap items-center gap-2 text-xs", children: [
        /* @__PURE__ */ jsx16("span", { className: "rounded-full border border-zinc-700 px-2.5 py-1 text-zinc-400", children: requesterEmail || "Loading\u2026" }),
        /* @__PURE__ */ jsx16("span", { className: `rounded-full border px-2.5 py-1 ${isLocalSuperadmin ? "border-orange-300/60 text-orange-200" : "border-zinc-700 text-zinc-400"}`, children: isLocalSuperadmin ? "Localhost superadmin" : formatRoleLabel(requesterRole) })
      ] })
    ] }),
    error ? /* @__PURE__ */ jsx16("p", { className: "rounded-xl border border-rose-400/40 bg-rose-500/10 px-4 py-3 text-sm text-rose-200", children: error }) : null,
    /* @__PURE__ */ jsxs14("div", { className: "grid gap-5 lg:grid-cols-[320px_1fr]", children: [
      /* @__PURE__ */ jsxs14("section", { className: "rounded-2xl border border-zinc-200/15 bg-zinc-900/60 p-5", children: [
        /* @__PURE__ */ jsxs14("div", { className: "mb-4 flex items-center gap-2", children: [
          /* @__PURE__ */ jsx16(UserCog, { size: 16, className: "text-orange-300" }),
          /* @__PURE__ */ jsx16("h2", { className: "font-bold text-zinc-100", children: "Assign Role" })
        ] }),
        /* @__PURE__ */ jsxs14("form", { onSubmit: submitRole, className: "space-y-3", children: [
          /* @__PURE__ */ jsxs14("label", { className: "block", children: [
            /* @__PURE__ */ jsx16("span", { className: "mb-1.5 block text-xs font-medium text-zinc-400", children: "Member (search by name or email)" }),
            /* @__PURE__ */ jsxs14("div", { className: "relative", children: [
              /* @__PURE__ */ jsx16("input", { type: "text", required: true, value: formEmail, onChange: (e) => {
                setFormEmail(e.target.value);
                setMemberSearchOpen(true);
              }, onFocus: () => setMemberSearchOpen(true), onBlur: () => {
                setTimeout(() => setMemberSearchOpen(false), 120);
              }, className: "w-full rounded-lg border border-zinc-200/20 bg-zinc-950/60 px-3 py-2 text-sm text-zinc-100 outline-none transition focus:border-orange-300/60", placeholder: "Type a name or email", autoComplete: "off" }),
              memberSearchOpen && memberSuggestions.length > 0 ? /* @__PURE__ */ jsx16("ul", { className: "absolute z-20 mt-1 max-h-56 w-full overflow-y-auto rounded-lg border border-zinc-700 bg-zinc-950/95 p-1 shadow-xl backdrop-blur", children: memberSuggestions.map((member) => /* @__PURE__ */ jsx16("li", { children: /* @__PURE__ */ jsxs14("button", { type: "button", onMouseDown: (event) => {
                event.preventDefault();
                setFormEmail(member.email);
                setMemberSearchOpen(false);
              }, className: "w-full rounded-md px-2.5 py-2 text-left transition hover:bg-zinc-800", children: [
                /* @__PURE__ */ jsx16("p", { className: "truncate text-sm font-medium text-zinc-100", children: member.name || member.email }),
                /* @__PURE__ */ jsx16("p", { className: "truncate text-xs text-zinc-500", children: member.email })
              ] }) }, member.email)) }) : null
            ] })
          ] }),
          /* @__PURE__ */ jsxs14("label", { className: "block", children: [
            /* @__PURE__ */ jsx16("span", { className: "mb-1.5 block text-xs font-medium text-zinc-400", children: "Role" }),
            /* @__PURE__ */ jsxs14("div", { className: "relative", children: [
              /* @__PURE__ */ jsx16("select", { value: formRole, onChange: (e) => setFormRole(e.target.value), className: "w-full appearance-none rounded-lg border border-zinc-200/20 bg-zinc-950/60 px-3 py-2 pr-8 text-sm text-zinc-100 outline-none transition focus:border-orange-300/60", children: ORG_ROLES.map((r) => /* @__PURE__ */ jsx16("option", { value: r, children: ORG_ROLE_LABELS[r] }, r)) }),
              /* @__PURE__ */ jsx16(ChevronDown2, { size: 14, className: "pointer-events-none absolute right-2.5 top-1/2 -translate-y-1/2 text-zinc-500" })
            ] })
          ] }),
          formRole === "banned" ? /* @__PURE__ */ jsxs14(Fragment5, { children: [
            /* @__PURE__ */ jsxs14("label", { className: "block", children: [
              /* @__PURE__ */ jsx16("span", { className: "mb-1.5 block text-xs font-medium text-zinc-400", children: "Ban Reason" }),
              /* @__PURE__ */ jsx16("textarea", { required: true, value: banReason, onChange: (e) => setBanReason(e.target.value), rows: 3, className: "w-full rounded-lg border border-zinc-200/20 bg-zinc-950/60 px-3 py-2 text-sm text-zinc-100 outline-none transition focus:border-orange-300/60", placeholder: "Reason for the ban" })
            ] }),
            /* @__PURE__ */ jsxs14("label", { className: "block", children: [
              /* @__PURE__ */ jsx16("span", { className: "mb-1.5 block text-xs font-medium text-zinc-400", children: "Ban Until (optional)" }),
              /* @__PURE__ */ jsx16("input", { type: "datetime-local", value: bannedUntil, onChange: (e) => setBannedUntil(e.target.value), className: "w-full rounded-lg border border-zinc-200/20 bg-zinc-950/60 px-3 py-2 text-sm text-zinc-100 outline-none transition focus:border-orange-300/60" })
            ] })
          ] }) : null,
          /* @__PURE__ */ jsx16("button", { type: "submit", disabled: submitting || !canManageUsers, className: "flex w-full items-center justify-center gap-2 rounded-lg bg-orange-300 px-4 py-2.5 text-sm font-semibold text-zinc-950 transition hover:bg-orange-200 disabled:cursor-not-allowed disabled:opacity-60", children: submitting ? "Saving\u2026" : submitSuccess ? /* @__PURE__ */ jsxs14(Fragment5, { children: [
            /* @__PURE__ */ jsx16(Check2, { size: 14 }),
            " Saved"
          ] }) : "Save Role" })
        ] })
      ] }),
      /* @__PURE__ */ jsxs14("section", { className: "rounded-2xl border border-zinc-200/15 bg-zinc-900/60 p-5", children: [
        /* @__PURE__ */ jsxs14("div", { className: "mb-4 flex items-center justify-between", children: [
          /* @__PURE__ */ jsxs14("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsx16(Users5, { size: 16, className: "text-orange-300" }),
            /* @__PURE__ */ jsx16("h2", { className: "font-bold text-zinc-100", children: "Members" })
          ] }),
          /* @__PURE__ */ jsxs14("span", { className: "rounded-full border border-zinc-700 px-2.5 py-0.5 text-xs text-zinc-500", children: [
            roles.length,
            " total"
          ] })
        ] }),
        loading ? /* @__PURE__ */ jsx16("p", { className: "text-sm text-zinc-400", children: "Loading members\u2026" }) : roles.length === 0 ? /* @__PURE__ */ jsx16("p", { className: "text-sm text-zinc-500", children: "No members yet." }) : /* @__PURE__ */ jsx16("ul", { className: "space-y-1.5 max-h-[480px] overflow-y-auto pr-1", children: roles.map((row) => /* @__PURE__ */ jsxs14("li", { className: "flex flex-wrap items-start justify-between gap-3 rounded-xl border border-zinc-200/10 bg-zinc-950/40 px-4 py-3", children: [
          /* @__PURE__ */ jsxs14("div", { className: "min-w-0", children: [
            /* @__PURE__ */ jsx16("p", { className: "truncate text-sm font-medium text-zinc-100", children: row.display_name || row.email }),
            row.display_name ? /* @__PURE__ */ jsx16("p", { className: "mt-0.5 truncate text-xs text-zinc-500", children: row.email }) : null,
            row.role === "banned" && row.ban_reason ? /* @__PURE__ */ jsxs14("p", { className: "mt-0.5 text-xs text-rose-300/80", children: [
              "Banned: ",
              row.ban_reason
            ] }) : /* @__PURE__ */ jsxs14("p", { className: "mt-0.5 text-xs text-zinc-600", children: [
              "Granted by ",
              row.granted_by || "system",
              " \xB7 ",
              new Date(row.updated_at).toLocaleDateString()
            ] }),
            /* @__PURE__ */ jsxs14("p", { className: "mt-1 text-xs text-zinc-500", children: [
              "Plan: ",
              (row.membership_plan || "free").toUpperCase(),
              " \xB7 Permissions: ",
              row.effective_permissions?.length || 0,
              row.stripe_subscription_id ? " \xB7 Stripe active" : ""
            ] })
          ] }),
          /* @__PURE__ */ jsxs14("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsx16("span", { className: `rounded-full border px-2.5 py-0.5 text-xs font-medium ${roleBadgeClass[row.role]}`, children: row.role === "banned" ? /* @__PURE__ */ jsxs14("span", { className: "flex items-center gap-1", children: [
              /* @__PURE__ */ jsx16(Ban, { size: 10 }),
              ORG_ROLE_LABELS[row.role]
            ] }) : ORG_ROLE_LABELS[row.role] }),
            /* @__PURE__ */ jsxs14("div", { className: "flex items-center gap-1.5", children: [
              /* @__PURE__ */ jsx16("select", { value: planDraftByEmail[row.email] || "free", onChange: (event) => {
                const value = event.target.value;
                setPlanDraftByEmail((prev) => ({
                  ...prev,
                  [row.email]: value
                }));
              }, disabled: !canManageUsers || planSavingEmail === row.email, className: "rounded-md border border-zinc-700 bg-zinc-900 px-2 py-1 text-xs text-zinc-100 outline-none", children: availablePlans.map((plan) => /* @__PURE__ */ jsx16("option", { value: plan, children: plan.toUpperCase() }, plan)) }),
              /* @__PURE__ */ jsx16("button", { type: "button", onClick: () => {
                void updateSubscription(row.email);
              }, disabled: !canManageUsers || planSavingEmail === row.email, className: "rounded-md border border-zinc-500/60 px-2 py-1 text-xs font-semibold text-zinc-100 transition hover:border-orange-300/70 hover:text-orange-100 disabled:cursor-not-allowed disabled:opacity-50", children: planSavingEmail === row.email ? "Saving..." : "Save Plan" })
            ] })
          ] })
        ] }, row.email)) })
      ] })
    ] }),
    /* @__PURE__ */ jsxs14("section", { className: "rounded-2xl border border-zinc-200/15 bg-zinc-900/60 p-5", children: [
      /* @__PURE__ */ jsxs14("div", { className: "mb-5 flex flex-wrap items-center justify-between gap-3", children: [
        /* @__PURE__ */ jsxs14("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsx16(ShieldCheck, { size: 16, className: "text-orange-300" }),
          /* @__PURE__ */ jsx16("h2", { className: "font-bold text-zinc-100", children: "Permission Management" })
        ] }),
        !canManagePerms ? /* @__PURE__ */ jsx16("span", { className: "rounded-full border border-zinc-700 px-2.5 py-0.5 text-xs text-zinc-500", children: "Read-only" }) : null
      ] }),
      /* @__PURE__ */ jsx16("div", { className: "mb-5 flex flex-wrap gap-1.5", children: PERMISSION_ROLES.map((role) => /* @__PURE__ */ jsx16("button", { type: "button", onClick: () => setActivePermRole(role), className: `rounded-lg border px-3 py-1.5 text-xs font-semibold transition ${activePermRole === role ? `${roleBadgeClass[role]} ring-1 ring-current/30` : "border-zinc-700 text-zinc-400 hover:border-zinc-500 hover:text-zinc-200"}`, children: ORG_ROLE_LABELS[role] }, role)) }),
      loading ? /* @__PURE__ */ jsx16("p", { className: "text-sm text-zinc-400", children: "Loading permissions\u2026" }) : /* @__PURE__ */ jsx16("ul", { className: "divide-y divide-zinc-200/8", children: permissionMatrix.map((perm) => {
        const isEnabled = Boolean(perm[activeRoleField]);
        const isSaving = permSavingKey === `${activePermRole}:${perm.permission_key}`;
        const isLocked = !canManagePerms || activePermRole === "banned";
        return /* @__PURE__ */ jsxs14("li", { className: "flex items-center justify-between gap-4 py-3", children: [
          /* @__PURE__ */ jsxs14("div", { className: "min-w-0", children: [
            /* @__PURE__ */ jsx16("p", { className: "text-sm font-medium text-zinc-100", children: perm.label }),
            /* @__PURE__ */ jsx16("p", { className: "text-xs text-zinc-500", children: perm.description })
          ] }),
          /* @__PURE__ */ jsx16("button", { type: "button", disabled: isLocked || isSaving, onClick: () => {
            void togglePermission(activePermRole, perm.permission_key, !isEnabled);
          }, className: `relative shrink-0 h-6 w-11 rounded-full border transition-colors duration-200 ${isEnabled ? "border-orange-400/60 bg-orange-400/20" : "border-zinc-600 bg-zinc-800"} disabled:cursor-not-allowed disabled:opacity-50`, "aria-label": `${isEnabled ? "Disable" : "Enable"} ${perm.label} for ${ORG_ROLE_LABELS[activePermRole]}`, children: /* @__PURE__ */ jsx16("span", { className: `absolute top-0.5 h-4 w-4 rounded-full transition-all duration-200 ${isEnabled ? "left-[calc(100%-18px)] bg-orange-300" : "left-0.5 bg-zinc-500"}` }) })
        ] }, perm.permission_key);
      }) })
    ] })
  ] }) });
}
var roleBadgeClass, PERMISSION_ROLES;
var init_admin_users_CcJsv1Wm = __esm({
  "dist/server/assets/admin.users-CcJsv1Wm.js"() {
    "use strict";
    init_router_BDBFyAOM();
    roleBadgeClass = {
      superadmin: "border-orange-300/60 bg-orange-400/10 text-orange-200",
      admin: "border-cyan-400/40 bg-cyan-400/10 text-cyan-200",
      manager: "border-emerald-400/40 bg-emerald-400/10 text-emerald-200",
      staff: "border-sky-400/40 bg-sky-400/10 text-sky-200",
      moderator: "border-fuchsia-400/40 bg-fuchsia-400/10 text-fuchsia-200",
      helper: "border-violet-400/40 bg-violet-400/10 text-violet-200",
      user: "border-zinc-500/40 bg-zinc-800/40 text-zinc-300",
      banned: "border-rose-400/50 bg-rose-500/10 text-rose-200"
    };
    PERMISSION_ROLES = ORG_ROLES.filter((r) => r !== "banned");
  }
});

// dist/server/assets/admin.shop-PTpzx7UB.js
var admin_shop_PTpzx7UB_exports = {};
__export(admin_shop_PTpzx7UB_exports, {
  component: () => AdminShopPage
});
import { jsx as jsx17, jsxs as jsxs15 } from "react/jsx-runtime";
import { Link as Link11 } from "@tanstack/react-router";
import { RefreshCcw, ArrowLeft as ArrowLeft4, ShoppingBag, Trash2, Store as Store4 } from "lucide-react";
import { useState as useState12, useEffect as useEffect11 } from "react";
import "@supabase/supabase-js";
import "stripe";
import "zod";
function AdminShopPage() {
  const [loading, setLoading] = useState12(true);
  const [error, setError] = useState12("");
  const [merchItems, setMerchItems] = useState12([]);
  const [membershipPlans, setMembershipPlans] = useState12([]);
  const [merchForm, setMerchForm] = useState12(emptyMerchForm);
  const [planForm, setPlanForm] = useState12(emptyPlanForm);
  const [savingMerch, setSavingMerch] = useState12(false);
  const [savingPlan, setSavingPlan] = useState12(false);
  const loadShopData = async () => {
    setError("");
    const [merchRes, plansRes] = await Promise.all([authedFetch("/api/admin/shop/merch"), authedFetch("/api/admin/shop/plans")]);
    const merchJson = await merchRes.json();
    const plansJson = await plansRes.json();
    if (!merchRes.ok) {
      throw new Error(merchJson.error || "Failed to load merch items");
    }
    if (!plansRes.ok) {
      throw new Error(plansJson.error || "Failed to load membership plans");
    }
    setMerchItems(merchJson.items || []);
    setMembershipPlans(plansJson.plans || []);
  };
  useEffect11(() => {
    void (async () => {
      try {
        setLoading(true);
        await loadShopData();
      } catch (err) {
        setError(err instanceof Error ? err.message : "Failed to load shop data");
      } finally {
        setLoading(false);
      }
    })();
  }, []);
  const handleSaveMerch = async (event) => {
    event.preventDefault();
    setSavingMerch(true);
    setError("");
    try {
      const method = merchForm.id ? "PUT" : "POST";
      const res = await authedFetch("/api/admin/shop/merch", {
        method,
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          id: merchForm.id || void 0,
          name: merchForm.name,
          price: merchForm.price,
          description: merchForm.description,
          sortOrder: Number(merchForm.sortOrder),
          isActive: merchForm.isActive
        })
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || "Failed to save merch item");
      setMerchForm(emptyMerchForm);
      await loadShopData();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to save merch item");
    } finally {
      setSavingMerch(false);
    }
  };
  const handleDeleteMerch = async (id) => {
    try {
      setError("");
      const res = await authedFetch("/api/admin/shop/merch", {
        method: "DELETE",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          id
        })
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || "Failed to delete merch item");
      if (merchForm.id === id) setMerchForm(emptyMerchForm);
      await loadShopData();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to delete merch item");
    }
  };
  const handleSavePlan = async (event) => {
    event.preventDefault();
    setSavingPlan(true);
    setError("");
    try {
      const method = planForm.id ? "PUT" : "POST";
      const features = planForm.featuresText.split("\n").map((x) => x.trim()).filter(Boolean);
      const res = await authedFetch("/api/admin/shop/plans", {
        method,
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          id: planForm.id || void 0,
          slug: planForm.slug,
          name: planForm.name,
          displayPrice: planForm.displayPrice,
          priceCents: Number(planForm.priceCents),
          description: planForm.description,
          features,
          sortOrder: Number(planForm.sortOrder),
          isActive: planForm.isActive
        })
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || "Failed to save membership plan");
      setPlanForm(emptyPlanForm);
      await loadShopData();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to save membership plan");
    } finally {
      setSavingPlan(false);
    }
  };
  const handleDeletePlan = async (id) => {
    try {
      setError("");
      const res = await authedFetch("/api/admin/shop/plans", {
        method: "DELETE",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          id
        })
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || "Failed to delete membership plan");
      if (planForm.id === id) setPlanForm(emptyPlanForm);
      await loadShopData();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to delete membership plan");
    }
  };
  return /* @__PURE__ */ jsx17("div", { className: "min-h-screen px-4 py-12 text-zinc-100", children: /* @__PURE__ */ jsxs15("div", { className: "mx-auto max-w-6xl space-y-6", children: [
    /* @__PURE__ */ jsx17("header", { className: "rounded-2xl border border-zinc-200/15 bg-zinc-900/60 p-6 md:p-8", children: /* @__PURE__ */ jsxs15("div", { className: "flex flex-wrap items-center justify-between gap-4", children: [
      /* @__PURE__ */ jsxs15("div", { children: [
        /* @__PURE__ */ jsx17("p", { className: "text-xs font-semibold uppercase tracking-[0.2em] text-zinc-400", children: "Admin / Shop" }),
        /* @__PURE__ */ jsx17("h1", { className: "mt-2 text-3xl font-black text-zinc-50 md:text-4xl", children: "Shop CRUD Management" }),
        /* @__PURE__ */ jsx17("p", { className: "mt-3 max-w-2xl text-zinc-300", children: "Create, edit, and delete merch items and membership plans used across the website." })
      ] }),
      /* @__PURE__ */ jsxs15("div", { className: "flex flex-wrap gap-3", children: [
        /* @__PURE__ */ jsxs15("button", { type: "button", onClick: () => {
          void loadShopData();
        }, className: "inline-flex items-center gap-2 rounded-lg border border-zinc-300/35 px-4 py-2 text-sm font-semibold text-zinc-100 transition hover:border-zinc-100", children: [
          /* @__PURE__ */ jsx17(RefreshCcw, { size: 16 }),
          " Refresh"
        ] }),
        /* @__PURE__ */ jsxs15(Link11, { to: "/admin", className: "inline-flex items-center gap-2 rounded-lg border border-zinc-300/35 px-4 py-2 text-sm font-semibold text-zinc-100 transition hover:border-zinc-100", children: [
          /* @__PURE__ */ jsx17(ArrowLeft4, { size: 16 }),
          " Admin Hub"
        ] }),
        /* @__PURE__ */ jsx17(Link11, { to: "/dashboard", className: "inline-flex items-center gap-2 rounded-lg border border-zinc-300/35 px-4 py-2 text-sm font-semibold text-zinc-100 transition hover:border-zinc-100", children: "Dashboard" })
      ] })
    ] }) }),
    error ? /* @__PURE__ */ jsx17("p", { className: "rounded-lg border border-rose-400/40 bg-rose-500/10 px-3 py-2 text-sm text-rose-200", children: error }) : null,
    /* @__PURE__ */ jsxs15("section", { className: "grid gap-6 lg:grid-cols-2", children: [
      /* @__PURE__ */ jsxs15("article", { className: "rounded-2xl border border-zinc-200/15 bg-zinc-900/60 p-6", children: [
        /* @__PURE__ */ jsxs15("div", { className: "mb-4 flex items-center gap-2 text-orange-100", children: [
          /* @__PURE__ */ jsx17(ShoppingBag, { size: 18 }),
          /* @__PURE__ */ jsx17("h2", { className: "text-xl font-bold text-zinc-50", children: "Merch Items" })
        ] }),
        /* @__PURE__ */ jsxs15("form", { onSubmit: handleSaveMerch, className: "space-y-3", children: [
          /* @__PURE__ */ jsx17("input", { type: "text", value: merchForm.name, onChange: (event) => setMerchForm((prev) => ({
            ...prev,
            name: event.target.value
          })), placeholder: "Item name", required: true, className: "w-full rounded-lg border border-zinc-200/20 bg-zinc-950/60 px-3 py-2 text-zinc-100" }),
          /* @__PURE__ */ jsx17("input", { type: "text", value: merchForm.price, onChange: (event) => setMerchForm((prev) => ({
            ...prev,
            price: event.target.value
          })), placeholder: "$34", required: true, className: "w-full rounded-lg border border-zinc-200/20 bg-zinc-950/60 px-3 py-2 text-zinc-100" }),
          /* @__PURE__ */ jsx17("textarea", { value: merchForm.description, onChange: (event) => setMerchForm((prev) => ({
            ...prev,
            description: event.target.value
          })), placeholder: "Description", required: true, className: "min-h-24 w-full rounded-lg border border-zinc-200/20 bg-zinc-950/60 px-3 py-2 text-zinc-100" }),
          /* @__PURE__ */ jsxs15("div", { className: "grid gap-3 sm:grid-cols-2", children: [
            /* @__PURE__ */ jsx17("input", { type: "number", min: 0, value: merchForm.sortOrder, onChange: (event) => setMerchForm((prev) => ({
              ...prev,
              sortOrder: Number(event.target.value)
            })), placeholder: "Sort order", className: "w-full rounded-lg border border-zinc-200/20 bg-zinc-950/60 px-3 py-2 text-zinc-100" }),
            /* @__PURE__ */ jsxs15("label", { className: "inline-flex items-center gap-2 rounded-lg border border-zinc-200/20 bg-zinc-950/60 px-3 py-2 text-sm text-zinc-200", children: [
              /* @__PURE__ */ jsx17("input", { type: "checkbox", checked: merchForm.isActive, onChange: (event) => setMerchForm((prev) => ({
                ...prev,
                isActive: event.target.checked
              })) }),
              "Active"
            ] })
          ] }),
          /* @__PURE__ */ jsxs15("div", { className: "flex flex-wrap gap-3", children: [
            /* @__PURE__ */ jsx17("button", { type: "submit", disabled: savingMerch, className: "rounded-lg bg-orange-300 px-4 py-2.5 font-semibold text-zinc-950 transition hover:bg-orange-200 disabled:opacity-70", children: savingMerch ? "Saving..." : merchForm.id ? "Update Item" : "Create Item" }),
            merchForm.id ? /* @__PURE__ */ jsx17("button", { type: "button", onClick: () => setMerchForm(emptyMerchForm), className: "rounded-lg border border-zinc-100/30 px-4 py-2.5 font-semibold text-zinc-100", children: "Cancel Edit" }) : null
          ] })
        ] }),
        !loading ? /* @__PURE__ */ jsx17("div", { className: "mt-6 space-y-3", children: merchItems.map((item) => /* @__PURE__ */ jsx17("div", { className: "rounded-lg border border-zinc-200/15 bg-zinc-950/50 p-3", children: /* @__PURE__ */ jsxs15("div", { className: "flex items-start justify-between gap-3", children: [
          /* @__PURE__ */ jsxs15("div", { children: [
            /* @__PURE__ */ jsx17("p", { className: "font-semibold text-zinc-50", children: item.name }),
            /* @__PURE__ */ jsx17("p", { className: "text-sm text-zinc-300", children: item.price }),
            /* @__PURE__ */ jsx17("p", { className: "mt-1 text-xs text-zinc-400", children: item.description }),
            /* @__PURE__ */ jsxs15("p", { className: "mt-1 text-xs text-zinc-500", children: [
              "Sort: ",
              item.sort_order,
              " \xB7 ",
              item.is_active ? "Active" : "Inactive"
            ] })
          ] }),
          /* @__PURE__ */ jsxs15("div", { className: "flex gap-2", children: [
            /* @__PURE__ */ jsx17("button", { type: "button", onClick: () => setMerchForm({
              id: item.id,
              name: item.name,
              price: item.price,
              description: item.description,
              sortOrder: item.sort_order,
              isActive: item.is_active
            }), className: "rounded border border-zinc-100/25 px-3 py-1 text-xs font-semibold text-zinc-100", children: "Edit" }),
            /* @__PURE__ */ jsx17("button", { type: "button", onClick: () => {
              void handleDeleteMerch(item.id);
            }, className: "rounded border border-rose-300/40 px-2 py-1 text-rose-200", children: /* @__PURE__ */ jsx17(Trash2, { size: 14 }) })
          ] })
        ] }) }, item.id)) }) : null
      ] }),
      /* @__PURE__ */ jsxs15("article", { className: "rounded-2xl border border-zinc-200/15 bg-zinc-900/60 p-6", children: [
        /* @__PURE__ */ jsxs15("div", { className: "mb-4 flex items-center gap-2 text-orange-100", children: [
          /* @__PURE__ */ jsx17(Store4, { size: 18 }),
          /* @__PURE__ */ jsx17("h2", { className: "text-xl font-bold text-zinc-50", children: "Membership Plans" })
        ] }),
        /* @__PURE__ */ jsxs15("form", { onSubmit: handleSavePlan, className: "space-y-3", children: [
          /* @__PURE__ */ jsxs15("div", { className: "grid gap-3 sm:grid-cols-2", children: [
            /* @__PURE__ */ jsx17("input", { type: "text", value: planForm.slug, onChange: (event) => setPlanForm((prev) => ({
              ...prev,
              slug: event.target.value
            })), placeholder: "slug (e.g. all-access)", required: true, className: "w-full rounded-lg border border-zinc-200/20 bg-zinc-950/60 px-3 py-2 text-zinc-100" }),
            /* @__PURE__ */ jsx17("input", { type: "text", value: planForm.name, onChange: (event) => setPlanForm((prev) => ({
              ...prev,
              name: event.target.value
            })), placeholder: "Plan name", required: true, className: "w-full rounded-lg border border-zinc-200/20 bg-zinc-950/60 px-3 py-2 text-zinc-100" })
          ] }),
          /* @__PURE__ */ jsxs15("div", { className: "grid gap-3 sm:grid-cols-2", children: [
            /* @__PURE__ */ jsx17("input", { type: "text", value: planForm.displayPrice, onChange: (event) => setPlanForm((prev) => ({
              ...prev,
              displayPrice: event.target.value
            })), placeholder: "$19/mo", required: true, className: "w-full rounded-lg border border-zinc-200/20 bg-zinc-950/60 px-3 py-2 text-zinc-100" }),
            /* @__PURE__ */ jsx17("input", { type: "number", min: 0, value: planForm.priceCents, onChange: (event) => setPlanForm((prev) => ({
              ...prev,
              priceCents: Number(event.target.value)
            })), placeholder: "1900", required: true, className: "w-full rounded-lg border border-zinc-200/20 bg-zinc-950/60 px-3 py-2 text-zinc-100" })
          ] }),
          /* @__PURE__ */ jsx17("textarea", { value: planForm.description, onChange: (event) => setPlanForm((prev) => ({
            ...prev,
            description: event.target.value
          })), placeholder: "Description", required: true, className: "min-h-24 w-full rounded-lg border border-zinc-200/20 bg-zinc-950/60 px-3 py-2 text-zinc-100" }),
          /* @__PURE__ */ jsx17("textarea", { value: planForm.featuresText, onChange: (event) => setPlanForm((prev) => ({
            ...prev,
            featuresText: event.target.value
          })), placeholder: "Features (one per line)", required: true, className: "min-h-24 w-full rounded-lg border border-zinc-200/20 bg-zinc-950/60 px-3 py-2 text-zinc-100" }),
          /* @__PURE__ */ jsxs15("div", { className: "grid gap-3 sm:grid-cols-2", children: [
            /* @__PURE__ */ jsx17("input", { type: "number", min: 0, value: planForm.sortOrder, onChange: (event) => setPlanForm((prev) => ({
              ...prev,
              sortOrder: Number(event.target.value)
            })), placeholder: "Sort order", className: "w-full rounded-lg border border-zinc-200/20 bg-zinc-950/60 px-3 py-2 text-zinc-100" }),
            /* @__PURE__ */ jsxs15("label", { className: "inline-flex items-center gap-2 rounded-lg border border-zinc-200/20 bg-zinc-950/60 px-3 py-2 text-sm text-zinc-200", children: [
              /* @__PURE__ */ jsx17("input", { type: "checkbox", checked: planForm.isActive, onChange: (event) => setPlanForm((prev) => ({
                ...prev,
                isActive: event.target.checked
              })) }),
              "Active"
            ] })
          ] }),
          /* @__PURE__ */ jsxs15("div", { className: "flex flex-wrap gap-3", children: [
            /* @__PURE__ */ jsx17("button", { type: "submit", disabled: savingPlan, className: "rounded-lg bg-orange-300 px-4 py-2.5 font-semibold text-zinc-950 transition hover:bg-orange-200 disabled:opacity-70", children: savingPlan ? "Saving..." : planForm.id ? "Update Plan" : "Create Plan" }),
            planForm.id ? /* @__PURE__ */ jsx17("button", { type: "button", onClick: () => setPlanForm(emptyPlanForm), className: "rounded-lg border border-zinc-100/30 px-4 py-2.5 font-semibold text-zinc-100", children: "Cancel Edit" }) : null
          ] })
        ] }),
        !loading ? /* @__PURE__ */ jsx17("div", { className: "mt-6 space-y-3", children: membershipPlans.map((plan) => /* @__PURE__ */ jsx17("div", { className: "rounded-lg border border-zinc-200/15 bg-zinc-950/50 p-3", children: /* @__PURE__ */ jsxs15("div", { className: "flex items-start justify-between gap-3", children: [
          /* @__PURE__ */ jsxs15("div", { children: [
            /* @__PURE__ */ jsxs15("p", { className: "font-semibold text-zinc-50", children: [
              plan.name,
              " (",
              plan.slug,
              ")"
            ] }),
            /* @__PURE__ */ jsxs15("p", { className: "text-sm text-zinc-300", children: [
              plan.display_price,
              " \xB7 ",
              plan.price_cents,
              " cents"
            ] }),
            /* @__PURE__ */ jsx17("p", { className: "mt-1 text-xs text-zinc-400", children: plan.description }),
            /* @__PURE__ */ jsx17("p", { className: "mt-1 text-xs text-zinc-400", children: plan.features.join(" | ") }),
            /* @__PURE__ */ jsxs15("p", { className: "mt-1 text-xs text-zinc-500", children: [
              "Sort: ",
              plan.sort_order,
              " \xB7 ",
              plan.is_active ? "Active" : "Inactive"
            ] })
          ] }),
          /* @__PURE__ */ jsxs15("div", { className: "flex gap-2", children: [
            /* @__PURE__ */ jsx17("button", { type: "button", onClick: () => setPlanForm({
              id: plan.id,
              slug: plan.slug,
              name: plan.name,
              displayPrice: plan.display_price,
              priceCents: plan.price_cents,
              description: plan.description,
              featuresText: plan.features.join("\n"),
              sortOrder: plan.sort_order,
              isActive: plan.is_active
            }), className: "rounded border border-zinc-100/25 px-3 py-1 text-xs font-semibold text-zinc-100", children: "Edit" }),
            /* @__PURE__ */ jsx17("button", { type: "button", onClick: () => {
              void handleDeletePlan(plan.id);
            }, className: "rounded border border-rose-300/40 px-2 py-1 text-rose-200", children: /* @__PURE__ */ jsx17(Trash2, { size: 14 }) })
          ] })
        ] }) }, plan.id)) }) : null
      ] })
    ] }),
    /* @__PURE__ */ jsx17("section", { className: "grid gap-5", children: /* @__PURE__ */ jsxs15(Link11, { to: "/merch", className: "rounded-2xl border border-zinc-200/15 bg-zinc-900/60 p-5 transition hover:border-orange-300/40", children: [
      /* @__PURE__ */ jsx17("div", { className: "mb-3 inline-flex rounded-md border border-zinc-200/20 bg-zinc-950/70 p-2 text-orange-200", children: /* @__PURE__ */ jsx17(ShoppingBag, { size: 18 }) }),
      /* @__PURE__ */ jsx17("h2", { className: "text-xl font-bold text-zinc-50", children: "Open Merch Page" }),
      /* @__PURE__ */ jsx17("p", { className: "mt-2 text-sm text-zinc-300", children: "Preview public merch items after saving changes." })
    ] }) })
  ] }) });
}
var emptyMerchForm, emptyPlanForm;
var init_admin_shop_PTpzx7UB = __esm({
  "dist/server/assets/admin.shop-PTpzx7UB.js"() {
    "use strict";
    init_router_BDBFyAOM();
    emptyMerchForm = {
      id: "",
      name: "",
      price: "",
      description: "",
      sortOrder: 0,
      isActive: true
    };
    emptyPlanForm = {
      id: "",
      slug: "",
      name: "",
      displayPrice: "",
      priceCents: 0,
      description: "",
      featuresText: "",
      sortOrder: 0,
      isActive: true
    };
  }
});

// dist/server/assets/dashboard.tools._tool-08iLNKOK.js
var dashboard_tools_tool_08iLNKOK_exports = {};
__export(dashboard_tools_tool_08iLNKOK_exports, {
  component: () => DashboardToolPage
});
import { jsxs as jsxs16, jsx as jsx18, Fragment as Fragment6 } from "react/jsx-runtime";
import { Link as Link12, notFound } from "@tanstack/react-router";
import { ArrowLeft as ArrowLeft5, Plus, X, Briefcase, Search as Search2, Clock, Users as Users6, ExternalLink as ExternalLink3, ChevronUp, ChevronDown as ChevronDown3, Check as Check3, Send, Radio as Radio2, Globe, DollarSign as DollarSign2, Share2, Settings as Settings2, Save as Save2, Trash2 as Trash22, Eye, BookOpen, TrendingUp, Megaphone as Megaphone2, Copy, Calendar, FileText, Tag, LayoutTemplate, GraduationCap } from "lucide-react";
import { useState as useState13, useEffect as useEffect12, useMemo as useMemo4, useRef as useRef5 } from "react";
import "@supabase/supabase-js";
import "stripe";
import "zod";
function statusBadge(status) {
  const styles = {
    open: "border-emerald-300/40 text-emerald-300",
    closed: "border-zinc-500/40 text-zinc-400",
    completed: "border-violet-300/40 text-violet-300",
    pending: "border-orange-300/40 text-orange-300",
    accepted: "border-emerald-300/40 text-emerald-300",
    rejected: "border-rose-300/40 text-rose-300"
  };
  return `rounded-full border px-2.5 py-0.5 text-xs font-semibold uppercase tracking-wide ${styles[status] || "border-zinc-300/40 text-zinc-300"}`;
}
function Avatar({ url, name, size = 10 }) {
  const initials = name.split("@")[0].slice(0, 2).toUpperCase();
  const sizeClass = `h-${size} w-${size}`;
  if (url) {
    return /* @__PURE__ */ jsx18(
      "img",
      {
        src: url,
        alt: name,
        className: `${sizeClass} rounded-full object-cover border border-zinc-200/20 flex-shrink-0`
      }
    );
  }
  return /* @__PURE__ */ jsx18(
    "div",
    {
      className: `${sizeClass} flex flex-shrink-0 items-center justify-center rounded-full bg-orange-300/20 border border-orange-300/30 text-xs font-bold text-orange-200`,
      children: initials
    }
  );
}
function SkillChip({ label }) {
  return /* @__PURE__ */ jsx18("span", { className: "rounded-full border border-zinc-200/20 bg-zinc-800/60 px-2.5 py-0.5 text-xs text-zinc-300", children: label });
}
function ApplicantsDrawer({
  requestId,
  requestTitle,
  onClose
}) {
  const [applicants, setApplicants] = useState13([]);
  const [loading, setLoading] = useState13(true);
  const [busyId, setBusyId] = useState13(null);
  const load = async () => {
    const response = await authedFetch(`/api/collab/applicants?requestId=${requestId}`);
    if (response.ok) {
      const data = await response.json();
      setApplicants(data.applicants || []);
    }
    setLoading(false);
  };
  useEffect12(() => {
    void load();
  }, [requestId]);
  const updateStatus = async (applicationId, status) => {
    setBusyId(applicationId);
    const response = await authedFetch("/api/collab/applicants", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ applicationId, status })
    });
    if (response.ok) {
      setApplicants(
        (prev) => prev.map((a) => a.id === applicationId ? { ...a, status } : a)
      );
    }
    setBusyId(null);
  };
  const pending = applicants.filter((a) => a.status === "pending");
  const decided = applicants.filter((a) => a.status !== "pending");
  return /* @__PURE__ */ jsx18(
    "div",
    {
      className: "fixed inset-0 z-50 flex items-start justify-end bg-zinc-950/70 backdrop-blur-sm",
      onClick: onClose,
      children: /* @__PURE__ */ jsxs16(
        "aside",
        {
          className: "relative flex h-full w-full max-w-lg flex-col overflow-y-auto bg-zinc-900 p-6 shadow-2xl",
          onClick: (e) => e.stopPropagation(),
          children: [
            /* @__PURE__ */ jsx18(
              "button",
              {
                type: "button",
                onClick: onClose,
                className: "absolute right-4 top-4 rounded-lg border border-zinc-200/20 p-1.5 text-zinc-400 transition hover:text-zinc-50",
                children: /* @__PURE__ */ jsx18(X, { size: 18 })
              }
            ),
            /* @__PURE__ */ jsx18("p", { className: "text-xs font-semibold uppercase tracking-[0.15em] text-zinc-400", children: "Applicants" }),
            /* @__PURE__ */ jsx18("h2", { className: "mt-1 text-xl font-bold text-zinc-50 pr-8", children: requestTitle }),
            loading ? /* @__PURE__ */ jsx18("p", { className: "mt-6 text-sm text-zinc-400", children: "Loading applicants..." }) : applicants.length === 0 ? /* @__PURE__ */ jsxs16("div", { className: "mt-8 rounded-xl border border-zinc-200/15 bg-zinc-800/60 p-6 text-center", children: [
              /* @__PURE__ */ jsx18(Users6, { size: 24, className: "mx-auto mb-2 text-zinc-500" }),
              /* @__PURE__ */ jsx18("p", { className: "text-sm text-zinc-400", children: "No one has applied yet." })
            ] }) : /* @__PURE__ */ jsxs16("div", { className: "mt-6 space-y-6", children: [
              pending.length > 0 && /* @__PURE__ */ jsxs16("section", { children: [
                /* @__PURE__ */ jsxs16("h3", { className: "mb-3 text-sm font-semibold text-orange-200", children: [
                  "Pending (",
                  pending.length,
                  ")"
                ] }),
                /* @__PURE__ */ jsx18("div", { className: "space-y-3", children: pending.map((applicant) => /* @__PURE__ */ jsx18(
                  ApplicantCard,
                  {
                    applicant,
                    busy: busyId === applicant.id,
                    onAccept: () => {
                      void updateStatus(applicant.id, "accepted");
                    },
                    onReject: () => {
                      void updateStatus(applicant.id, "rejected");
                    }
                  },
                  applicant.id
                )) })
              ] }),
              decided.length > 0 && /* @__PURE__ */ jsxs16("section", { children: [
                /* @__PURE__ */ jsxs16("h3", { className: "mb-3 text-sm font-semibold text-zinc-400", children: [
                  "Decided (",
                  decided.length,
                  ")"
                ] }),
                /* @__PURE__ */ jsx18("div", { className: "space-y-3", children: decided.map((applicant) => /* @__PURE__ */ jsx18(
                  ApplicantCard,
                  {
                    applicant,
                    busy: busyId === applicant.id,
                    onAccept: () => {
                      void updateStatus(applicant.id, "accepted");
                    },
                    onReject: () => {
                      void updateStatus(applicant.id, "rejected");
                    }
                  },
                  applicant.id
                )) })
              ] })
            ] })
          ]
        }
      )
    }
  );
}
function ApplicantCard({
  applicant,
  busy,
  onAccept,
  onReject
}) {
  const name = applicant.profile?.display_name || applicant.applicant_email.split("@")[0];
  return /* @__PURE__ */ jsxs16("article", { className: "rounded-xl border border-zinc-200/15 bg-zinc-800/60 p-4", children: [
    /* @__PURE__ */ jsxs16("div", { className: "flex items-start gap-3", children: [
      /* @__PURE__ */ jsx18(Avatar, { url: applicant.profile?.avatar_url || null, name, size: 10 }),
      /* @__PURE__ */ jsxs16("div", { className: "flex-1 min-w-0", children: [
        /* @__PURE__ */ jsxs16("div", { className: "flex items-center gap-2 flex-wrap", children: [
          /* @__PURE__ */ jsx18("span", { className: "font-semibold text-zinc-100 truncate", children: name }),
          /* @__PURE__ */ jsx18("span", { className: statusBadge(applicant.status), children: applicant.status })
        ] }),
        /* @__PURE__ */ jsx18("p", { className: "text-xs text-zinc-500 mt-0.5", children: applicant.applicant_email }),
        applicant.profile?.bio ? /* @__PURE__ */ jsx18("p", { className: "mt-1.5 text-sm text-zinc-400 line-clamp-2", children: applicant.profile.bio }) : null,
        applicant.profile?.skills?.length ? /* @__PURE__ */ jsx18("div", { className: "mt-2 flex flex-wrap gap-1", children: applicant.profile.skills.slice(0, 5).map((s) => /* @__PURE__ */ jsx18(SkillChip, { label: s }, s)) }) : null,
        applicant.message ? /* @__PURE__ */ jsxs16("blockquote", { className: "mt-2 rounded-lg border border-zinc-200/10 bg-zinc-900/60 px-3 py-2 text-sm text-zinc-300 italic", children: [
          '"',
          applicant.message,
          '"'
        ] }) : null,
        /* @__PURE__ */ jsxs16("p", { className: "mt-2 text-xs text-zinc-500", children: [
          "Applied ",
          new Date(applicant.applied_at).toLocaleDateString()
        ] })
      ] })
    ] }),
    applicant.status === "pending" ? /* @__PURE__ */ jsxs16("div", { className: "mt-3 flex gap-2", children: [
      /* @__PURE__ */ jsx18(
        "button",
        {
          type: "button",
          onClick: onAccept,
          disabled: busy,
          className: "flex-1 rounded-lg bg-emerald-600 py-2 text-sm font-semibold text-white transition hover:bg-emerald-500 disabled:opacity-60",
          children: busy ? "..." : "\u2713 Accept"
        }
      ),
      /* @__PURE__ */ jsx18(
        "button",
        {
          type: "button",
          onClick: onReject,
          disabled: busy,
          className: "flex-1 rounded-lg border border-rose-300/30 py-2 text-sm font-semibold text-rose-300 transition hover:border-rose-200 disabled:opacity-60",
          children: busy ? "..." : "\u2715 Decline"
        }
      )
    ] }) : null
  ] });
}
function ApplyModal({
  request,
  onClose,
  onSuccess
}) {
  const [message, setMessage] = useState13("");
  const [busy, setBusy] = useState13(false);
  const [error, setError] = useState13("");
  const submit = async () => {
    setBusy(true);
    setError("");
    const response = await authedFetch("/api/collab/apply", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ requestId: request.id, message })
    });
    if (response.ok) {
      onSuccess();
      onClose();
    } else {
      const data = await response.json();
      setError(data.error || "Could not submit application.");
    }
    setBusy(false);
  };
  return /* @__PURE__ */ jsx18(
    "div",
    {
      className: "fixed inset-0 z-50 flex items-center justify-center bg-zinc-950/70 backdrop-blur-sm p-4",
      onClick: onClose,
      children: /* @__PURE__ */ jsxs16(
        "div",
        {
          className: "w-full max-w-md rounded-2xl border border-zinc-200/15 bg-zinc-900 p-6 shadow-2xl",
          onClick: (e) => e.stopPropagation(),
          children: [
            /* @__PURE__ */ jsxs16("div", { className: "flex items-start justify-between gap-2", children: [
              /* @__PURE__ */ jsxs16("div", { children: [
                /* @__PURE__ */ jsx18("p", { className: "text-xs font-semibold uppercase tracking-[0.15em] text-zinc-400", children: "Apply to Collaborate" }),
                /* @__PURE__ */ jsx18("h3", { className: "mt-1 text-lg font-bold text-zinc-50", children: request.title })
              ] }),
              /* @__PURE__ */ jsx18("button", { type: "button", onClick: onClose, className: "rounded-lg border border-zinc-200/20 p-1.5 text-zinc-400 hover:text-zinc-50", children: /* @__PURE__ */ jsx18(X, { size: 16 }) })
            ] }),
            /* @__PURE__ */ jsxs16("div", { className: "mt-4", children: [
              /* @__PURE__ */ jsx18("label", { className: "mb-1.5 block text-sm font-medium text-zinc-300", children: "Why are you a great fit? (optional)" }),
              /* @__PURE__ */ jsx18(
                "textarea",
                {
                  value: message,
                  onChange: (e) => setMessage(e.target.value),
                  rows: 4,
                  maxLength: 500,
                  placeholder: "Tell the owner a bit about yourself and what you bring to this collaboration...",
                  className: "w-full rounded-lg border border-zinc-200/20 bg-zinc-950/60 px-3 py-2 text-sm text-zinc-100 outline-none transition focus:border-orange-200/70 resize-none"
                }
              ),
              /* @__PURE__ */ jsxs16("p", { className: "mt-1 text-right text-xs text-zinc-500", children: [
                message.length,
                "/500"
              ] })
            ] }),
            error ? /* @__PURE__ */ jsx18("p", { className: "mt-3 rounded-lg border border-rose-400/40 bg-rose-500/10 px-3 py-2 text-sm text-rose-200", children: error }) : null,
            /* @__PURE__ */ jsxs16(
              "button",
              {
                type: "button",
                onClick: () => {
                  void submit();
                },
                disabled: busy,
                className: "mt-4 flex w-full items-center justify-center gap-2 rounded-lg bg-orange-300 py-2.5 font-semibold text-zinc-950 transition hover:bg-orange-200 disabled:opacity-70",
                children: [
                  /* @__PURE__ */ jsx18(Send, { size: 16 }),
                  " ",
                  busy ? "Sending..." : "Submit Application"
                ]
              }
            )
          ]
        }
      )
    }
  );
}
function RequestCard({
  req,
  onApply,
  onViewApplicants,
  onClose,
  onDelete
}) {
  const [expanded, setExpanded] = useState13(false);
  return /* @__PURE__ */ jsxs16("article", { className: "rounded-2xl border border-zinc-200/15 bg-zinc-900/60 p-5 transition hover:border-zinc-200/25", children: [
    /* @__PURE__ */ jsxs16("div", { className: "flex items-start gap-3", children: [
      /* @__PURE__ */ jsxs16("div", { className: "flex-1 min-w-0", children: [
        /* @__PURE__ */ jsxs16("div", { className: "flex flex-wrap items-center gap-2", children: [
          /* @__PURE__ */ jsx18("span", { className: statusBadge(req.status), children: req.status }),
          /* @__PURE__ */ jsxs16("span", { className: "flex items-center gap-1 text-xs text-zinc-500", children: [
            /* @__PURE__ */ jsx18(Users6, { size: 11 }),
            " ",
            req.spots_available,
            " spot",
            req.spots_available !== 1 ? "s" : ""
          ] }),
          req.isOwner && req.applicantCount > 0 ? /* @__PURE__ */ jsxs16("span", { className: "rounded-full border border-orange-300/40 bg-orange-300/10 px-2 py-0.5 text-xs font-semibold text-orange-200", children: [
            req.applicantCount,
            " applicant",
            req.applicantCount !== 1 ? "s" : ""
          ] }) : null
        ] }),
        /* @__PURE__ */ jsx18("h3", { className: "mt-2 text-base font-bold text-zinc-50", children: req.title }),
        /* @__PURE__ */ jsxs16("p", { className: "mt-0.5 text-xs text-zinc-500", children: [
          "by ",
          req.owner_email.split("@")[0]
        ] }),
        req.description ? /* @__PURE__ */ jsx18("p", { className: `mt-2 text-sm text-zinc-400 ${expanded ? "" : "line-clamp-2"}`, children: req.description }) : null,
        req.skills_needed.length > 0 ? /* @__PURE__ */ jsx18("div", { className: "mt-3 flex flex-wrap gap-1.5", children: req.skills_needed.map((s) => /* @__PURE__ */ jsx18(SkillChip, { label: s }, s)) }) : null,
        req.project_url ? /* @__PURE__ */ jsxs16(
          "a",
          {
            href: req.project_url,
            target: "_blank",
            rel: "noopener noreferrer",
            className: "mt-2 inline-flex items-center gap-1 text-xs text-orange-200 transition hover:text-orange-100",
            children: [
              /* @__PURE__ */ jsx18(ExternalLink3, { size: 11 }),
              " View Project"
            ]
          }
        ) : null
      ] }),
      /* @__PURE__ */ jsx18(
        "button",
        {
          type: "button",
          onClick: () => setExpanded((v) => !v),
          className: "rounded-lg border border-zinc-200/15 p-1.5 text-zinc-500 transition hover:text-zinc-300",
          children: expanded ? /* @__PURE__ */ jsx18(ChevronUp, { size: 14 }) : /* @__PURE__ */ jsx18(ChevronDown3, { size: 14 })
        }
      )
    ] }),
    expanded ? /* @__PURE__ */ jsxs16("div", { className: "mt-4 flex items-center gap-2 border-t border-zinc-200/10 pt-4 flex-wrap", children: [
      /* @__PURE__ */ jsxs16("p", { className: "text-xs text-zinc-500 flex-1", children: [
        "Posted ",
        new Date(req.created_at).toLocaleDateString()
      ] }),
      req.isOwner ? /* @__PURE__ */ jsxs16(Fragment6, { children: [
        /* @__PURE__ */ jsxs16(
          "button",
          {
            type: "button",
            onClick: () => onViewApplicants(req),
            className: "inline-flex items-center gap-1.5 rounded-lg border border-zinc-200/20 px-3 py-1.5 text-xs font-semibold text-zinc-100 transition hover:border-orange-200/40",
            children: [
              /* @__PURE__ */ jsx18(Users6, { size: 12 }),
              " Applicants ",
              req.applicantCount > 0 ? `(${req.applicantCount})` : ""
            ]
          }
        ),
        req.status === "open" ? /* @__PURE__ */ jsx18(
          "button",
          {
            type: "button",
            onClick: () => onClose(req),
            className: "rounded-lg border border-zinc-200/20 px-3 py-1.5 text-xs font-semibold text-zinc-400 transition hover:border-zinc-200/40 hover:text-zinc-200",
            children: "Close Request"
          }
        ) : null,
        /* @__PURE__ */ jsx18(
          "button",
          {
            type: "button",
            onClick: () => onDelete(req.id),
            className: "rounded-lg border border-rose-300/20 px-3 py-1.5 text-xs font-semibold text-rose-300 transition hover:border-rose-200/50",
            children: "Delete"
          }
        )
      ] }) : /* @__PURE__ */ jsx18(Fragment6, { children: req.hasApplied ? /* @__PURE__ */ jsxs16("span", { className: "inline-flex items-center gap-1.5 rounded-lg border border-emerald-300/40 bg-emerald-300/5 px-3 py-1.5 text-xs font-semibold text-emerald-300", children: [
        /* @__PURE__ */ jsx18(Check3, { size: 12 }),
        " Applied"
      ] }) : req.status === "open" ? /* @__PURE__ */ jsxs16(
        "button",
        {
          type: "button",
          onClick: () => onApply(req),
          className: "inline-flex items-center gap-1.5 rounded-lg bg-orange-300 px-3 py-1.5 text-xs font-semibold text-zinc-950 transition hover:bg-orange-200",
          children: [
            /* @__PURE__ */ jsx18(Send, { size: 12 }),
            " Apply"
          ]
        }
      ) : null })
    ] }) : null
  ] });
}
function CollaborationHub() {
  const [tab, setTab] = useState13("browse");
  const [browseRequests, setBrowseRequests] = useState13([]);
  const [myRequests, setMyRequests] = useState13([]);
  const [myApplications, setMyApplications] = useState13([]);
  const [loading, setLoading] = useState13(true);
  const [error, setError] = useState13("");
  const [search, setSearch] = useState13("");
  const [applyTarget, setApplyTarget] = useState13(null);
  const [applicantsTarget, setApplicantsTarget] = useState13(null);
  const [showCreate, setShowCreate] = useState13(false);
  const [createTitle, setCreateTitle] = useState13("");
  const [createDescription, setCreateDescription] = useState13("");
  const [createSkills, setCreateSkills] = useState13("");
  const [createSpots, setCreateSpots] = useState13("1");
  const [createUrl, setCreateUrl] = useState13("");
  const [createBusy, setCreateBusy] = useState13(false);
  const loadBrowse = async () => {
    const response = await authedFetch("/api/collab");
    if (response.ok) {
      const data = await response.json();
      setBrowseRequests(data.requests || []);
    }
  };
  const loadMine = async () => {
    const response = await authedFetch("/api/collab?mine=1");
    if (response.ok) {
      const data = await response.json();
      setMyRequests(data.requests || []);
    }
  };
  const loadApplications = async () => {
    const response = await authedFetch("/api/collab/apply");
    if (response.ok) {
      const data = await response.json();
      setMyApplications(data.applications || []);
    }
  };
  useEffect12(() => {
    void (async () => {
      try {
        setLoading(true);
        await Promise.all([loadBrowse(), loadMine(), loadApplications()]);
      } catch {
        setError("Failed to load collaboration hub.");
      } finally {
        setLoading(false);
      }
    })();
  }, []);
  const handleCreate = async () => {
    if (!createTitle.trim()) {
      setError("Title is required.");
      return;
    }
    setCreateBusy(true);
    setError("");
    const response = await authedFetch("/api/collab", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        title: createTitle.trim(),
        description: createDescription.trim(),
        skillsNeeded: createSkills.split(",").map((s) => s.trim()).filter(Boolean),
        spotsAvailable: Math.max(1, parseInt(createSpots) || 1),
        projectUrl: createUrl.trim() || void 0
      })
    });
    if (response.ok) {
      setCreateTitle("");
      setCreateDescription("");
      setCreateSkills("");
      setCreateSpots("1");
      setCreateUrl("");
      setShowCreate(false);
      await Promise.all([loadBrowse(), loadMine()]);
      setTab("my-projects");
    } else {
      const data = await response.json();
      setError(data.error || "Could not create request.");
    }
    setCreateBusy(false);
  };
  const handleClose = async (req) => {
    await authedFetch("/api/collab", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: req.id, status: "closed" })
    });
    await Promise.all([loadBrowse(), loadMine()]);
  };
  const handleDelete = async (id) => {
    if (!confirm("Delete this collab request? This cannot be undone.")) return;
    await authedFetch("/api/collab", {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id })
    });
    await Promise.all([loadBrowse(), loadMine()]);
  };
  const displayed = useMemo4(() => {
    const list = tab === "browse" ? browseRequests : tab === "my-projects" ? myRequests : [];
    if (!search) return list;
    const q = search.toLowerCase();
    return list.filter(
      (r) => r.title.toLowerCase().includes(q) || r.description.toLowerCase().includes(q) || r.skills_needed.some((s) => s.toLowerCase().includes(q))
    );
  }, [tab, browseRequests, myRequests, search]);
  return /* @__PURE__ */ jsxs16("div", { className: "min-h-screen px-4 py-10 text-zinc-100", children: [
    /* @__PURE__ */ jsxs16("div", { className: "mx-auto max-w-5xl space-y-6", children: [
      /* @__PURE__ */ jsx18("header", { className: "rounded-2xl border border-zinc-200/15 bg-zinc-900/60 p-6", children: /* @__PURE__ */ jsxs16("div", { className: "flex flex-wrap items-center justify-between gap-4", children: [
        /* @__PURE__ */ jsxs16("div", { children: [
          /* @__PURE__ */ jsx18("p", { className: "text-xs font-semibold uppercase tracking-[0.2em] text-zinc-400", children: "Dashboard Tool" }),
          /* @__PURE__ */ jsx18("h1", { className: "mt-2 text-3xl font-black text-zinc-50", children: "Collaboration Hub" }),
          /* @__PURE__ */ jsx18("p", { className: "mt-1 text-sm text-zinc-400", children: "Post collab requests, find partners, and build projects together." })
        ] }),
        /* @__PURE__ */ jsxs16("div", { className: "flex gap-3", children: [
          /* @__PURE__ */ jsxs16(
            Link12,
            {
              to: "/dashboard",
              className: "inline-flex items-center gap-2 rounded-lg border border-zinc-100/25 px-4 py-2 text-sm font-semibold text-zinc-100 transition hover:border-orange-200/70 hover:text-orange-100",
              children: [
                /* @__PURE__ */ jsx18(ArrowLeft5, { size: 16 }),
                " Dashboard"
              ]
            }
          ),
          /* @__PURE__ */ jsxs16(
            "button",
            {
              type: "button",
              onClick: () => setShowCreate((v) => !v),
              className: "inline-flex items-center gap-2 rounded-lg bg-orange-300 px-4 py-2 text-sm font-semibold text-zinc-950 transition hover:bg-orange-200",
              children: [
                /* @__PURE__ */ jsx18(Plus, { size: 16 }),
                " Post Request"
              ]
            }
          )
        ] })
      ] }) }),
      showCreate ? /* @__PURE__ */ jsxs16("section", { className: "rounded-2xl border border-orange-200/30 bg-zinc-900/60 p-6", children: [
        /* @__PURE__ */ jsxs16("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ jsx18("h2", { className: "text-lg font-bold text-zinc-50", children: "Post a Collaboration Request" }),
          /* @__PURE__ */ jsx18("button", { type: "button", onClick: () => setShowCreate(false), className: "rounded-lg border border-zinc-200/20 p-1.5 text-zinc-400 hover:text-zinc-50", children: /* @__PURE__ */ jsx18(X, { size: 16 }) })
        ] }),
        /* @__PURE__ */ jsxs16("div", { className: "mt-4 grid gap-3 sm:grid-cols-2", children: [
          /* @__PURE__ */ jsx18(
            "input",
            {
              type: "text",
              value: createTitle,
              onChange: (e) => setCreateTitle(e.target.value),
              placeholder: "Project / collab title",
              className: "sm:col-span-2 rounded-lg border border-zinc-200/20 bg-zinc-950/60 px-3 py-2 text-zinc-100 outline-none focus:border-orange-200/70"
            }
          ),
          /* @__PURE__ */ jsx18(
            "textarea",
            {
              value: createDescription,
              onChange: (e) => setCreateDescription(e.target.value),
              rows: 4,
              placeholder: "Describe the project, goals, and what kind of collaborators you're looking for...",
              className: "sm:col-span-2 rounded-lg border border-zinc-200/20 bg-zinc-950/60 px-3 py-2 text-sm text-zinc-100 outline-none focus:border-orange-200/70 resize-none"
            }
          ),
          /* @__PURE__ */ jsxs16("div", { children: [
            /* @__PURE__ */ jsx18("label", { className: "mb-1 block text-xs font-medium text-zinc-400", children: "Skills Needed (comma-separated)" }),
            /* @__PURE__ */ jsx18(
              "input",
              {
                type: "text",
                value: createSkills,
                onChange: (e) => setCreateSkills(e.target.value),
                placeholder: "Video editing, Copywriting, Design...",
                className: "w-full rounded-lg border border-zinc-200/20 bg-zinc-950/60 px-3 py-2 text-zinc-100 outline-none focus:border-orange-200/70"
              }
            )
          ] }),
          /* @__PURE__ */ jsxs16("div", { children: [
            /* @__PURE__ */ jsx18("label", { className: "mb-1 block text-xs font-medium text-zinc-400", children: "Spots Available" }),
            /* @__PURE__ */ jsx18(
              "input",
              {
                type: "number",
                min: "1",
                max: "20",
                value: createSpots,
                onChange: (e) => setCreateSpots(e.target.value),
                className: "w-full rounded-lg border border-zinc-200/20 bg-zinc-950/60 px-3 py-2 text-zinc-100 outline-none focus:border-orange-200/70"
              }
            )
          ] }),
          /* @__PURE__ */ jsxs16("div", { className: "sm:col-span-2", children: [
            /* @__PURE__ */ jsx18("label", { className: "mb-1 block text-xs font-medium text-zinc-400", children: "Project URL (optional)" }),
            /* @__PURE__ */ jsx18(
              "input",
              {
                type: "url",
                value: createUrl,
                onChange: (e) => setCreateUrl(e.target.value),
                placeholder: "https://...",
                className: "w-full rounded-lg border border-zinc-200/20 bg-zinc-950/60 px-3 py-2 text-zinc-100 outline-none focus:border-orange-200/70"
              }
            )
          ] })
        ] }),
        error ? /* @__PURE__ */ jsx18("p", { className: "mt-3 rounded-lg border border-rose-400/40 bg-rose-500/10 px-3 py-2 text-sm text-rose-200", children: error }) : null,
        /* @__PURE__ */ jsxs16(
          "button",
          {
            type: "button",
            onClick: () => {
              void handleCreate();
            },
            disabled: createBusy,
            className: "mt-4 inline-flex items-center gap-2 rounded-lg bg-orange-300 px-4 py-2 font-semibold text-zinc-950 transition hover:bg-orange-200 disabled:opacity-70",
            children: [
              /* @__PURE__ */ jsx18(Briefcase, { size: 16 }),
              " ",
              createBusy ? "Posting..." : "Post Request"
            ]
          }
        )
      ] }) : null,
      error && !showCreate ? /* @__PURE__ */ jsx18("p", { className: "rounded-lg border border-rose-400/40 bg-rose-500/10 px-3 py-2 text-sm text-rose-200", children: error }) : null,
      /* @__PURE__ */ jsx18("div", { className: "flex flex-wrap gap-1 rounded-xl border border-zinc-200/15 bg-zinc-900/60 p-1", children: [
        { key: "browse", label: "Browse", count: browseRequests.length },
        { key: "my-projects", label: "My Projects", count: myRequests.length },
        { key: "my-applications", label: "My Applications", count: myApplications.length }
      ].map(({ key, label, count }) => /* @__PURE__ */ jsxs16(
        "button",
        {
          type: "button",
          onClick: () => setTab(key),
          className: `flex items-center gap-2 rounded-lg px-4 py-2 text-sm font-semibold transition ${tab === key ? "bg-orange-300 text-zinc-950" : "text-zinc-300 hover:text-zinc-50"}`,
          children: [
            label,
            count > 0 ? /* @__PURE__ */ jsx18("span", { className: `rounded-full px-1.5 py-0.5 text-xs ${tab === key ? "bg-zinc-950/20" : "bg-zinc-700"}`, children: count }) : null
          ]
        },
        key
      )) }),
      tab !== "my-applications" ? /* @__PURE__ */ jsxs16("div", { className: "relative", children: [
        /* @__PURE__ */ jsx18(Search2, { size: 15, className: "absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400" }),
        /* @__PURE__ */ jsx18(
          "input",
          {
            type: "text",
            value: search,
            onChange: (e) => setSearch(e.target.value),
            placeholder: "Search by title, description, or skill...",
            className: "w-full rounded-lg border border-zinc-200/20 bg-zinc-900/60 py-2 pl-9 pr-3 text-sm text-zinc-100 outline-none transition focus:border-orange-200/70"
          }
        )
      ] }) : null,
      loading ? /* @__PURE__ */ jsx18("p", { className: "text-zinc-400", children: "Loading..." }) : null,
      !loading && tab !== "my-applications" ? /* @__PURE__ */ jsx18("div", { className: "space-y-4", children: displayed.length === 0 ? /* @__PURE__ */ jsxs16("div", { className: "rounded-2xl border border-zinc-200/15 bg-zinc-900/60 p-8 text-center", children: [
        /* @__PURE__ */ jsx18(Briefcase, { size: 28, className: "mx-auto mb-3 text-zinc-500" }),
        /* @__PURE__ */ jsx18("p", { className: "font-semibold text-zinc-300", children: tab === "browse" ? "No open collab requests right now." : "You haven't posted any requests yet." }),
        tab === "my-projects" ? /* @__PURE__ */ jsxs16(
          "button",
          {
            type: "button",
            onClick: () => setShowCreate(true),
            className: "mt-4 inline-flex items-center gap-2 rounded-lg bg-orange-300 px-4 py-2 text-sm font-semibold text-zinc-950 transition hover:bg-orange-200",
            children: [
              /* @__PURE__ */ jsx18(Plus, { size: 14 }),
              " Post Your First Request"
            ]
          }
        ) : null
      ] }) : displayed.map((req) => /* @__PURE__ */ jsx18(
        RequestCard,
        {
          req,
          onApply: setApplyTarget,
          onViewApplicants: setApplicantsTarget,
          onClose: handleClose,
          onDelete: handleDelete
        },
        req.id
      )) }) : null,
      !loading && tab === "my-applications" ? /* @__PURE__ */ jsx18("div", { className: "space-y-3", children: myApplications.length === 0 ? /* @__PURE__ */ jsxs16("div", { className: "rounded-2xl border border-zinc-200/15 bg-zinc-900/60 p-8 text-center", children: [
        /* @__PURE__ */ jsx18(Clock, { size: 28, className: "mx-auto mb-3 text-zinc-500" }),
        /* @__PURE__ */ jsx18("p", { className: "font-semibold text-zinc-300", children: "No applications yet." }),
        /* @__PURE__ */ jsx18("p", { className: "mt-1 text-sm text-zinc-500", children: "Browse open requests and apply to collaborate." })
      ] }) : myApplications.map((app) => /* @__PURE__ */ jsxs16("article", { className: "rounded-2xl border border-zinc-200/15 bg-zinc-900/60 p-4", children: [
        /* @__PURE__ */ jsxs16("div", { className: "flex items-start justify-between gap-3 flex-wrap", children: [
          /* @__PURE__ */ jsxs16("div", { children: [
            /* @__PURE__ */ jsx18("h3", { className: "font-semibold text-zinc-50", children: app.requestTitle || "Unknown Project" }),
            /* @__PURE__ */ jsxs16("p", { className: "text-xs text-zinc-500", children: [
              "by ",
              app.requestOwner?.split("@")[0] || "\u2014"
            ] }),
            app.message ? /* @__PURE__ */ jsxs16("p", { className: "mt-1.5 text-sm text-zinc-400 italic", children: [
              '"',
              app.message,
              '"'
            ] }) : null
          ] }),
          /* @__PURE__ */ jsx18("span", { className: statusBadge(app.status), children: app.status })
        ] }),
        /* @__PURE__ */ jsxs16("p", { className: "mt-2 text-xs text-zinc-500", children: [
          "Applied ",
          new Date(app.applied_at).toLocaleDateString()
        ] })
      ] }, app.id)) }) : null
    ] }),
    applyTarget ? /* @__PURE__ */ jsx18(
      ApplyModal,
      {
        request: applyTarget,
        onClose: () => setApplyTarget(null),
        onSuccess: () => {
          void Promise.all([loadBrowse(), loadMine(), loadApplications()]);
        }
      }
    ) : null,
    applicantsTarget ? /* @__PURE__ */ jsx18(
      ApplicantsDrawer,
      {
        requestId: applicantsTarget.id,
        requestTitle: applicantsTarget.title,
        onClose: () => setApplicantsTarget(null)
      }
    ) : null
  ] });
}
function DashboardToolPage() {
  const params = Route$e.useParams();
  const parsedTool = toolSchema$1.safeParse(params.tool);
  if (!parsedTool.success) {
    throw notFound();
  }
  const toolKey = parsedTool.data;
  if (toolKey === "knowledge-vault") {
    return /* @__PURE__ */ jsx18(KnowledgeVaultPage, {});
  }
  if (toolKey === "revenue-tracker") {
    return /* @__PURE__ */ jsx18(RevenueTrackerPage, {});
  }
  if (toolKey === "collaboration-hub") {
    return /* @__PURE__ */ jsx18(CollaborationHub, {});
  }
  if (toolKey === "promotion-hub") {
    return /* @__PURE__ */ jsx18(PromotionHubPage, {});
  }
  if (toolKey === "merch-studio") {
    return /* @__PURE__ */ jsx18(MerchStudioPage, {});
  }
  const config2 = TOOL_CONFIGS[toolKey];
  const [entries, setEntries] = useState13([]);
  const [loading, setLoading] = useState13(true);
  const [error, setError] = useState13("");
  const [busyId, setBusyId] = useState13(null);
  const [title, setTitle] = useState13("");
  const [details, setDetails] = useState13("");
  const [status, setStatus] = useState13("planned");
  const [eventDate, setEventDate] = useState13("");
  const [amount, setAmount] = useState13("");
  const createPayload = useMemo4(() => ({
    title: title.trim(),
    details: details.trim(),
    status,
    eventDate: eventDate ? new Date(eventDate).toISOString() : null,
    amountCents: config2.showAmount && amount ? Math.max(0, Math.round(Number(amount) * 100)) : null
  }), [title, details, status, eventDate, amount, config2.showAmount]);
  const loadEntries2 = async () => {
    setError("");
    const response = await authedFetch(`/api/tools/${toolKey}`);
    const data = await response.json();
    if (!response.ok) {
      setError(data.error || "Failed to load tool entries.");
      return;
    }
    setEntries(data.entries || []);
  };
  useEffect12(() => {
    void (async () => {
      try {
        setLoading(true);
        await loadEntries2();
      } catch {
        setError("Failed to load tool entries.");
      } finally {
        setLoading(false);
      }
    })();
  }, [toolKey]);
  const createEntry = async () => {
    if (!createPayload.title) {
      setError("Title is required.");
      return;
    }
    try {
      setError("");
      setBusyId("new");
      const response = await authedFetch(`/api/tools/${toolKey}`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(createPayload)
      });
      const data = await response.json();
      if (!response.ok) {
        setError(data.error || "Could not create entry.");
        return;
      }
      setTitle("");
      setDetails("");
      setStatus("planned");
      setEventDate("");
      setAmount("");
      await loadEntries2();
    } catch {
      setError("Could not create entry.");
    } finally {
      setBusyId(null);
    }
  };
  const updateEntry = async (entry) => {
    try {
      setError("");
      setBusyId(entry.id);
      const response = await authedFetch(`/api/tools/${toolKey}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          id: entry.id,
          title: entry.title,
          details: entry.details,
          status: entry.status,
          eventDate: entry.event_date,
          amountCents: entry.amount_cents,
          metadata: entry.metadata
        })
      });
      const data = await response.json();
      if (!response.ok) {
        setError(data.error || "Could not update entry.");
        return;
      }
      await loadEntries2();
    } catch {
      setError("Could not update entry.");
    } finally {
      setBusyId(null);
    }
  };
  const deleteEntry = async (id) => {
    try {
      setError("");
      setBusyId(id);
      const response = await authedFetch(`/api/tools/${toolKey}`, {
        method: "DELETE",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          id
        })
      });
      const data = await response.json();
      if (!response.ok) {
        setError(data.error || "Could not delete entry.");
        return;
      }
      await loadEntries2();
    } catch {
      setError("Could not delete entry.");
    } finally {
      setBusyId(null);
    }
  };
  return /* @__PURE__ */ jsx18("div", { className: "min-h-screen px-4 py-10 text-zinc-100", children: /* @__PURE__ */ jsxs16("div", { className: "mx-auto max-w-6xl space-y-6", children: [
    /* @__PURE__ */ jsx18("header", { className: "rounded-2xl border border-zinc-200/15 bg-zinc-900/60 p-6", children: /* @__PURE__ */ jsxs16("div", { className: "flex flex-wrap items-center justify-between gap-4", children: [
      /* @__PURE__ */ jsxs16("div", { children: [
        /* @__PURE__ */ jsx18("p", { className: "text-xs font-semibold uppercase tracking-[0.2em] text-zinc-400", children: "Dashboard Tool" }),
        /* @__PURE__ */ jsx18("h1", { className: "mt-2 text-3xl font-black text-zinc-50", children: config2.title }),
        /* @__PURE__ */ jsx18("p", { className: "mt-2 max-w-3xl text-sm text-zinc-300", children: config2.description }),
        /* @__PURE__ */ jsx18("p", { className: "mt-2 text-xs text-zinc-400", children: config2.helper })
      ] }),
      /* @__PURE__ */ jsx18("div", { className: "flex gap-3", children: /* @__PURE__ */ jsxs16(Link12, { to: "/dashboard", className: "inline-flex items-center gap-2 rounded-lg border border-zinc-100/25 px-4 py-2 text-sm font-semibold text-zinc-100 transition hover:border-orange-200/70 hover:text-orange-100", children: [
        /* @__PURE__ */ jsx18(ArrowLeft5, { size: 16 }),
        " Dashboard"
      ] }) })
    ] }) }),
    /* @__PURE__ */ jsxs16("section", { className: "rounded-2xl border border-zinc-200/15 bg-zinc-900/60 p-6", children: [
      /* @__PURE__ */ jsx18("h2", { className: "text-xl font-semibold text-zinc-50", children: "Add Entry" }),
      /* @__PURE__ */ jsxs16("div", { className: "mt-4 grid gap-3 md:grid-cols-2", children: [
        /* @__PURE__ */ jsx18("input", { type: "text", value: title, onChange: (event) => setTitle(event.target.value), placeholder: "Entry title", className: "rounded-lg border border-zinc-200/20 bg-zinc-950/60 px-3 py-2 text-zinc-100 outline-none transition focus:border-orange-200/70" }),
        /* @__PURE__ */ jsx18("select", { value: status, onChange: (event) => setStatus(event.target.value), className: "rounded-lg border border-zinc-200/20 bg-zinc-950/60 px-3 py-2 text-zinc-100 outline-none transition focus:border-orange-200/70", children: statusOptions.map((option) => /* @__PURE__ */ jsx18("option", { value: option, children: option }, option)) }),
        config2.showDate ? /* @__PURE__ */ jsx18("input", { type: "datetime-local", value: eventDate, onChange: (event) => setEventDate(event.target.value), className: "rounded-lg border border-zinc-200/20 bg-zinc-950/60 px-3 py-2 text-zinc-100 outline-none transition focus:border-orange-200/70" }) : null,
        config2.showAmount ? /* @__PURE__ */ jsx18("input", { type: "number", min: "0", step: "0.01", value: amount, onChange: (event) => setAmount(event.target.value), placeholder: "Amount (USD)", className: "rounded-lg border border-zinc-200/20 bg-zinc-950/60 px-3 py-2 text-zinc-100 outline-none transition focus:border-orange-200/70" }) : null,
        /* @__PURE__ */ jsx18("textarea", { value: details, onChange: (event) => setDetails(event.target.value), placeholder: "Details", rows: 4, className: "md:col-span-2 rounded-lg border border-zinc-200/20 bg-zinc-950/60 px-3 py-2 text-zinc-100 outline-none transition focus:border-orange-200/70" })
      ] }),
      /* @__PURE__ */ jsxs16("button", { type: "button", onClick: () => {
        void createEntry();
      }, disabled: busyId === "new", className: "mt-4 inline-flex items-center gap-2 rounded-lg bg-orange-300 px-4 py-2 font-semibold text-zinc-950 transition hover:bg-orange-200 disabled:cursor-not-allowed disabled:opacity-70", children: [
        /* @__PURE__ */ jsx18(Plus, { size: 16 }),
        " ",
        busyId === "new" ? "Adding..." : "Add Entry"
      ] })
    ] }),
    error ? /* @__PURE__ */ jsx18("p", { className: "rounded-lg border border-rose-400/40 bg-rose-500/10 px-3 py-2 text-sm text-rose-200", children: error }) : null,
    /* @__PURE__ */ jsxs16("section", { className: "space-y-3", children: [
      loading ? /* @__PURE__ */ jsx18("p", { className: "text-zinc-300", children: "Loading entries..." }) : null,
      !loading && entries.length === 0 ? /* @__PURE__ */ jsx18("article", { className: "rounded-2xl border border-zinc-200/15 bg-zinc-900/60 p-5 text-zinc-300", children: "No entries yet for this tool." }) : null,
      entries.map((entry) => /* @__PURE__ */ jsxs16("article", { className: "rounded-2xl border border-zinc-200/15 bg-zinc-900/60 p-5", children: [
        /* @__PURE__ */ jsxs16("div", { className: "grid gap-3 md:grid-cols-2", children: [
          /* @__PURE__ */ jsx18("input", { type: "text", value: entry.title, onChange: (event) => {
            setEntries((current) => current.map((item) => item.id === entry.id ? {
              ...item,
              title: event.target.value
            } : item));
          }, className: "rounded-lg border border-zinc-200/20 bg-zinc-950/60 px-3 py-2 text-zinc-100 outline-none transition focus:border-orange-200/70" }),
          /* @__PURE__ */ jsx18("select", { value: entry.status, onChange: (event) => {
            setEntries((current) => current.map((item) => item.id === entry.id ? {
              ...item,
              status: event.target.value
            } : item));
          }, className: "rounded-lg border border-zinc-200/20 bg-zinc-950/60 px-3 py-2 text-zinc-100 outline-none transition focus:border-orange-200/70", children: statusOptions.map((option) => /* @__PURE__ */ jsx18("option", { value: option, children: option }, option)) }),
          config2.showDate ? /* @__PURE__ */ jsx18("input", { type: "datetime-local", value: entry.event_date ? new Date(entry.event_date).toISOString().slice(0, 16) : "", onChange: (event) => {
            setEntries((current) => current.map((item) => item.id === entry.id ? {
              ...item,
              event_date: event.target.value ? new Date(event.target.value).toISOString() : null
            } : item));
          }, className: "rounded-lg border border-zinc-200/20 bg-zinc-950/60 px-3 py-2 text-zinc-100 outline-none transition focus:border-orange-200/70" }) : null,
          config2.showAmount ? /* @__PURE__ */ jsx18("input", { type: "number", min: "0", step: "0.01", value: entry.amount_cents === null ? "" : (entry.amount_cents / 100).toString(), onChange: (event) => {
            setEntries((current) => current.map((item) => item.id === entry.id ? {
              ...item,
              amount_cents: event.target.value ? Math.max(0, Math.round(Number(event.target.value) * 100)) : null
            } : item));
          }, className: "rounded-lg border border-zinc-200/20 bg-zinc-950/60 px-3 py-2 text-zinc-100 outline-none transition focus:border-orange-200/70" }) : null,
          /* @__PURE__ */ jsx18("textarea", { rows: 3, value: entry.details, onChange: (event) => {
            setEntries((current) => current.map((item) => item.id === entry.id ? {
              ...item,
              details: event.target.value
            } : item));
          }, className: "md:col-span-2 rounded-lg border border-zinc-200/20 bg-zinc-950/60 px-3 py-2 text-zinc-100 outline-none transition focus:border-orange-200/70" })
        ] }),
        /* @__PURE__ */ jsxs16("div", { className: "mt-3 flex items-center justify-between gap-3", children: [
          /* @__PURE__ */ jsxs16("p", { className: "text-xs text-zinc-400", children: [
            "Updated ",
            new Date(entry.updated_at).toLocaleString()
          ] }),
          /* @__PURE__ */ jsxs16("div", { className: "flex gap-2", children: [
            /* @__PURE__ */ jsxs16("button", { type: "button", onClick: () => {
              void updateEntry(entry);
            }, disabled: busyId === entry.id, className: "inline-flex items-center gap-2 rounded-lg border border-zinc-100/25 px-3 py-2 text-sm font-semibold text-zinc-100 transition hover:border-orange-200/70 hover:text-orange-100 disabled:cursor-not-allowed disabled:opacity-70", children: [
              /* @__PURE__ */ jsx18(Save2, { size: 14 }),
              " Save"
            ] }),
            /* @__PURE__ */ jsxs16("button", { type: "button", onClick: () => {
              void deleteEntry(entry.id);
            }, disabled: busyId === entry.id, className: "inline-flex items-center gap-2 rounded-lg border border-rose-300/30 px-3 py-2 text-sm font-semibold text-rose-200 transition hover:border-rose-200 disabled:cursor-not-allowed disabled:opacity-70", children: [
              /* @__PURE__ */ jsx18(Trash22, { size: 14 }),
              " Delete"
            ] })
          ] })
        ] })
      ] }, entry.id))
    ] })
  ] }) });
}
function parseRevenueEntry(entry) {
  return {
    id: entry.id,
    title: entry.title,
    details: entry.details,
    amount_cents: entry.amount_cents,
    event_date: entry.event_date,
    status: entry.status,
    venue: entry.metadata?.venue || "other",
    created_at: entry.created_at,
    updated_at: entry.updated_at
  };
}
function formatCents(cents) {
  if (cents === null || cents === 0) return "$0";
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: 0,
    maximumFractionDigits: 2
  }).format(cents / 100);
}
function AnimatedNumber({
  value,
  prefix = ""
}) {
  const [display, setDisplay] = useState13(0);
  useEffect12(() => {
    if (value === 0) {
      setDisplay(0);
      return;
    }
    const start = Date.now();
    const duration = 900;
    const from = 0;
    const raf = (id) => id;
    let handle = raf(0);
    const step = () => {
      const elapsed = Date.now() - start;
      const progress = Math.min(elapsed / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      setDisplay(Math.round(from + (value - from) * eased));
      if (progress < 1) {
        handle = requestAnimationFrame(step);
      }
    };
    handle = requestAnimationFrame(step);
    return () => cancelAnimationFrame(handle);
  }, [value]);
  return /* @__PURE__ */ jsxs16("span", { children: [
    prefix,
    display.toLocaleString()
  ] });
}
function VenueBar({
  label,
  cents,
  maxCents,
  color
}) {
  const pct = maxCents > 0 ? cents / maxCents * 100 : 0;
  return /* @__PURE__ */ jsxs16("div", { className: "flex items-center gap-3", children: [
    /* @__PURE__ */ jsx18("span", { className: "w-32 shrink-0 truncate text-xs text-zinc-400", children: label }),
    /* @__PURE__ */ jsx18("div", { className: "relative h-3 flex-1 overflow-hidden rounded-full bg-zinc-800", children: /* @__PURE__ */ jsx18("div", { className: "absolute left-0 top-0 h-full rounded-full transition-all duration-700 ease-out", style: {
      width: `${pct}%`,
      backgroundColor: color
    } }) }),
    /* @__PURE__ */ jsx18("span", { className: "w-20 shrink-0 text-right text-xs font-semibold text-zinc-200", children: formatCents(cents) })
  ] });
}
function RevenueTrackerPage() {
  const [entries, setEntries] = useState13([]);
  const [loading, setLoading] = useState13(true);
  const [error, setError] = useState13("");
  const [busyId, setBusyId] = useState13(null);
  const [showAddForm, setShowAddForm] = useState13(false);
  const [filterVenue, setFilterVenue] = useState13("all");
  const [addTitle, setAddTitle] = useState13("");
  const [addDetails, setAddDetails] = useState13("");
  const [addAmount, setAddAmount] = useState13("");
  const [addVenue, setAddVenue] = useState13("other");
  const [addDate, setAddDate] = useState13("");
  const [addStatus, setAddStatus] = useState13("active");
  const loadEntries2 = async () => {
    const response = await authedFetch("/api/tools/revenue-tracker");
    if (!response.ok) {
      setError("Failed to load revenue entries.");
      return;
    }
    const data = await response.json();
    setEntries((data.entries || []).map(parseRevenueEntry));
  };
  useEffect12(() => {
    void (async () => {
      try {
        setLoading(true);
        await loadEntries2();
      } catch {
        setError("Failed to load revenue entries.");
      } finally {
        setLoading(false);
      }
    })();
  }, []);
  const handleAdd = async () => {
    if (!addTitle.trim()) {
      setError("Title is required.");
      return;
    }
    try {
      setError("");
      setBusyId("new");
      const response = await authedFetch("/api/tools/revenue-tracker", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          title: addTitle.trim(),
          details: addDetails.trim(),
          status: addStatus,
          eventDate: addDate ? new Date(addDate).toISOString() : null,
          amountCents: addAmount ? Math.max(0, Math.round(Number(addAmount) * 100)) : null,
          metadata: {
            venue: addVenue
          }
        })
      });
      if (!response.ok) {
        const data = await response.json();
        setError(data.error || "Could not add entry.");
        return;
      }
      setAddTitle("");
      setAddDetails("");
      setAddAmount("");
      setAddDate("");
      setAddVenue("other");
      setAddStatus("active");
      setShowAddForm(false);
      await loadEntries2();
    } catch {
      setError("Could not add entry.");
    } finally {
      setBusyId(null);
    }
  };
  const handleDelete = async (id) => {
    if (!confirm("Delete this revenue entry?")) return;
    try {
      setBusyId(id);
      const response = await authedFetch("/api/tools/revenue-tracker", {
        method: "DELETE",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          id
        })
      });
      if (!response.ok) {
        setError("Could not delete entry.");
        return;
      }
      await loadEntries2();
    } catch {
      setError("Could not delete entry.");
    } finally {
      setBusyId(null);
    }
  };
  const handleUpdate = async (entry, changes) => {
    try {
      setBusyId(entry.id);
      const updated = {
        ...entry,
        ...changes
      };
      const response = await authedFetch("/api/tools/revenue-tracker", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          id: updated.id,
          title: updated.title,
          details: updated.details,
          status: updated.status,
          eventDate: updated.event_date,
          amountCents: updated.amount_cents,
          metadata: {
            venue: updated.venue
          }
        })
      });
      if (!response.ok) {
        setError("Could not update entry.");
        return;
      }
      await loadEntries2();
    } catch {
      setError("Could not update entry.");
    } finally {
      setBusyId(null);
    }
  };
  const totals = useMemo4(() => {
    const now = /* @__PURE__ */ new Date();
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
    const yearStart = new Date(now.getFullYear(), 0, 1);
    let allTime = 0;
    let thisMonth = 0;
    let thisYear = 0;
    const byVenue = {};
    for (const e of entries) {
      const cents = e.amount_cents || 0;
      allTime += cents;
      const d = e.event_date ? new Date(e.event_date) : new Date(e.created_at);
      if (d >= monthStart) thisMonth += cents;
      if (d >= yearStart) thisYear += cents;
      byVenue[e.venue] = (byVenue[e.venue] || 0) + cents;
    }
    const maxVenueCents = Math.max(0, ...Object.values(byVenue).filter(Boolean));
    const sortedVenues = Object.entries(byVenue).sort((a, b) => b[1] - a[1]);
    return {
      allTime,
      thisMonth,
      thisYear,
      byVenue,
      maxVenueCents,
      sortedVenues
    };
  }, [entries]);
  const filtered = useMemo4(() => filterVenue === "all" ? entries : entries.filter((e) => e.venue === filterVenue), [entries, filterVenue]);
  const venuesUsed = useMemo4(() => Array.from(new Set(entries.map((e) => e.venue))), [entries]);
  return /* @__PURE__ */ jsx18("div", { className: "min-h-screen px-4 py-10 text-zinc-100", children: /* @__PURE__ */ jsxs16("div", { className: "mx-auto max-w-6xl space-y-6", children: [
    /* @__PURE__ */ jsx18("header", { className: "rounded-2xl border border-zinc-200/15 bg-zinc-900/60 p-6", children: /* @__PURE__ */ jsxs16("div", { className: "flex flex-wrap items-center justify-between gap-4", children: [
      /* @__PURE__ */ jsxs16("div", { children: [
        /* @__PURE__ */ jsx18("p", { className: "text-xs font-semibold uppercase tracking-[0.2em] text-zinc-400", children: "My Revenue Tracker" }),
        /* @__PURE__ */ jsx18("h1", { className: "mt-2 text-3xl font-black text-zinc-50", children: "Revenue Dashboard" }),
        /* @__PURE__ */ jsx18("p", { className: "mt-1 text-sm text-zinc-400", children: "Track income from every venue in the organization. Your data is private to you." })
      ] }),
      /* @__PURE__ */ jsxs16("div", { className: "flex gap-3", children: [
        /* @__PURE__ */ jsxs16(Link12, { to: "/dashboard", className: "inline-flex items-center gap-2 rounded-lg border border-zinc-100/25 px-4 py-2 text-sm font-semibold text-zinc-100 transition hover:border-orange-200/70 hover:text-orange-100", children: [
          /* @__PURE__ */ jsx18(ArrowLeft5, { size: 16 }),
          " Dashboard"
        ] }),
        /* @__PURE__ */ jsxs16("button", { type: "button", onClick: () => setShowAddForm((v) => !v), className: "inline-flex items-center gap-2 rounded-lg bg-orange-300 px-4 py-2 text-sm font-semibold text-zinc-950 transition hover:bg-orange-200", children: [
          /* @__PURE__ */ jsx18(Plus, { size: 16 }),
          " Log Revenue"
        ] })
      ] })
    ] }) }),
    /* @__PURE__ */ jsx18("div", { className: "grid gap-4 sm:grid-cols-3", children: [{
      label: "This Month",
      cents: totals.thisMonth,
      accent: "border-orange-300/40 bg-orange-300/5"
    }, {
      label: "This Year",
      cents: totals.thisYear,
      accent: "border-violet-300/40 bg-violet-300/5"
    }, {
      label: "All Time",
      cents: totals.allTime,
      accent: "border-emerald-300/40 bg-emerald-300/5"
    }].map(({
      label,
      cents,
      accent
    }) => /* @__PURE__ */ jsxs16("article", { className: `rounded-2xl border p-5 ${accent}`, children: [
      /* @__PURE__ */ jsxs16("div", { className: "flex items-center gap-2 text-zinc-400", children: [
        /* @__PURE__ */ jsx18(TrendingUp, { size: 14 }),
        /* @__PURE__ */ jsx18("span", { className: "text-xs font-semibold uppercase tracking-[0.15em]", children: label })
      ] }),
      /* @__PURE__ */ jsx18("p", { className: "mt-3 text-3xl font-black tabular-nums text-zinc-50", children: loading ? "\u2014" : /* @__PURE__ */ jsx18(AnimatedNumber, { value: Math.round(cents / 100), prefix: "$" }) }),
      /* @__PURE__ */ jsxs16("p", { className: "mt-1 text-xs text-zinc-500", children: [
        entries.filter((e) => {
          if (label === "All Time") return true;
          const now = /* @__PURE__ */ new Date();
          const d = e.event_date ? new Date(e.event_date) : new Date(e.created_at);
          if (label === "This Month") return d >= new Date(now.getFullYear(), now.getMonth(), 1);
          return d >= new Date(now.getFullYear(), 0, 1);
        }).length,
        " entries"
      ] })
    ] }, label)) }),
    totals.sortedVenues.length > 0 ? /* @__PURE__ */ jsxs16("section", { className: "rounded-2xl border border-zinc-200/15 bg-zinc-900/60 p-6", children: [
      /* @__PURE__ */ jsx18("h2", { className: "text-base font-bold text-zinc-50", children: "Revenue by Venue" }),
      /* @__PURE__ */ jsx18("div", { className: "mt-5 space-y-3", children: totals.sortedVenues.map(([venue, cents]) => /* @__PURE__ */ jsx18(VenueBar, { label: VENUE_LABELS[venue], cents, maxCents: totals.maxVenueCents, color: VENUE_COLORS[venue] }, venue)) })
    ] }) : null,
    showAddForm ? /* @__PURE__ */ jsxs16("section", { className: "rounded-2xl border border-orange-200/30 bg-zinc-900/60 p-6 animate-in fade-in slide-in-from-top-2 duration-200", children: [
      /* @__PURE__ */ jsxs16("div", { className: "flex items-center justify-between", children: [
        /* @__PURE__ */ jsx18("h2", { className: "text-lg font-semibold text-zinc-50", children: "Log Revenue Entry" }),
        /* @__PURE__ */ jsx18("button", { type: "button", onClick: () => setShowAddForm(false), className: "rounded-lg border border-zinc-200/20 p-1.5 text-zinc-400 transition hover:text-zinc-50", children: /* @__PURE__ */ jsx18(X, { size: 16 }) })
      ] }),
      /* @__PURE__ */ jsxs16("div", { className: "mt-4 grid gap-3 sm:grid-cols-2", children: [
        /* @__PURE__ */ jsx18("input", { type: "text", value: addTitle, onChange: (e) => setAddTitle(e.target.value), placeholder: "Revenue source name (e.g. Course Sale)", className: "sm:col-span-2 rounded-lg border border-zinc-200/20 bg-zinc-950/60 px-3 py-2 text-zinc-100 outline-none transition focus:border-orange-200/70" }),
        /* @__PURE__ */ jsxs16("div", { children: [
          /* @__PURE__ */ jsx18("label", { className: "mb-1 block text-xs font-medium text-zinc-400", children: "Venue" }),
          /* @__PURE__ */ jsx18("select", { value: addVenue, onChange: (e) => setAddVenue(e.target.value), className: "w-full rounded-lg border border-zinc-200/20 bg-zinc-950/60 px-3 py-2 text-zinc-100 outline-none transition focus:border-orange-200/70", children: Object.keys(VENUE_LABELS).map((v) => /* @__PURE__ */ jsx18("option", { value: v, children: VENUE_LABELS[v] }, v)) })
        ] }),
        /* @__PURE__ */ jsxs16("div", { children: [
          /* @__PURE__ */ jsx18("label", { className: "mb-1 block text-xs font-medium text-zinc-400", children: "Amount (USD)" }),
          /* @__PURE__ */ jsx18("input", { type: "number", min: "0", step: "0.01", value: addAmount, onChange: (e) => setAddAmount(e.target.value), placeholder: "0.00", className: "w-full rounded-lg border border-zinc-200/20 bg-zinc-950/60 px-3 py-2 text-zinc-100 outline-none transition focus:border-orange-200/70" })
        ] }),
        /* @__PURE__ */ jsxs16("div", { children: [
          /* @__PURE__ */ jsx18("label", { className: "mb-1 block text-xs font-medium text-zinc-400", children: "Date Received" }),
          /* @__PURE__ */ jsx18("input", { type: "date", value: addDate, onChange: (e) => setAddDate(e.target.value), className: "w-full rounded-lg border border-zinc-200/20 bg-zinc-950/60 px-3 py-2 text-zinc-100 outline-none transition focus:border-orange-200/70" })
        ] }),
        /* @__PURE__ */ jsxs16("div", { children: [
          /* @__PURE__ */ jsx18("label", { className: "mb-1 block text-xs font-medium text-zinc-400", children: "Status" }),
          /* @__PURE__ */ jsx18("select", { value: addStatus, onChange: (e) => setAddStatus(e.target.value), className: "w-full rounded-lg border border-zinc-200/20 bg-zinc-950/60 px-3 py-2 text-zinc-100 outline-none transition focus:border-orange-200/70", children: statusOptions.map((s) => /* @__PURE__ */ jsx18("option", { value: s, children: s }, s)) })
        ] }),
        /* @__PURE__ */ jsx18("textarea", { value: addDetails, onChange: (e) => setAddDetails(e.target.value), placeholder: "Notes (optional)", rows: 3, className: "sm:col-span-2 rounded-lg border border-zinc-200/20 bg-zinc-950/60 px-3 py-2 text-zinc-100 outline-none transition focus:border-orange-200/70" })
      ] }),
      error ? /* @__PURE__ */ jsx18("p", { className: "mt-3 rounded-lg border border-rose-400/40 bg-rose-500/10 px-3 py-2 text-sm text-rose-200", children: error }) : null,
      /* @__PURE__ */ jsxs16("button", { type: "button", onClick: () => {
        void handleAdd();
      }, disabled: busyId === "new", className: "mt-4 inline-flex items-center gap-2 rounded-lg bg-orange-300 px-4 py-2 font-semibold text-zinc-950 transition hover:bg-orange-200 disabled:opacity-70", children: [
        /* @__PURE__ */ jsx18(Plus, { size: 16 }),
        " ",
        busyId === "new" ? "Saving..." : "Log Revenue"
      ] })
    ] }) : null,
    error && !showAddForm ? /* @__PURE__ */ jsx18("p", { className: "rounded-lg border border-rose-400/40 bg-rose-500/10 px-3 py-2 text-sm text-rose-200", children: error }) : null,
    venuesUsed.length > 1 ? /* @__PURE__ */ jsxs16("div", { className: "flex flex-wrap gap-2", children: [
      /* @__PURE__ */ jsx18("button", { type: "button", onClick: () => setFilterVenue("all"), className: `rounded-lg border px-3 py-1.5 text-sm font-medium transition ${filterVenue === "all" ? "border-orange-200/70 bg-orange-200/10 text-orange-100" : "border-zinc-200/20 text-zinc-300 hover:border-zinc-200/40"}`, children: "All Venues" }),
      venuesUsed.map((v) => /* @__PURE__ */ jsx18("button", { type: "button", onClick: () => setFilterVenue(v), className: `rounded-lg border px-3 py-1.5 text-sm font-medium transition ${filterVenue === v ? "border-orange-200/70 bg-orange-200/10 text-orange-100" : "border-zinc-200/20 text-zinc-300 hover:border-zinc-200/40"}`, style: filterVenue === v ? {
        borderColor: VENUE_COLORS[v] + "80",
        color: VENUE_COLORS[v]
      } : {}, children: VENUE_LABELS[v] }, v))
    ] }) : null,
    loading ? /* @__PURE__ */ jsx18("p", { className: "text-zinc-300", children: "Loading your revenue data..." }) : null,
    !loading && filtered.length === 0 ? /* @__PURE__ */ jsxs16("article", { className: "rounded-2xl border border-zinc-200/15 bg-zinc-900/60 p-8 text-center", children: [
      /* @__PURE__ */ jsx18("div", { className: "mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-full border border-zinc-200/20 bg-zinc-800", children: /* @__PURE__ */ jsx18(TrendingUp, { size: 22, className: "text-zinc-400" }) }),
      /* @__PURE__ */ jsx18("p", { className: "font-semibold text-zinc-200", children: "No revenue logged yet" }),
      /* @__PURE__ */ jsx18("p", { className: "mt-1 text-sm text-zinc-500", children: 'Click "Log Revenue" to start tracking your income streams.' })
    ] }) : null,
    /* @__PURE__ */ jsx18("div", { className: "space-y-3", children: filtered.map((entry) => /* @__PURE__ */ jsx18(RevenueEntryCard, { entry, busy: busyId === entry.id, onUpdate: (changes) => {
      void handleUpdate(entry, changes);
    }, onDelete: () => {
      void handleDelete(entry.id);
    } }, entry.id)) })
  ] }) });
}
function RevenueEntryCard({
  entry,
  busy,
  onUpdate,
  onDelete
}) {
  const [editing, setEditing] = useState13(false);
  const [title, setTitle] = useState13(entry.title);
  const [details, setDetails] = useState13(entry.details);
  const [amount, setAmount] = useState13(entry.amount_cents !== null ? (entry.amount_cents / 100).toString() : "");
  const [venue, setVenue] = useState13(entry.venue);
  const [date, setDate] = useState13(entry.event_date ? new Date(entry.event_date).toISOString().split("T")[0] : "");
  const [status, setStatus] = useState13(entry.status);
  const color = VENUE_COLORS[entry.venue] || "#9ca3af";
  if (!editing) {
    return /* @__PURE__ */ jsxs16("article", { className: "group flex items-center gap-4 rounded-2xl border border-zinc-200/15 bg-zinc-900/60 p-4 transition hover:border-zinc-200/30", children: [
      /* @__PURE__ */ jsx18("div", { className: "h-10 w-1 shrink-0 rounded-full", style: {
        backgroundColor: color
      } }),
      /* @__PURE__ */ jsxs16("div", { className: "flex-1 min-w-0", children: [
        /* @__PURE__ */ jsxs16("div", { className: "flex flex-wrap items-center gap-2", children: [
          /* @__PURE__ */ jsx18("h3", { className: "font-semibold text-zinc-50 truncate", children: entry.title }),
          /* @__PURE__ */ jsx18("span", { className: "rounded-full border px-2 py-0.5 text-xs font-medium", style: {
            borderColor: color + "60",
            color
          }, children: VENUE_LABELS[entry.venue] }),
          /* @__PURE__ */ jsx18("span", { className: "rounded-full border border-zinc-200/20 px-2 py-0.5 text-xs text-zinc-400", children: entry.status })
        ] }),
        entry.details ? /* @__PURE__ */ jsx18("p", { className: "mt-0.5 text-sm text-zinc-400 truncate", children: entry.details }) : null,
        entry.event_date ? /* @__PURE__ */ jsx18("p", { className: "mt-0.5 text-xs text-zinc-500", children: new Date(entry.event_date).toLocaleDateString() }) : null
      ] }),
      /* @__PURE__ */ jsx18("div", { className: "shrink-0 text-right", children: /* @__PURE__ */ jsx18("p", { className: "text-xl font-black tabular-nums", style: {
        color
      }, children: formatCents(entry.amount_cents) }) }),
      /* @__PURE__ */ jsxs16("div", { className: "flex shrink-0 gap-2 opacity-0 transition group-hover:opacity-100", children: [
        /* @__PURE__ */ jsx18("button", { type: "button", onClick: () => setEditing(true), className: "rounded-lg border border-zinc-200/20 px-3 py-1.5 text-xs font-semibold text-zinc-100 transition hover:border-orange-200/60", children: "Edit" }),
        /* @__PURE__ */ jsx18("button", { type: "button", onClick: onDelete, disabled: busy, className: "rounded-lg border border-rose-300/30 p-1.5 text-rose-300 transition hover:border-rose-200 disabled:opacity-50", children: /* @__PURE__ */ jsx18(Trash22, { size: 14 }) })
      ] })
    ] });
  }
  return /* @__PURE__ */ jsxs16("article", { className: "rounded-2xl border border-orange-200/30 bg-zinc-900/60 p-5", children: [
    /* @__PURE__ */ jsxs16("div", { className: "grid gap-3 sm:grid-cols-2", children: [
      /* @__PURE__ */ jsx18("input", { type: "text", value: title, onChange: (e) => setTitle(e.target.value), className: "sm:col-span-2 rounded-lg border border-zinc-200/20 bg-zinc-950/60 px-3 py-2 text-zinc-100 outline-none transition focus:border-orange-200/70" }),
      /* @__PURE__ */ jsxs16("div", { children: [
        /* @__PURE__ */ jsx18("label", { className: "mb-1 block text-xs font-medium text-zinc-400", children: "Venue" }),
        /* @__PURE__ */ jsx18("select", { value: venue, onChange: (e) => setVenue(e.target.value), className: "w-full rounded-lg border border-zinc-200/20 bg-zinc-950/60 px-3 py-2 text-zinc-100 outline-none transition focus:border-orange-200/70", children: Object.keys(VENUE_LABELS).map((v) => /* @__PURE__ */ jsx18("option", { value: v, children: VENUE_LABELS[v] }, v)) })
      ] }),
      /* @__PURE__ */ jsxs16("div", { children: [
        /* @__PURE__ */ jsx18("label", { className: "mb-1 block text-xs font-medium text-zinc-400", children: "Amount (USD)" }),
        /* @__PURE__ */ jsx18("input", { type: "number", min: "0", step: "0.01", value: amount, onChange: (e) => setAmount(e.target.value), className: "w-full rounded-lg border border-zinc-200/20 bg-zinc-950/60 px-3 py-2 text-zinc-100 outline-none transition focus:border-orange-200/70" })
      ] }),
      /* @__PURE__ */ jsxs16("div", { children: [
        /* @__PURE__ */ jsx18("label", { className: "mb-1 block text-xs font-medium text-zinc-400", children: "Date" }),
        /* @__PURE__ */ jsx18("input", { type: "date", value: date, onChange: (e) => setDate(e.target.value), className: "w-full rounded-lg border border-zinc-200/20 bg-zinc-950/60 px-3 py-2 text-zinc-100 outline-none transition focus:border-orange-200/70" })
      ] }),
      /* @__PURE__ */ jsxs16("div", { children: [
        /* @__PURE__ */ jsx18("label", { className: "mb-1 block text-xs font-medium text-zinc-400", children: "Status" }),
        /* @__PURE__ */ jsx18("select", { value: status, onChange: (e) => setStatus(e.target.value), className: "w-full rounded-lg border border-zinc-200/20 bg-zinc-950/60 px-3 py-2 text-zinc-100 outline-none transition focus:border-orange-200/70", children: statusOptions.map((s) => /* @__PURE__ */ jsx18("option", { value: s, children: s }, s)) })
      ] }),
      /* @__PURE__ */ jsx18("textarea", { value: details, onChange: (e) => setDetails(e.target.value), rows: 3, placeholder: "Notes", className: "sm:col-span-2 rounded-lg border border-zinc-200/20 bg-zinc-950/60 px-3 py-2 text-zinc-100 outline-none transition focus:border-orange-200/70" })
    ] }),
    /* @__PURE__ */ jsxs16("div", { className: "mt-3 flex gap-2", children: [
      /* @__PURE__ */ jsxs16("button", { type: "button", onClick: () => {
        onUpdate({
          title,
          details,
          venue,
          status,
          event_date: date ? new Date(date).toISOString() : null,
          amount_cents: amount ? Math.max(0, Math.round(Number(amount) * 100)) : null
        });
        setEditing(false);
      }, disabled: busy, className: "inline-flex items-center gap-2 rounded-lg bg-orange-300 px-4 py-2 text-sm font-semibold text-zinc-950 transition hover:bg-orange-200 disabled:opacity-70", children: [
        /* @__PURE__ */ jsx18(Save2, { size: 14 }),
        " ",
        busy ? "Saving..." : "Save"
      ] }),
      /* @__PURE__ */ jsx18("button", { type: "button", onClick: () => setEditing(false), className: "rounded-lg border border-zinc-200/20 px-4 py-2 text-sm font-semibold text-zinc-200 transition hover:border-zinc-200/40", children: "Cancel" })
    ] })
  ] });
}
function categoryIcon(category) {
  const size = 14;
  switch (category) {
    case "tutorial":
      return /* @__PURE__ */ jsx18(GraduationCap, { size });
    case "document":
      return /* @__PURE__ */ jsx18(FileText, { size });
    case "template":
      return /* @__PURE__ */ jsx18(LayoutTemplate, { size });
    case "guide":
      return /* @__PURE__ */ jsx18(BookOpen, { size });
    case "script":
      return /* @__PURE__ */ jsx18(Tag, { size });
    default:
      return /* @__PURE__ */ jsx18(FileText, { size });
  }
}
function parseDocMeta(entry) {
  const meta = entry.metadata || {};
  return {
    id: entry.id,
    title: entry.title,
    details: entry.details,
    category: meta.category || "document",
    difficulty: meta.difficulty || "beginner",
    tags: Array.isArray(meta.tags) ? meta.tags : [],
    file_url: typeof meta.file_url === "string" ? meta.file_url : null,
    view_count: typeof meta.view_count === "number" ? meta.view_count : 0,
    created_by: entry.created_by,
    updated_at: entry.updated_at
  };
}
function KnowledgeVaultPage() {
  const [docs, setDocs] = useState13([]);
  const [loading, setLoading] = useState13(true);
  const [error, setError] = useState13("");
  const [search, setSearch] = useState13("");
  const [activeCategory, setActiveCategory] = useState13("all");
  const [selectedDoc, setSelectedDoc] = useState13(null);
  const [showAddForm, setShowAddForm] = useState13(false);
  const [addTitle, setAddTitle] = useState13("");
  const [addDetails, setAddDetails] = useState13("");
  const [addCategory, setAddCategory] = useState13("document");
  const [addDifficulty, setAddDifficulty] = useState13("beginner");
  const [addTags, setAddTags] = useState13("");
  const [addUrl, setAddUrl] = useState13("");
  const [addBusy, setAddBusy] = useState13(false);
  const loadDocs = async () => {
    const response = await authedFetch("/api/tools/knowledge-vault");
    if (!response.ok) {
      setError("Failed to load library.");
      return;
    }
    const data = await response.json();
    setDocs((data.entries || []).map(parseDocMeta));
  };
  useEffect12(() => {
    void (async () => {
      try {
        setLoading(true);
        await loadDocs();
      } catch {
        setError("Failed to load library.");
      } finally {
        setLoading(false);
      }
    })();
  }, []);
  const trackView = async (doc) => {
    setSelectedDoc(doc);
    void authedFetch("/api/knowledge-vault", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        documentId: doc.id
      })
    });
  };
  const handleAdd = async () => {
    if (!addTitle.trim()) {
      setError("Title is required.");
      return;
    }
    try {
      setError("");
      setAddBusy(true);
      const response = await authedFetch("/api/tools/knowledge-vault", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          title: addTitle.trim(),
          details: addDetails.trim(),
          status: "active",
          metadata: {
            category: addCategory,
            difficulty: addDifficulty,
            tags: addTags.split(",").map((t) => t.trim()).filter(Boolean),
            file_url: addUrl.trim() || null,
            view_count: 0
          }
        })
      });
      if (!response.ok) {
        const data = await response.json();
        setError(data.error || "Could not add document.");
        return;
      }
      setAddTitle("");
      setAddDetails("");
      setAddCategory("document");
      setAddDifficulty("beginner");
      setAddTags("");
      setAddUrl("");
      setShowAddForm(false);
      await loadDocs();
    } catch {
      setError("Could not add document.");
    } finally {
      setAddBusy(false);
    }
  };
  const handleDelete = async (id) => {
    if (!confirm("Delete this document from the library?")) return;
    try {
      const response = await authedFetch("/api/tools/knowledge-vault", {
        method: "DELETE",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          id
        })
      });
      if (!response.ok) {
        setError("Could not delete document.");
        return;
      }
      if (selectedDoc?.id === id) setSelectedDoc(null);
      await loadDocs();
    } catch {
      setError("Could not delete document.");
    }
  };
  const filtered = useMemo4(() => {
    const q = search.toLowerCase();
    return docs.filter((doc) => {
      const matchesCategory = activeCategory === "all" || doc.category === activeCategory;
      const matchesSearch = !q || doc.title.toLowerCase().includes(q) || doc.details.toLowerCase().includes(q) || doc.tags.some((tag) => tag.toLowerCase().includes(q));
      return matchesCategory && matchesSearch;
    });
  }, [docs, activeCategory, search]);
  return /* @__PURE__ */ jsxs16("div", { className: "min-h-screen px-4 py-10 text-zinc-100", children: [
    /* @__PURE__ */ jsxs16("div", { className: "mx-auto max-w-7xl space-y-6", children: [
      /* @__PURE__ */ jsx18("header", { className: "rounded-2xl border border-zinc-200/15 bg-zinc-900/60 p-6", children: /* @__PURE__ */ jsxs16("div", { className: "flex flex-wrap items-center justify-between gap-4", children: [
        /* @__PURE__ */ jsxs16("div", { children: [
          /* @__PURE__ */ jsx18("p", { className: "text-xs font-semibold uppercase tracking-[0.2em] text-zinc-400", children: "Dashboard Tool" }),
          /* @__PURE__ */ jsx18("h1", { className: "mt-2 text-3xl font-black text-zinc-50", children: "Knowledge Vault" }),
          /* @__PURE__ */ jsx18("p", { className: "mt-2 max-w-3xl text-sm text-zinc-300", children: "Your organization's library of tutorials, guides, templates, and reusable frameworks." })
        ] }),
        /* @__PURE__ */ jsxs16("div", { className: "flex gap-3", children: [
          /* @__PURE__ */ jsxs16(Link12, { to: "/dashboard", className: "inline-flex items-center gap-2 rounded-lg border border-zinc-100/25 px-4 py-2 text-sm font-semibold text-zinc-100 transition hover:border-orange-200/70 hover:text-orange-100", children: [
            /* @__PURE__ */ jsx18(ArrowLeft5, { size: 16 }),
            " Dashboard"
          ] }),
          /* @__PURE__ */ jsxs16("button", { type: "button", onClick: () => setShowAddForm((v) => !v), className: "inline-flex items-center gap-2 rounded-lg bg-orange-300 px-4 py-2 text-sm font-semibold text-zinc-950 transition hover:bg-orange-200", children: [
            /* @__PURE__ */ jsx18(Plus, { size: 16 }),
            " Add Document"
          ] })
        ] })
      ] }) }),
      showAddForm ? /* @__PURE__ */ jsxs16("section", { className: "rounded-2xl border border-orange-200/30 bg-zinc-900/60 p-6", children: [
        /* @__PURE__ */ jsxs16("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ jsx18("h2", { className: "text-lg font-semibold text-zinc-50", children: "Add to Library" }),
          /* @__PURE__ */ jsx18("button", { type: "button", onClick: () => setShowAddForm(false), className: "rounded-lg border border-zinc-200/20 p-1.5 text-zinc-400 transition hover:text-zinc-50", children: /* @__PURE__ */ jsx18(X, { size: 16 }) })
        ] }),
        /* @__PURE__ */ jsxs16("div", { className: "mt-4 grid gap-3 md:grid-cols-2", children: [
          /* @__PURE__ */ jsx18("input", { type: "text", value: addTitle, onChange: (e) => setAddTitle(e.target.value), placeholder: "Document title", className: "md:col-span-2 rounded-lg border border-zinc-200/20 bg-zinc-950/60 px-3 py-2 text-zinc-100 outline-none transition focus:border-orange-200/70" }),
          /* @__PURE__ */ jsx18("select", { value: addCategory, onChange: (e) => setAddCategory(e.target.value), className: "rounded-lg border border-zinc-200/20 bg-zinc-950/60 px-3 py-2 text-zinc-100 outline-none transition focus:border-orange-200/70", children: ["document", "tutorial", "guide", "template", "script"].map((c) => /* @__PURE__ */ jsx18("option", { value: c, children: CATEGORY_LABELS[c] }, c)) }),
          /* @__PURE__ */ jsxs16("select", { value: addDifficulty, onChange: (e) => setAddDifficulty(e.target.value), className: "rounded-lg border border-zinc-200/20 bg-zinc-950/60 px-3 py-2 text-zinc-100 outline-none transition focus:border-orange-200/70", children: [
            /* @__PURE__ */ jsx18("option", { value: "beginner", children: "Beginner" }),
            /* @__PURE__ */ jsx18("option", { value: "intermediate", children: "Intermediate" }),
            /* @__PURE__ */ jsx18("option", { value: "advanced", children: "Advanced" })
          ] }),
          /* @__PURE__ */ jsx18("input", { type: "text", value: addTags, onChange: (e) => setAddTags(e.target.value), placeholder: "Tags (comma-separated)", className: "rounded-lg border border-zinc-200/20 bg-zinc-950/60 px-3 py-2 text-zinc-100 outline-none transition focus:border-orange-200/70" }),
          /* @__PURE__ */ jsx18("input", { type: "url", value: addUrl, onChange: (e) => setAddUrl(e.target.value), placeholder: "External URL (optional)", className: "rounded-lg border border-zinc-200/20 bg-zinc-950/60 px-3 py-2 text-zinc-100 outline-none transition focus:border-orange-200/70" }),
          /* @__PURE__ */ jsx18("textarea", { value: addDetails, onChange: (e) => setAddDetails(e.target.value), placeholder: "Description or full content", rows: 5, className: "md:col-span-2 rounded-lg border border-zinc-200/20 bg-zinc-950/60 px-3 py-2 text-zinc-100 outline-none transition focus:border-orange-200/70" })
        ] }),
        error ? /* @__PURE__ */ jsx18("p", { className: "mt-3 rounded-lg border border-rose-400/40 bg-rose-500/10 px-3 py-2 text-sm text-rose-200", children: error }) : null,
        /* @__PURE__ */ jsxs16("button", { type: "button", onClick: () => {
          void handleAdd();
        }, disabled: addBusy, className: "mt-4 inline-flex items-center gap-2 rounded-lg bg-orange-300 px-4 py-2 font-semibold text-zinc-950 transition hover:bg-orange-200 disabled:opacity-70", children: [
          /* @__PURE__ */ jsx18(Plus, { size: 16 }),
          " ",
          addBusy ? "Adding..." : "Add to Library"
        ] })
      ] }) : null,
      /* @__PURE__ */ jsxs16("div", { className: "flex flex-wrap gap-3", children: [
        /* @__PURE__ */ jsxs16("div", { className: "relative flex-1 min-w-48", children: [
          /* @__PURE__ */ jsx18(Search2, { size: 15, className: "absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400" }),
          /* @__PURE__ */ jsx18("input", { type: "text", value: search, onChange: (e) => setSearch(e.target.value), placeholder: "Search library...", className: "w-full rounded-lg border border-zinc-200/20 bg-zinc-900/60 py-2 pl-9 pr-3 text-sm text-zinc-100 outline-none transition focus:border-orange-200/70" })
        ] }),
        /* @__PURE__ */ jsx18("div", { className: "flex flex-wrap gap-2", children: Object.keys(CATEGORY_LABELS).map((cat) => /* @__PURE__ */ jsx18("button", { type: "button", onClick: () => setActiveCategory(cat), className: `rounded-lg border px-3 py-1.5 text-sm font-medium transition ${activeCategory === cat ? "border-orange-200/70 bg-orange-200/10 text-orange-100" : "border-zinc-200/20 text-zinc-300 hover:border-zinc-200/40 hover:text-zinc-50"}`, children: CATEGORY_LABELS[cat] }, cat)) })
      ] }),
      loading ? /* @__PURE__ */ jsx18("p", { className: "text-zinc-300", children: "Loading library..." }) : null,
      !loading && filtered.length === 0 ? /* @__PURE__ */ jsx18("article", { className: "rounded-2xl border border-zinc-200/15 bg-zinc-900/60 p-8 text-center text-zinc-400", children: search || activeCategory !== "all" ? "No documents match your filter." : "No documents in the library yet. Add the first one." }) : null,
      /* @__PURE__ */ jsx18("div", { className: "grid gap-4 md:grid-cols-2 lg:grid-cols-3", children: filtered.map((doc) => /* @__PURE__ */ jsxs16("article", { className: "group flex flex-col rounded-2xl border border-zinc-200/15 bg-zinc-900/60 p-5 transition hover:border-orange-300/40", children: [
        /* @__PURE__ */ jsxs16("div", { className: "flex items-start justify-between gap-2", children: [
          /* @__PURE__ */ jsxs16("div", { className: "flex items-center gap-2 text-zinc-400", children: [
            categoryIcon(doc.category),
            /* @__PURE__ */ jsx18("span", { className: "text-xs font-semibold uppercase tracking-[0.15em]", children: CATEGORY_LABELS[doc.category] })
          ] }),
          /* @__PURE__ */ jsx18("span", { className: `rounded-full border px-2 py-0.5 text-xs font-medium ${DIFFICULTY_COLORS[doc.difficulty]}`, children: doc.difficulty })
        ] }),
        /* @__PURE__ */ jsx18("h3", { className: "mt-3 text-base font-bold text-zinc-50 group-hover:text-orange-100", children: doc.title }),
        doc.details ? /* @__PURE__ */ jsx18("p", { className: "mt-1.5 line-clamp-3 text-sm leading-relaxed text-zinc-400", children: doc.details }) : null,
        doc.tags.length > 0 ? /* @__PURE__ */ jsx18("div", { className: "mt-3 flex flex-wrap gap-1.5", children: doc.tags.map((tag) => /* @__PURE__ */ jsx18("span", { className: "rounded-full bg-zinc-800/80 px-2 py-0.5 text-xs text-zinc-400", children: tag }, tag)) }) : null,
        /* @__PURE__ */ jsxs16("div", { className: "mt-auto pt-4 flex items-center justify-between gap-2", children: [
          /* @__PURE__ */ jsxs16("span", { className: "flex items-center gap-1 text-xs text-zinc-500", children: [
            /* @__PURE__ */ jsx18(Eye, { size: 12 }),
            " ",
            doc.view_count,
            " views"
          ] }),
          /* @__PURE__ */ jsxs16("div", { className: "flex items-center gap-2", children: [
            doc.file_url ? /* @__PURE__ */ jsxs16("a", { href: doc.file_url, target: "_blank", rel: "noopener noreferrer", onClick: () => {
              void trackView(doc);
            }, className: "inline-flex items-center gap-1.5 rounded-lg border border-zinc-200/20 px-3 py-1.5 text-xs font-semibold text-zinc-100 transition hover:border-orange-200/60 hover:text-orange-100", children: [
              /* @__PURE__ */ jsx18(ExternalLink3, { size: 12 }),
              " Open"
            ] }) : null,
            /* @__PURE__ */ jsxs16("button", { type: "button", onClick: () => {
              void trackView(doc);
            }, className: "inline-flex items-center gap-1.5 rounded-lg bg-orange-300/90 px-3 py-1.5 text-xs font-semibold text-zinc-950 transition hover:bg-orange-200", children: [
              /* @__PURE__ */ jsx18(BookOpen, { size: 12 }),
              " Read"
            ] }),
            /* @__PURE__ */ jsx18("button", { type: "button", onClick: () => {
              void handleDelete(doc.id);
            }, className: "rounded-lg p-1.5 text-zinc-500 transition hover:text-rose-300", "aria-label": "Delete document", children: /* @__PURE__ */ jsx18(Trash22, { size: 14 }) })
          ] })
        ] })
      ] }, doc.id)) })
    ] }),
    selectedDoc ? /* @__PURE__ */ jsx18("div", { className: "fixed inset-0 z-50 flex items-start justify-end bg-zinc-950/70 backdrop-blur-sm", onClick: () => setSelectedDoc(null), children: /* @__PURE__ */ jsxs16("aside", { className: "relative flex h-full w-full max-w-xl flex-col overflow-y-auto bg-zinc-900 p-8 shadow-2xl", onClick: (e) => e.stopPropagation(), children: [
      /* @__PURE__ */ jsx18("button", { type: "button", onClick: () => setSelectedDoc(null), className: "absolute right-5 top-5 rounded-lg border border-zinc-200/20 p-1.5 text-zinc-400 transition hover:text-zinc-50", children: /* @__PURE__ */ jsx18(X, { size: 18 }) }),
      /* @__PURE__ */ jsxs16("div", { className: "flex items-center gap-2 text-zinc-400", children: [
        categoryIcon(selectedDoc.category),
        /* @__PURE__ */ jsx18("span", { className: "text-xs font-semibold uppercase tracking-[0.15em]", children: CATEGORY_LABELS[selectedDoc.category] }),
        /* @__PURE__ */ jsx18("span", { className: `ml-auto rounded-full border px-2 py-0.5 text-xs font-medium ${DIFFICULTY_COLORS[selectedDoc.difficulty]}`, children: selectedDoc.difficulty })
      ] }),
      /* @__PURE__ */ jsx18("h2", { className: "mt-4 text-2xl font-black text-zinc-50", children: selectedDoc.title }),
      selectedDoc.tags.length > 0 ? /* @__PURE__ */ jsx18("div", { className: "mt-3 flex flex-wrap gap-2", children: selectedDoc.tags.map((tag) => /* @__PURE__ */ jsx18("span", { className: "rounded-full bg-zinc-800/80 px-2.5 py-0.5 text-xs text-zinc-400", children: tag }, tag)) }) : null,
      /* @__PURE__ */ jsx18("div", { className: "mt-6 flex-1 whitespace-pre-wrap text-sm leading-relaxed text-zinc-300", children: selectedDoc.details || "No content provided for this document." }),
      selectedDoc.file_url ? /* @__PURE__ */ jsxs16("a", { href: selectedDoc.file_url, target: "_blank", rel: "noopener noreferrer", className: "mt-6 inline-flex items-center justify-center gap-2 rounded-lg bg-orange-300 px-4 py-2.5 font-semibold text-zinc-950 transition hover:bg-orange-200", children: [
        /* @__PURE__ */ jsx18(ExternalLink3, { size: 16 }),
        " Open Resource"
      ] }) : null,
      /* @__PURE__ */ jsxs16("p", { className: "mt-4 text-xs text-zinc-500", children: [
        "Added by ",
        selectedDoc.created_by || "admin",
        " \xB7 Updated ",
        new Date(selectedDoc.updated_at).toLocaleDateString()
      ] })
    ] }) }) : null
  ] });
}
function platformText(base, platform) {
  const limit = platform.charLimit;
  if (base.length <= limit) return base;
  return base.slice(0, limit - 1) + "\u2026";
}
function PromotionHubPage() {
  const [message, setMessage] = useState13("");
  const [selectedPlatforms, setSelectedPlatforms] = useState13(/* @__PURE__ */ new Set(["x"]));
  const [scheduleDate, setScheduleDate] = useState13("");
  const [copiedKey, setCopiedKey] = useState13(null);
  const [scheduledPosts, setScheduledPosts] = useState13([]);
  const [postsLoading, setPostsLoading] = useState13(true);
  const [saving, setSaving] = useState13(false);
  const [saveError, setSaveError] = useState13("");
  const [deletingId, setDeletingId] = useState13(null);
  const copiedTimerRef = useRef5(null);
  const loadPosts = async () => {
    try {
      const response = await authedFetch("/api/tools/promotion-hub");
      if (!response.ok) return;
      const data = await response.json();
      const parsed = (data.entries || []).map((e) => ({
        id: e.id,
        message: e.title,
        platforms: Array.isArray(e.metadata?.platforms) ? e.metadata.platforms : [],
        scheduled_at: e.event_date || e.created_at,
        status: e.status === "done" ? "sent" : e.status === "active" ? "queued" : e.status,
        created_at: e.created_at
      }));
      setScheduledPosts(parsed.sort((a, b) => new Date(a.scheduled_at).getTime() - new Date(b.scheduled_at).getTime()));
    } catch {
    } finally {
      setPostsLoading(false);
    }
  };
  useEffect12(() => {
    void loadPosts();
  }, []);
  const togglePlatform = (key) => {
    setSelectedPlatforms((prev) => {
      const next = new Set(prev);
      if (next.has(key)) {
        next.delete(key);
      } else {
        next.add(key);
      }
      return next;
    });
  };
  const copyForPlatform = (platform) => {
    const text = platformText(message, platform);
    void navigator.clipboard.writeText(text);
    if (copiedTimerRef.current) clearTimeout(copiedTimerRef.current);
    setCopiedKey(platform.key);
    copiedTimerRef.current = setTimeout(() => setCopiedKey(null), 2e3);
  };
  const openXIntent = () => {
    const platform = PLATFORMS.find((p) => p.key === "x");
    const text = platformText(message, platform);
    window.open(platform.intent(text), "_blank", "noopener,noreferrer");
  };
  const schedulePost = async () => {
    if (!message.trim()) {
      setSaveError("Please write a message first.");
      return;
    }
    if (selectedPlatforms.size === 0) {
      setSaveError("Select at least one platform.");
      return;
    }
    setSaving(true);
    setSaveError("");
    try {
      const response = await authedFetch("/api/tools/promotion-hub", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          title: message.trim().slice(0, 160),
          details: message.trim(),
          status: "planned",
          eventDate: scheduleDate ? new Date(scheduleDate).toISOString() : (/* @__PURE__ */ new Date()).toISOString(),
          metadata: {
            platforms: Array.from(selectedPlatforms)
          }
        })
      });
      if (!response.ok) {
        const err = await response.json();
        setSaveError(err.error || "Failed to schedule post.");
        return;
      }
      setMessage("");
      setScheduleDate("");
      await loadPosts();
    } catch {
      setSaveError("Unexpected error. Please try again.");
    } finally {
      setSaving(false);
    }
  };
  const deletePost = async (id) => {
    setDeletingId(id);
    try {
      await authedFetch("/api/tools/promotion-hub", {
        method: "DELETE",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          id
        })
      });
      setScheduledPosts((prev) => prev.filter((p) => p.id !== id));
    } catch {
    } finally {
      setDeletingId(null);
    }
  };
  return /* @__PURE__ */ jsx18("div", { className: "min-h-screen px-4 py-12 text-zinc-100", children: /* @__PURE__ */ jsxs16("div", { className: "mx-auto max-w-5xl", children: [
    /* @__PURE__ */ jsx18("div", { className: "mb-8 flex items-center justify-between gap-4", children: /* @__PURE__ */ jsxs16("div", { children: [
      /* @__PURE__ */ jsxs16(Link12, { to: "/dashboard", className: "mb-3 inline-flex items-center gap-1.5 text-xs text-zinc-400 transition hover:text-zinc-100", children: [
        /* @__PURE__ */ jsx18(ArrowLeft5, { size: 13 }),
        " Back to Dashboard"
      ] }),
      /* @__PURE__ */ jsxs16("div", { className: "flex items-center gap-3", children: [
        /* @__PURE__ */ jsx18("div", { className: "rounded-md border border-zinc-200/20 bg-zinc-900/60 p-2 text-orange-200", children: /* @__PURE__ */ jsx18(Megaphone2, { size: 18 }) }),
        /* @__PURE__ */ jsxs16("div", { children: [
          /* @__PURE__ */ jsx18("h1", { className: "text-2xl font-black text-zinc-50", children: "Promotion Hub" }),
          /* @__PURE__ */ jsx18("p", { className: "text-sm text-zinc-400", children: "Compose, preview, and schedule posts across your linked social platforms" })
        ] })
      ] })
    ] }) }),
    /* @__PURE__ */ jsxs16("div", { className: "grid gap-6 lg:grid-cols-[1fr_380px]", children: [
      /* @__PURE__ */ jsxs16("div", { className: "space-y-5", children: [
        /* @__PURE__ */ jsxs16("section", { className: "rounded-2xl border border-zinc-200/15 bg-zinc-900/60 p-5", children: [
          /* @__PURE__ */ jsx18("p", { className: "mb-3 text-xs font-semibold uppercase tracking-[0.2em] text-zinc-400", children: "Target Platforms" }),
          /* @__PURE__ */ jsx18("div", { className: "flex flex-wrap gap-2", children: PLATFORMS.map((platform) => {
            const selected = selectedPlatforms.has(platform.key);
            return /* @__PURE__ */ jsxs16("button", { type: "button", onClick: () => togglePlatform(platform.key), className: `flex items-center gap-2 rounded-lg border px-3 py-1.5 text-sm font-semibold transition ${selected ? "border-orange-200/60 bg-orange-200/10 text-orange-100" : "border-zinc-200/15 bg-zinc-800/40 text-zinc-400 hover:border-zinc-200/40 hover:text-zinc-100"}`, children: [
              /* @__PURE__ */ jsx18("span", { className: platform.color, children: platform.icon }),
              platform.label,
              selected ? /* @__PURE__ */ jsx18(Check3, { size: 12, className: "text-orange-200" }) : null
            ] }, platform.key);
          }) })
        ] }),
        /* @__PURE__ */ jsxs16("section", { className: "rounded-2xl border border-zinc-200/15 bg-zinc-900/60 p-5", children: [
          /* @__PURE__ */ jsx18("p", { className: "mb-3 text-xs font-semibold uppercase tracking-[0.2em] text-zinc-400", children: "Message" }),
          /* @__PURE__ */ jsx18("textarea", { value: message, onChange: (e) => setMessage(e.target.value), rows: 6, placeholder: "Write your promotional message here. It will be adapted to each platform's character limit automatically.", className: "w-full resize-none rounded-lg border border-zinc-200/20 bg-zinc-950/60 px-4 py-3 text-sm text-zinc-100 outline-none transition focus:border-orange-200/70 placeholder:text-zinc-600" }),
          /* @__PURE__ */ jsx18("div", { className: "mt-2 flex flex-wrap gap-3", children: PLATFORMS.filter((p) => selectedPlatforms.has(p.key)).map((p) => {
            platformText(message, p);
            const over = message.length > p.charLimit;
            return /* @__PURE__ */ jsxs16("span", { className: `text-xs ${over ? "text-rose-300" : "text-zinc-500"}`, children: [
              p.label,
              ": ",
              Math.min(message.length, p.charLimit),
              "/",
              p.charLimit,
              over ? " (will trim)" : ""
            ] }, p.key);
          }) })
        ] }),
        message.trim() && selectedPlatforms.size > 0 ? /* @__PURE__ */ jsxs16("section", { className: "rounded-2xl border border-zinc-200/15 bg-zinc-900/60 p-5", children: [
          /* @__PURE__ */ jsx18("p", { className: "mb-4 text-xs font-semibold uppercase tracking-[0.2em] text-zinc-400", children: "Platform Previews" }),
          /* @__PURE__ */ jsx18("div", { className: "space-y-4", children: PLATFORMS.filter((p) => selectedPlatforms.has(p.key)).map((platform) => {
            const text = platformText(message, platform);
            const isCopied = copiedKey === platform.key;
            return /* @__PURE__ */ jsxs16("div", { className: "rounded-xl border border-zinc-200/10 bg-zinc-950/60 p-4", children: [
              /* @__PURE__ */ jsxs16("div", { className: "mb-2 flex items-center justify-between gap-2", children: [
                /* @__PURE__ */ jsxs16("div", { className: "flex items-center gap-2", children: [
                  /* @__PURE__ */ jsx18("span", { className: platform.color, children: platform.icon }),
                  /* @__PURE__ */ jsx18("span", { className: "text-xs font-semibold text-zinc-300", children: platform.label }),
                  /* @__PURE__ */ jsxs16("span", { className: "text-xs text-zinc-600", children: [
                    text.length,
                    "/",
                    platform.charLimit
                  ] })
                ] }),
                /* @__PURE__ */ jsxs16("div", { className: "flex items-center gap-2", children: [
                  platform.intent ? /* @__PURE__ */ jsxs16("button", { type: "button", onClick: openXIntent, className: "flex items-center gap-1.5 rounded-lg border border-zinc-200/20 px-2.5 py-1 text-xs font-semibold text-zinc-200 transition hover:border-orange-200/50 hover:text-orange-100", children: [
                    /* @__PURE__ */ jsx18(Send, { size: 11 }),
                    " Post Now"
                  ] }) : null,
                  /* @__PURE__ */ jsxs16("button", { type: "button", onClick: () => copyForPlatform(platform), className: "flex items-center gap-1.5 rounded-lg border border-zinc-200/20 px-2.5 py-1 text-xs font-semibold text-zinc-200 transition hover:border-orange-200/50 hover:text-orange-100", children: [
                    isCopied ? /* @__PURE__ */ jsx18(Check3, { size: 11, className: "text-emerald-300" }) : /* @__PURE__ */ jsx18(Copy, { size: 11 }),
                    isCopied ? "Copied!" : "Copy"
                  ] })
                ] })
              ] }),
              /* @__PURE__ */ jsx18("p", { className: "whitespace-pre-wrap text-sm text-zinc-300", children: text }),
              !platform.intent ? /* @__PURE__ */ jsxs16("p", { className: "mt-2 text-xs text-zinc-600", children: [
                "Copy this text and paste it into ",
                platform.prefix,
                " to post."
              ] }) : null
            ] }, platform.key);
          }) })
        ] }) : null,
        /* @__PURE__ */ jsxs16("section", { className: "rounded-2xl border border-zinc-200/15 bg-zinc-900/60 p-5", children: [
          /* @__PURE__ */ jsx18("p", { className: "mb-3 text-xs font-semibold uppercase tracking-[0.2em] text-zinc-400", children: "Schedule" }),
          /* @__PURE__ */ jsxs16("div", { className: "flex flex-wrap items-end gap-3", children: [
            /* @__PURE__ */ jsxs16("div", { className: "flex-1 min-w-[200px]", children: [
              /* @__PURE__ */ jsx18("label", { className: "mb-1.5 block text-xs font-medium text-zinc-400", children: /* @__PURE__ */ jsxs16("span", { className: "flex items-center gap-1.5", children: [
                /* @__PURE__ */ jsx18(Calendar, { size: 12 }),
                " Post date & time (optional)"
              ] }) }),
              /* @__PURE__ */ jsx18("input", { type: "datetime-local", value: scheduleDate, onChange: (e) => setScheduleDate(e.target.value), className: "w-full rounded-lg border border-zinc-200/20 bg-zinc-950/60 px-3 py-2 text-sm text-zinc-100 outline-none transition focus:border-orange-200/70" })
            ] }),
            /* @__PURE__ */ jsxs16("button", { type: "button", onClick: () => void schedulePost(), disabled: saving || !message.trim(), className: "flex items-center gap-2 rounded-lg bg-orange-300 px-4 py-2 text-sm font-semibold text-zinc-950 transition hover:bg-orange-200 disabled:cursor-not-allowed disabled:opacity-60", children: [
              /* @__PURE__ */ jsx18(Clock, { size: 14 }),
              saving ? "Saving..." : scheduleDate ? "Schedule Post" : "Add to Queue"
            ] })
          ] }),
          saveError ? /* @__PURE__ */ jsx18("p", { className: "mt-2 text-xs text-rose-300", children: saveError }) : null,
          /* @__PURE__ */ jsx18("p", { className: "mt-2 text-xs text-zinc-600", children: 'Posts are saved to your queue. X supports one-click posting via the "Post Now" button. For other platforms, use the Copy button and paste into the app.' })
        ] })
      ] }),
      /* @__PURE__ */ jsx18("div", { children: /* @__PURE__ */ jsxs16("section", { className: "rounded-2xl border border-zinc-200/15 bg-zinc-900/60 p-5", children: [
        /* @__PURE__ */ jsx18("p", { className: "mb-4 text-xs font-semibold uppercase tracking-[0.2em] text-zinc-400", children: "Post Queue" }),
        postsLoading ? /* @__PURE__ */ jsx18("p", { className: "text-sm text-zinc-400", children: "Loading queue..." }) : scheduledPosts.length === 0 ? /* @__PURE__ */ jsxs16("div", { className: "rounded-xl border border-zinc-200/10 bg-zinc-950/40 p-4 text-center", children: [
          /* @__PURE__ */ jsx18("p", { className: "text-sm text-zinc-500", children: "No posts queued yet." }),
          /* @__PURE__ */ jsx18("p", { className: "mt-1 text-xs text-zinc-600", children: 'Compose a message and click "Add to Queue".' })
        ] }) : /* @__PURE__ */ jsx18("div", { className: "space-y-3", children: scheduledPosts.map((post) => {
          const postPlatforms = PLATFORMS.filter((p) => post.platforms.includes(p.key));
          const scheduled = new Date(post.scheduled_at);
          const isPast = scheduled < /* @__PURE__ */ new Date();
          return /* @__PURE__ */ jsxs16("div", { className: "rounded-xl border border-zinc-200/10 bg-zinc-950/40 p-3", children: [
            /* @__PURE__ */ jsxs16("div", { className: "mb-2 flex items-start justify-between gap-2", children: [
              /* @__PURE__ */ jsxs16("div", { className: "flex flex-wrap gap-1", children: [
                postPlatforms.map((p) => /* @__PURE__ */ jsx18("span", { className: `${p.color} flex items-center gap-1 text-xs`, children: p.icon }, p.key)),
                /* @__PURE__ */ jsx18("span", { className: `rounded-full px-2 py-0.5 text-xs font-semibold ${post.status === "sent" ? "bg-emerald-300/10 text-emerald-300" : post.status === "failed" ? "bg-rose-300/10 text-rose-300" : isPast ? "bg-amber-300/10 text-amber-300" : "bg-zinc-200/10 text-zinc-400"}`, children: post.status === "sent" ? "Sent" : post.status === "failed" ? "Failed" : isPast ? "Past due" : "Queued" })
              ] }),
              /* @__PURE__ */ jsx18("button", { type: "button", onClick: () => void deletePost(post.id), disabled: deletingId === post.id, className: "flex-shrink-0 rounded p-1 text-zinc-600 transition hover:text-rose-300 disabled:opacity-40", "aria-label": "Delete post", children: /* @__PURE__ */ jsx18(Trash22, { size: 13 }) })
            ] }),
            /* @__PURE__ */ jsx18("p", { className: "line-clamp-3 text-xs text-zinc-300", children: post.message }),
            /* @__PURE__ */ jsx18("p", { className: "mt-1.5 text-xs text-zinc-600", children: scheduleDate ? scheduled.toLocaleString() : scheduled.toLocaleDateString() })
          ] }, post.id);
        }) })
      ] }) })
    ] })
  ] }) });
}
var MODULES, TOOL_CONFIGS, statusOptions, VENUE_LABELS, VENUE_COLORS, CATEGORY_LABELS, DIFFICULTY_COLORS, PLATFORMS;
var init_dashboard_tools_tool_08iLNKOK = __esm({
  "dist/server/assets/dashboard.tools._tool-08iLNKOK.js"() {
    "use strict";
    init_router_BDBFyAOM();
    MODULES = [
      {
        id: "broadcast-infrastructure",
        title: "Broadcast Infrastructure",
        subtitle: "Content Production Layer",
        Icon: Radio2,
        accentClass: "text-sky-400",
        bgClass: "bg-sky-400/10",
        borderClass: "border-sky-400/30",
        progressHex: "#38bdf8",
        items: [
          { id: "software-installed", label: "Broadcasting software installed and configured" },
          { id: "stable-internet", label: "Stable internet connection verified" },
          { id: "bitrate-optimized", label: "Bitrate matches upload speed" },
          { id: "scenes-created", label: "Scenes and overlays created" },
          { id: "test-stream", label: "Test stream completed successfully" }
        ]
      },
      {
        id: "digital-hub",
        title: "Centralized Digital Hub",
        subtitle: "Brand Infrastructure",
        Icon: Globe,
        accentClass: "text-violet-400",
        bgClass: "bg-violet-400/10",
        borderClass: "border-violet-400/30",
        progressHex: "#a78bfa",
        items: [
          { id: "website-created", label: "Website created and published" },
          { id: "socials-linked", label: "All social platforms linked" },
          { id: "stream-embedded", label: "Livestream embedded or linked" },
          { id: "monetization-links", label: "Monetization links active" }
        ]
      },
      {
        id: "monetization-engine",
        title: "Monetization Engine",
        subtitle: "Revenue Layer",
        Icon: DollarSign2,
        accentClass: "text-emerald-400",
        bgClass: "bg-emerald-400/10",
        borderClass: "border-emerald-400/30",
        progressHex: "#34d399",
        items: [
          { id: "merch-store-created", label: "Merch store created" },
          { id: "products-published", label: "Products published (minimum viable catalog)" },
          { id: "payment-connected", label: "Payment processing connected" },
          { id: "store-linked", label: "Store linked to main hub" }
        ],
        insight: "Most small creators fail because they wait too long to monetize. Even a tiny audience can convert if the system exists early."
      },
      {
        id: "content-distribution",
        title: "Content Distribution System",
        subtitle: "Growth Layer",
        Icon: Share2,
        accentClass: "text-orange-400",
        bgClass: "bg-orange-400/10",
        borderClass: "border-orange-400/30",
        progressHex: "#fb923c",
        items: [
          { id: "content-schedule", label: "Weekly content schedule created" },
          { id: "posting-frequency", label: "Minimum posting frequency defined" },
          { id: "clips-extracted", label: "Clips extracted from streams" },
          { id: "cross-platform", label: "Content distributed across platforms" }
        ]
      },
      {
        id: "operational-system",
        title: "Operational System",
        subtitle: "Management Layer",
        Icon: Settings2,
        accentClass: "text-rose-400",
        bgClass: "bg-rose-400/10",
        borderClass: "border-rose-400/30",
        progressHex: "#fb7185",
        items: [
          { id: "tasks-organized", label: "Tasks organized into system" },
          { id: "roles-defined", label: "Roles defined (even if solo)" },
          { id: "weekly-review", label: "Weekly review process established" },
          { id: "metrics-tracked", label: "Performance metrics tracked" }
        ]
      }
    ];
    MODULES.reduce((sum, m) => sum + m.items.length, 0);
    TOOL_CONFIGS = {
      "bulletin-board": {
        key: "bulletin-board",
        title: "Bulletin Board",
        description: "Post important announcements, launches, and opportunities for your team.",
        helper: "Use short headlines and clear action items so everyone can execute quickly.",
        showDate: false,
        showAmount: false
      },
      "content-calendar": {
        key: "content-calendar",
        title: "Content Calendar",
        description: "Plan and track content outputs across platforms and campaigns.",
        helper: "Set a date for each item and move status from planned to done as you ship.",
        showDate: true,
        showAmount: false
      },
      "revenue-tracker": {
        key: "revenue-tracker",
        title: "Revenue Tracker",
        description: "Track revenue-related entries and outcomes over time.",
        helper: "Enter amount values in dollars to keep a clear running record of outcomes.",
        showDate: true,
        showAmount: true
      },
      "creator-task-board": {
        key: "creator-task-board",
        title: "Creator Task Board",
        description: "Manage weekly execution tasks and unblock momentum.",
        helper: "Keep tasks specific and outcome-focused; update status as work progresses.",
        showDate: true,
        showAmount: false
      },
      "collaboration-hub": {
        key: "collaboration-hub",
        title: "Collaboration Hub",
        description: "Track partner initiatives, co-marketing plans, and shared deliverables.",
        helper: "Document ownership and next actions for each collaboration.",
        showDate: true,
        showAmount: false
      },
      "knowledge-vault": {
        key: "knowledge-vault",
        title: "Knowledge Vault",
        description: "Store reusable frameworks, scripts, templates, and strategic notes.",
        helper: "Capture proven patterns so you can reuse what works.",
        showDate: false,
        showAmount: false
      },
      "promotion-hub": {
        key: "promotion-hub",
        title: "Promotion Hub",
        description: "Compose and schedule promotional posts across your linked social platforms.",
        helper: "Write once and distribute to Kick, Twitch, X, Instagram, and Threads.",
        showDate: true,
        showAmount: false
      },
      "merch-studio": {
        key: "merch-studio",
        title: "Merch Studio",
        description: "Submit mockups for review, track split percentages, and monitor your earnings.",
        helper: "Upload your designs, wait for admin approval, and track your payout history.",
        showDate: false,
        showAmount: false
      },
      "creator-growth-system": {
        key: "creator-growth-system",
        title: "Creator Growth System",
        description: "Track your creator operating system across 5 core modules.",
        helper: "Complete each module checklist to build a fully operational creator brand.",
        showDate: false,
        showAmount: false
      }
    };
    statusOptions = ["idea", "planned", "active", "blocked", "done"];
    VENUE_LABELS = {
      youtube: "YouTube / Video",
      tiktok: "TikTok / Reels",
      newsletter: "Newsletter / Email",
      course: "Digital Products",
      coaching: "Coaching / Consulting",
      merch: "Merch / Physical",
      affiliate: "Affiliate / Referral",
      membership: "Memberships",
      freelance: "Freelance / Services",
      events: "Events / Live",
      other: "Other"
    };
    VENUE_COLORS = {
      youtube: "#ef4444",
      tiktok: "#ec4899",
      newsletter: "#f97316",
      course: "#8b5cf6",
      coaching: "#06b6d4",
      merch: "#10b981",
      affiliate: "#f59e0b",
      membership: "#6366f1",
      freelance: "#84cc16",
      events: "#14b8a6",
      other: "#9ca3af"
    };
    CATEGORY_LABELS = {
      all: "All",
      tutorial: "Tutorial",
      document: "Document",
      template: "Template",
      guide: "Guide",
      script: "Script"
    };
    DIFFICULTY_COLORS = {
      beginner: "text-emerald-300 border-emerald-300/40",
      intermediate: "text-orange-200 border-orange-200/40",
      advanced: "text-rose-300 border-rose-300/40"
    };
    PLATFORMS = [{
      key: "x",
      label: "X / Twitter",
      charLimit: 280,
      color: "text-zinc-100",
      intent: (text) => `https://x.com/intent/tweet?text=${encodeURIComponent(text)}`,
      prefix: "x.com",
      icon: /* @__PURE__ */ jsx18("svg", { width: "14", height: "14", viewBox: "0 0 24 24", fill: "currentColor", "aria-hidden": "true", children: /* @__PURE__ */ jsx18("path", { d: "M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-4.714-6.231-5.401 6.231H2.746l7.73-8.835L1.254 2.25H8.08l4.259 5.632zm-1.161 17.52h1.833L7.084 4.126H5.117z" }) })
    }, {
      key: "threads",
      label: "Threads",
      charLimit: 500,
      color: "text-zinc-100",
      intent: null,
      prefix: "threads.net",
      icon: /* @__PURE__ */ jsx18("svg", { width: "14", height: "14", viewBox: "0 0 192 192", fill: "currentColor", "aria-hidden": "true", children: /* @__PURE__ */ jsx18("path", { d: "M141.537 88.988a66.667 66.667 0 0 0-2.518-1.143c-1.482-27.307-16.403-42.94-41.457-43.1h-.462c-14.967 0-27.406 6.396-35.116 18.05l13.678 9.384c5.751-8.734 14.793-10.608 21.459-10.608h.306c8.29.053 14.556 2.464 18.637 7.165 2.95 3.414 4.93 8.138 5.89 14.073-7.348-1.25-15.295-1.636-23.803-1.15-23.956 1.386-39.348 15.403-38.367 34.887.492 9.828 5.42 18.272 13.868 23.76 7.143 4.694 16.364 6.966 25.955 6.45 12.665-.689 22.616-5.529 29.575-14.391 5.29-6.904 8.637-15.831 10.093-27.116 6.05 3.658 10.529 8.493 13.019 14.41 4.276 10.164 4.521 26.867-8.793 40.18-11.813 11.81-26.04 16.923-47.454 17.078-23.786-.177-41.763-7.804-53.433-22.676C33.17 138.003 27.99 120.39 27.81 98c.18-22.39 5.36-40.003 15.385-52.346C54.865 30.83 72.842 23.203 96.628 23.026c23.947.178 42.227 7.84 54.348 22.775 5.958 7.376 10.441 16.365 13.378 26.713l15.919-4.229c-3.579-13.21-9.282-24.617-17.027-34.007C147.533 16.24 124.737 6.145 96.77 5.933h-.32C68.685 6.145 46.23 16.275 30.876 36.025 17.087 53.625 10.02 78.34 9.809 98c.211 19.66 7.278 44.373 21.067 61.974C46.23 179.724 68.684 189.854 96.45 190.067h.32c24.75-.195 42.183-6.693 56.506-21.012 18.798-18.794 18.207-42.306 12.023-56.8-4.386-10.43-12.8-18.931-23.762-23.267z" }) })
    }, {
      key: "instagram",
      label: "Instagram",
      charLimit: 2200,
      color: "text-pink-300",
      intent: null,
      prefix: "instagram.com",
      icon: /* @__PURE__ */ jsx18("svg", { width: "14", height: "14", viewBox: "0 0 24 24", fill: "currentColor", "aria-hidden": "true", children: /* @__PURE__ */ jsx18("path", { d: "M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 1 0 0 12.324 6.162 6.162 0 0 0 0-12.324zM12 16a4 4 0 1 1 0-8 4 4 0 0 1 0 8zm6.406-11.845a1.44 1.44 0 1 0 0 2.881 1.44 1.44 0 0 0 0-2.881z" }) })
    }, {
      key: "kick",
      label: "Kick",
      charLimit: 500,
      color: "text-[#53FC18]",
      intent: null,
      prefix: "kick.com",
      icon: /* @__PURE__ */ jsx18("svg", { width: "14", height: "14", viewBox: "0 0 24 24", fill: "#53FC18", "aria-hidden": "true", children: /* @__PURE__ */ jsx18("path", { d: "M2 2h5v8.5l5-8.5h6l-6 10 6 10h-6l-5-8.5V22H2z" }) })
    }, {
      key: "twitch",
      label: "Twitch",
      charLimit: 500,
      color: "text-purple-300",
      intent: null,
      prefix: "twitch.tv",
      icon: /* @__PURE__ */ jsx18("svg", { width: "14", height: "14", viewBox: "0 0 24 24", fill: "#9146FF", "aria-hidden": "true", children: /* @__PURE__ */ jsx18("path", { d: "M11.571 4.714h1.715v5.143H11.57zm4.715 0H18v5.143h-1.714zM6 0L1.714 4.286v15.428h5.143V24l4.286-4.286h3.428L22.286 12V0zm14.571 11.143l-3.428 3.428h-3.429l-3 3v-3H6.857V1.714h13.714z" }) })
    }];
  }
});

// dist/server/assets/router-BDBFyAOM.js
var router_BDBFyAOM_exports = {};
__export(router_BDBFyAOM_exports, {
  M: () => MerchStudioPage,
  O: () => ORG_ROLES,
  R: () => Route$x,
  a: () => authedFetch,
  b: () => getClientAuthRedirectUrl,
  c: () => isLocalRootSessionActive,
  d: () => getLocalRootUser,
  e: () => getIdentityLinkUrl,
  f: () => formatRoleLabel,
  g: () => getSupabaseBrowserClient,
  h: () => setStoredViewAsRole,
  i: () => isLocalhostClient,
  j: () => endLocalRootSession,
  k: () => canManageRole,
  l: () => ORG_ROLE_LABELS,
  m: () => Route$e,
  r: () => router,
  s: () => startLocalRootSession,
  t: () => toolSchema$1
});
import { useNavigate as useNavigate4, Link as Link13, createRootRoute, HeadContent, Scripts, createFileRoute, lazyRouteComponent, redirect, notFound as notFound2, createRouter } from "@tanstack/react-router";
import { jsxs as jsxs17, jsx as jsx19, Fragment as Fragment7 } from "react/jsx-runtime";
import { useState as useState14, useEffect as useEffect13, useMemo as useMemo5 } from "react";
import { createClient } from "@supabase/supabase-js";
import { UserCircle, LogOut as LogOut2, X as X2, Menu } from "lucide-react";
import Stripe from "stripe";
import { z } from "zod";
import { timingSafeEqual } from "node:crypto";
function isLocalhostHost(hostname) {
  return hostname === "localhost" || hostname === "127.0.0.1";
}
function isLocalhostClient() {
  if (typeof window === "undefined") return false;
  return isLocalhostHost(window.location.hostname);
}
function isLocalRootSessionActive() {
  if (!isLocalhostClient()) return false;
  return window.localStorage.getItem(LOCAL_ROOT_SESSION_KEY) === "true";
}
function startLocalRootSession() {
  if (!isLocalhostClient()) return;
  window.localStorage.setItem(LOCAL_ROOT_SESSION_KEY, "true");
}
function endLocalRootSession() {
  if (typeof window === "undefined") return;
  window.localStorage.removeItem(LOCAL_ROOT_SESSION_KEY);
}
function getLocalRootUser() {
  return {
    email: LOCAL_ROOT_EMAIL,
    user_metadata: {
      username: "root",
      full_name: "root"
    }
  };
}
function isOrgRole(value) {
  return ORG_ROLES.includes(value);
}
function canManageRole(actorRole, targetRole) {
  if (actorRole === "superadmin") {
    return true;
  }
  if (actorRole === "banned") {
    return false;
  }
  return ORG_ROLE_RANK[actorRole] < ORG_ROLE_RANK[targetRole];
}
function formatRoleLabel(role) {
  return ORG_ROLE_LABELS[role];
}
function getStoredViewAsRole() {
  if (typeof window === "undefined") return null;
  const value = window.localStorage.getItem(VIEW_AS_ROLE_STORAGE_KEY);
  if (!value || !isOrgRole(value)) {
    return null;
  }
  return value;
}
function setStoredViewAsRole(role) {
  if (typeof window === "undefined") return;
  if (!role) {
    window.localStorage.removeItem(VIEW_AS_ROLE_STORAGE_KEY);
    return;
  }
  window.localStorage.setItem(VIEW_AS_ROLE_STORAGE_KEY, role);
}
function getSupabaseBrowserClient() {
  if (supabaseBrowserClient) return supabaseBrowserClient;
  const supabaseUrl2 = "https://pqngaffhjqadrsntsvlp.supabase.co";
  const supabasePublishableKey = "sb_publishable_PYklH7WqzrRHtvuTFIRc2Q_Cwi8jGi8";
  supabaseBrowserClient = createClient(supabaseUrl2, supabasePublishableKey);
  return supabaseBrowserClient;
}
async function getSupabaseAccessToken() {
  const supabase = getSupabaseBrowserClient();
  const { data } = await supabase.auth.getSession();
  return data.session?.access_token || null;
}
async function authedFetch(input, init) {
  const token = await getSupabaseAccessToken();
  const headers = new Headers(init?.headers);
  const viewAsRole = getStoredViewAsRole();
  if (token) {
    headers.set("Authorization", `Bearer ${token}`);
  }
  if (viewAsRole) {
    headers.set("x-view-as-role", viewAsRole);
  }
  if (isLocalRootSessionActive()) {
    headers.set("x-local-root-session", "true");
  }
  return fetch(input, {
    ...init,
    headers
  });
}
async function getIdentityLinkUrl(provider, redirectTo) {
  const token = await getSupabaseAccessToken();
  if (!token) {
    throw new Error("No active session. Please log out and log back in, then try again.");
  }
  const supabaseUrl2 = "https://pqngaffhjqadrsntsvlp.supabase.co";
  const anonKey = "sb_publishable_PYklH7WqzrRHtvuTFIRc2Q_Cwi8jGi8";
  const params = new URLSearchParams({
    provider,
    redirect_to: redirectTo,
    skip_http_redirect: "true"
  });
  const response = await fetch(`${supabaseUrl2}/auth/v1/user/identities/authorize?${params.toString()}`, {
    method: "GET",
    headers: {
      Authorization: `Bearer ${token}`,
      apikey: anonKey
    }
  });
  const data = await response.json();
  if (!response.ok || !data.url) {
    throw new Error(data.error_description || data.msg || `Could not start ${provider} account linking.`);
  }
  return data.url;
}
function SiteHeader() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState14(false);
  const [user, setUser] = useState14(null);
  const [authLoading, setAuthLoading] = useState14(true);
  const navigate = useNavigate4();
  useEffect13(() => {
    const supabase = getSupabaseBrowserClient();
    const checkAuth = async () => {
      if (isLocalRootSessionActive()) {
        setUser(getLocalRootUser());
        setAuthLoading(false);
        return;
      }
      try {
        const { data } = await supabase.auth.getSession();
        setUser(data.session?.user || null);
      } catch {
        setUser(null);
      } finally {
        setAuthLoading(false);
      }
    };
    void checkAuth();
    const {
      data: { subscription }
    } = supabase.auth.onAuthStateChange((_event, session) => {
      if (isLocalRootSessionActive()) {
        setUser(getLocalRootUser());
        setAuthLoading(false);
        return;
      }
      setUser(session?.user || null);
      setAuthLoading(false);
    });
    const handleResume = () => {
      void checkAuth();
    };
    if (typeof window !== "undefined") {
      window.addEventListener("focus", handleResume);
      document.addEventListener("visibilitychange", handleResume);
    }
    return () => {
      subscription.unsubscribe();
      if (typeof window !== "undefined") {
        window.removeEventListener("focus", handleResume);
        document.removeEventListener("visibilitychange", handleResume);
      }
    };
  }, []);
  const handleLogout = async () => {
    try {
      if (isLocalRootSessionActive()) {
        endLocalRootSession();
        setUser(null);
        setMobileMenuOpen(false);
        await navigate({ to: "/" });
        return;
      }
      const supabase = getSupabaseBrowserClient();
      await supabase.auth.signOut();
      setUser(null);
      setMobileMenuOpen(false);
      await navigate({ to: "/" });
    } catch (error) {
      console.error("Logout failed:", error);
    }
  };
  return /* @__PURE__ */ jsxs17("header", { className: "sticky top-3 z-20 rounded-2xl border border-zinc-200/15 bg-zinc-900/90 p-3 backdrop-blur", children: [
    /* @__PURE__ */ jsxs17("div", { className: "flex items-center justify-between gap-3", children: [
      /* @__PURE__ */ jsx19(Link13, { to: "/", className: "text-sm font-black tracking-[0.16em] text-orange-200 sm:text-base", children: "W.A.G.E. SOCIETY" }),
      /* @__PURE__ */ jsx19("nav", { className: "hidden items-center gap-2 md:flex", children: navLinks.map((item) => /* @__PURE__ */ jsx19(
        Link13,
        {
          to: item.to,
          className: "rounded-lg px-3 py-2 text-sm font-medium text-zinc-300 transition hover:bg-zinc-800 hover:text-zinc-100",
          children: item.label
        },
        item.to
      )) }),
      /* @__PURE__ */ jsx19("div", { className: "hidden items-center gap-2 md:flex", children: authLoading ? /* @__PURE__ */ jsx19("div", { className: "h-8 w-32 animate-pulse rounded-lg bg-zinc-800" }) : user ? /* @__PURE__ */ jsxs17(Fragment7, { children: [
        /* @__PURE__ */ jsxs17(
          Link13,
          {
            to: "/dashboard",
            className: "inline-flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-semibold text-zinc-100 transition hover:bg-zinc-800",
            children: [
              /* @__PURE__ */ jsx19(UserCircle, { size: 15 }),
              " Profile"
            ]
          }
        ),
        /* @__PURE__ */ jsxs17(
          "button",
          {
            type: "button",
            onClick: handleLogout,
            className: "inline-flex items-center gap-2 rounded-lg bg-orange-300 px-3 py-2 text-sm font-semibold text-zinc-950 transition hover:bg-orange-200",
            children: [
              /* @__PURE__ */ jsx19(LogOut2, { size: 15 }),
              " Logout"
            ]
          }
        )
      ] }) : /* @__PURE__ */ jsxs17(Fragment7, { children: [
        /* @__PURE__ */ jsx19(
          Link13,
          {
            to: "/login",
            className: "rounded-lg border border-zinc-100/20 px-3 py-2 text-sm font-semibold text-zinc-100 transition hover:border-orange-200/70",
            children: "Login"
          }
        ),
        /* @__PURE__ */ jsx19(
          Link13,
          {
            to: "/signup",
            className: "rounded-lg bg-orange-300 px-3 py-2 text-sm font-semibold text-zinc-950 transition hover:bg-orange-200",
            children: "Sign Up"
          }
        )
      ] }) }),
      /* @__PURE__ */ jsx19(
        "button",
        {
          type: "button",
          onClick: () => setMobileMenuOpen((value) => !value),
          className: "inline-flex items-center justify-center rounded-lg border border-zinc-100/20 p-2 text-zinc-100 md:hidden",
          "aria-label": "Toggle menu",
          "aria-expanded": mobileMenuOpen,
          children: mobileMenuOpen ? /* @__PURE__ */ jsx19(X2, { size: 18 }) : /* @__PURE__ */ jsx19(Menu, { size: 18 })
        }
      )
    ] }),
    mobileMenuOpen ? /* @__PURE__ */ jsxs17("div", { className: "mt-3 grid gap-2 border-t border-zinc-200/15 pt-3 md:hidden", children: [
      navLinks.map((item) => /* @__PURE__ */ jsx19(
        Link13,
        {
          to: item.to,
          onClick: () => setMobileMenuOpen(false),
          className: "rounded-lg bg-zinc-800/80 px-3 py-2 text-sm font-medium text-zinc-100",
          children: item.label
        },
        item.to
      )),
      /* @__PURE__ */ jsx19("div", { className: "mt-1 grid grid-cols-2 gap-2", children: authLoading ? /* @__PURE__ */ jsx19("div", { className: "col-span-2 h-9 animate-pulse rounded-lg bg-zinc-800" }) : user ? /* @__PURE__ */ jsxs17(Fragment7, { children: [
        /* @__PURE__ */ jsx19(
          Link13,
          {
            to: "/dashboard",
            onClick: () => setMobileMenuOpen(false),
            className: "rounded-lg bg-zinc-800/80 px-3 py-2 text-center text-sm font-semibold text-zinc-100",
            children: "Profile"
          }
        ),
        /* @__PURE__ */ jsx19(
          "button",
          {
            type: "button",
            onClick: handleLogout,
            className: "rounded-lg bg-orange-300 px-3 py-2 text-center text-sm font-semibold text-zinc-950",
            children: "Logout"
          }
        )
      ] }) : /* @__PURE__ */ jsxs17(Fragment7, { children: [
        /* @__PURE__ */ jsx19(
          Link13,
          {
            to: "/login",
            onClick: () => setMobileMenuOpen(false),
            className: "rounded-lg border border-zinc-100/20 px-3 py-2 text-center text-sm font-semibold text-zinc-100",
            children: "Login"
          }
        ),
        /* @__PURE__ */ jsx19(
          Link13,
          {
            to: "/signup",
            onClick: () => setMobileMenuOpen(false),
            className: "rounded-lg bg-orange-300 px-3 py-2 text-center text-sm font-semibold text-zinc-950",
            children: "Sign Up"
          }
        )
      ] }) })
    ] }) : null
  ] });
}
function RootDocument({ children }) {
  const [pageReady, setPageReady] = useState14(false);
  const [viewingAs, setViewingAs] = useState14(null);
  const navigate = useNavigate4();
  useEffect13(() => {
    if (typeof window === "undefined") return;
    const cap = window.Capacitor;
    if (!cap?.isNativePlatform?.()) return;
    let cleanupFn = null;
    void (async () => {
      try {
        const { App } = await import("@capacitor/app");
        const { Browser } = await import("@capacitor/browser");
        const listener = await App.addListener("appUrlOpen", async (event) => {
          const url = event.url;
          if (!url.startsWith("com.wagesociety.android://login-callback")) return;
          await Browser.close().catch(() => {
          });
          const hash = url.includes("#") ? url.split("#")[1] : "";
          const params = new URLSearchParams(hash);
          const accessToken = params.get("access_token");
          const refreshToken = params.get("refresh_token");
          if (accessToken && refreshToken) {
            const supabase = getSupabaseBrowserClient();
            const { error } = await supabase.auth.setSession({ access_token: accessToken, refresh_token: refreshToken });
            if (!error) {
              const { data } = await supabase.auth.getUser();
              const meta = data?.user?.user_metadata || {};
              const dest = meta.onboarding_completed === true ? "/dashboard" : "/onboarding";
              void navigate({ to: dest });
            }
          }
        });
        cleanupFn = () => {
          listener.remove().catch(() => {
          });
        };
      } catch {
      }
    })();
    return () => {
      cleanupFn?.();
    };
  }, [navigate]);
  useEffect13(() => {
    if (typeof window === "undefined") return;
    if ("serviceWorker" in navigator) {
      navigator.serviceWorker.register("/sw.js").catch(() => {
      });
    }
  }, []);
  useEffect13(() => {
    if (typeof window === "undefined") return;
    const markReady = () => setPageReady(true);
    if (document.readyState === "complete") {
      markReady();
      return;
    }
    window.addEventListener("load", markReady, { once: true });
    return () => {
      window.removeEventListener("load", markReady);
    };
  }, []);
  useEffect13(() => {
    if (typeof window === "undefined") return;
    const syncViewAs = () => {
      setViewingAs(getStoredViewAsRole());
    };
    syncViewAs();
    window.addEventListener("storage", syncViewAs);
    return () => {
      window.removeEventListener("storage", syncViewAs);
    };
  }, []);
  useEffect13(() => {
    if (typeof window === "undefined") return;
    const host = window.location.hostname;
    const pathname = window.location.pathname;
    const isLocalhost = host === "localhost" || host === "127.0.0.1";
    if (!isLocalhost || pathname !== "/") return;
    if (isLocalRootSessionActive()) {
      window.location.replace("/dashboard");
      return;
    }
    void (async () => {
      try {
        const supabase = getSupabaseBrowserClient();
        const { data } = await supabase.auth.getSession();
        if (data.session?.user) {
          window.location.replace("/dashboard");
        }
      } catch {
      }
    })();
  }, []);
  return /* @__PURE__ */ jsxs17("html", { lang: "en", children: [
    /* @__PURE__ */ jsxs17("head", { children: [
      /* @__PURE__ */ jsx19(HeadContent, {}),
      /* @__PURE__ */ jsx19(
        "script",
        {
          type: "application/ld+json",
          dangerouslySetInnerHTML: {
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "Organization",
              name: "W.A.G.E. Society",
              url: "https://wagesociety.com",
              logo: "https://wagesociety.com/favicon.svg",
              description: "A modern organization for content creators, online marketers, and entrepreneurs. Join W.A.G.E. Society for strategy, systems, and community accountability.",
              sameAs: [],
              contactPoint: {
                "@type": "ContactPoint",
                contactType: "customer support",
                email: "appeals@wagesociety.com"
              }
            })
          }
        }
      )
    ] }),
    /* @__PURE__ */ jsxs17("body", { children: [
      /* @__PURE__ */ jsx19("div", { className: "min-h-screen bg-zinc-950 text-zinc-100", children: /* @__PURE__ */ jsxs17("div", { className: "mx-auto flex w-full max-w-6xl flex-col px-4 pb-12 pt-5 sm:px-6 lg:px-8", children: [
        /* @__PURE__ */ jsx19(SiteHeader, {}),
        children
      ] }) }),
      viewingAs ? /* @__PURE__ */ jsxs17("div", { className: "fixed right-4 top-4 z-[10000] flex items-center gap-3 rounded-lg border border-rose-300/60 bg-rose-600/90 px-4 py-2 text-xs font-semibold uppercase tracking-[0.12em] text-rose-50 shadow-lg shadow-rose-900/40", children: [
        /* @__PURE__ */ jsxs17("span", { children: [
          "VIEWING AS (",
          formatRoleLabel(viewingAs),
          ")"
        ] }),
        /* @__PURE__ */ jsx19(
          "button",
          {
            type: "button",
            onClick: () => {
              setStoredViewAsRole(null);
              setViewingAs(null);
              if (typeof window !== "undefined") {
                window.location.reload();
              }
            },
            className: "rounded border border-rose-100/50 px-2 py-0.5 text-[10px] font-bold tracking-[0.12em] text-rose-50 transition hover:border-white",
            children: "Reset"
          }
        )
      ] }) : null,
      !pageReady ? /* @__PURE__ */ jsx19("div", { className: "fixed inset-0 z-[9999] flex items-center justify-center bg-zinc-950/95 backdrop-blur-sm", children: /* @__PURE__ */ jsxs17("div", { className: "flex flex-col items-center gap-4 text-center", children: [
        /* @__PURE__ */ jsx19("div", { className: "h-14 w-14 animate-spin rounded-full border-4 border-zinc-600 border-t-orange-300" }),
        /* @__PURE__ */ jsxs17("div", { children: [
          /* @__PURE__ */ jsx19("p", { className: "text-xs font-semibold uppercase tracking-[0.2em] text-zinc-400", children: "W.A.G.E. Society" }),
          /* @__PURE__ */ jsx19("p", { className: "mt-2 text-lg font-semibold text-zinc-100", children: "Loading your workspace..." })
        ] })
      ] }) }) : null,
      /* @__PURE__ */ jsx19(Scripts, {})
    ] })
  ] });
}
function needsOnboarding(metadata) {
  return metadata?.onboarding_completed !== true;
}
async function requireAuthenticatedRoute(redirectTo = "/login", options = {}) {
  if (typeof window === "undefined") return;
  if (isLocalRootSessionActive()) {
    return;
  }
  const supabase = getSupabaseBrowserClient();
  const { data } = await supabase.auth.getSession();
  if (!data.session) {
    throw redirect({
      to: redirectTo
    });
  }
  const user = data.session.user;
  if (!options.skipOnboardingCheck && needsOnboarding(user.user_metadata)) {
    throw redirect({ to: "/onboarding" });
  }
}
function centsToUsd(value) {
  return `$${(value / 100).toFixed(2)}`;
}
function parseLines(value) {
  return value.split("\n").map((line) => line.trim()).filter(Boolean);
}
function looksLikeImage(url) {
  return /\.(jpg|jpeg|png|gif|webp)(\?|$)/i.test(url);
}
function looksLikeVideo(url) {
  return /\.(mp4|webm|mov|m4v)(\?|$)/i.test(url);
}
function MerchStudioPage() {
  const [submissions, setSubmissions] = useState14([]);
  const [earnings, setEarnings] = useState14([]);
  const [summary, setSummary] = useState14({
    memberDueCents: 0,
    memberPaidCents: 0,
    memberPendingCents: 0
  });
  const [canReview, setCanReview] = useState14(false);
  const [loading, setLoading] = useState14(true);
  const [submitting, setSubmitting] = useState14(false);
  const [savingReviewId, setSavingReviewId] = useState14(null);
  const [recordingEarnings, setRecordingEarnings] = useState14(null);
  const [error, setError] = useState14("");
  const [notice, setNotice] = useState14("");
  const [title, setTitle] = useState14("");
  const [description, setDescription] = useState14("");
  const [submissionTarget, setSubmissionTarget] = useState14("wage_shop");
  const [externalStoreUrl, setExternalStoreUrl] = useState14("");
  const [manualMediaLinks, setManualMediaLinks] = useState14("");
  const [embedLinks, setEmbedLinks] = useState14("");
  const [files, setFiles] = useState14([]);
  const [reviewStatus, setReviewStatus] = useState14({});
  const [reviewCreatorSplit, setReviewCreatorSplit] = useState14({});
  const [reviewWageSplit, setReviewWageSplit] = useState14({});
  const [reviewNotes, setReviewNotes] = useState14({});
  const [grossInputs, setGrossInputs] = useState14({});
  const sortedSubmissions = useMemo5(
    () => [...submissions].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()),
    [submissions]
  );
  const loadData = async () => {
    setLoading(true);
    setError("");
    try {
      const [submissionsRes, earningsRes] = await Promise.all([
        authedFetch("/api/merch-studio/submissions"),
        authedFetch("/api/merch-studio/earnings")
      ]);
      const submissionsData = await submissionsRes.json();
      const earningsData = await earningsRes.json();
      if (!submissionsRes.ok) {
        setError(submissionsData?.error || "Failed to load merch submissions.");
        setSubmissions([]);
      } else {
        setSubmissions(submissionsData?.submissions || []);
        setCanReview(Boolean(submissionsData?.canReview));
      }
      if (!earningsRes.ok) {
        if (!submissionsRes.ok) {
          setError(
            submissionsData?.error || earningsData?.error || "Failed to load Merch Studio data."
          );
        }
        setEarnings([]);
        setSummary({ memberDueCents: 0, memberPaidCents: 0, memberPendingCents: 0 });
      } else {
        setEarnings(earningsData?.earnings || []);
        setSummary(
          earningsData?.summary || {
            memberDueCents: 0,
            memberPaidCents: 0,
            memberPendingCents: 0
          }
        );
      }
    } catch {
      setError("Failed to load Merch Studio data.");
    } finally {
      setLoading(false);
    }
  };
  useEffect13(() => {
    void loadData();
  }, []);
  const uploadFiles = async (fileList) => {
    const uploaded = [];
    for (const file of fileList) {
      const form = new FormData();
      form.append("file", file);
      const response = await authedFetch("/api/merch-studio/upload", {
        method: "POST",
        body: form
      });
      const data = await response.json();
      if (!response.ok || !data.url) {
        throw new Error(data.error || `Upload failed for ${file.name}`);
      }
      uploaded.push(data.url);
    }
    return uploaded;
  };
  const handleSubmit = async (event) => {
    event.preventDefault();
    setSubmitting(true);
    setError("");
    setNotice("");
    try {
      const uploadedUrls = await uploadFiles(files);
      const manualUrls = parseLines(manualMediaLinks);
      const externalUrl = externalStoreUrl.trim();
      const response = await authedFetch("/api/merch-studio/submissions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title,
          description,
          submissionTarget,
          externalStoreUrl: externalUrl,
          mediaUrls: [...uploadedUrls, ...manualUrls],
          embedLinks: parseLines(embedLinks)
        })
      });
      const data = await response.json();
      if (!response.ok) {
        setError(data.error || "Unable to submit merch concept.");
        return;
      }
      setTitle("");
      setDescription("");
      setSubmissionTarget("wage_shop");
      setExternalStoreUrl("");
      setManualMediaLinks("");
      setEmbedLinks("");
      setFiles([]);
      setNotice("Merch concept submitted. Admin review is now pending.");
      await loadData();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to submit merch concept.");
    } finally {
      setSubmitting(false);
    }
  };
  const handleAdminReview = async (submission) => {
    const creatorSplit = reviewCreatorSplit[submission.id] ?? submission.creatorSplitPercent;
    const wageSplit = reviewWageSplit[submission.id] ?? submission.wageSplitPercent;
    const status = reviewStatus[submission.id] ?? submission.status;
    const adminNotes = reviewNotes[submission.id] ?? submission.adminNotes ?? "";
    setSavingReviewId(submission.id);
    setError("");
    setNotice("");
    try {
      const response = await authedFetch("/api/merch-studio/submissions", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          id: submission.id,
          status,
          adminNotes,
          creatorSplitPercent: creatorSplit,
          wageSplitPercent: wageSplit
        })
      });
      const data = await response.json();
      if (!response.ok) {
        setError(data.error || "Failed to save review decision.");
        return;
      }
      setNotice("Review decision saved.");
      await loadData();
    } catch {
      setError("Failed to save review decision.");
    } finally {
      setSavingReviewId(null);
    }
  };
  const handleRecordEarnings = async (submissionId) => {
    const grossInput = grossInputs[submissionId] || "";
    const grossCents = Math.round(Number(grossInput) * 100);
    if (!Number.isFinite(grossCents) || grossCents < 0) {
      setError("Gross revenue must be a valid non-negative dollar amount.");
      return;
    }
    setRecordingEarnings(submissionId);
    setError("");
    setNotice("");
    try {
      const response = await authedFetch("/api/merch-studio/earnings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          submissionId,
          grossCents
        })
      });
      const data = await response.json();
      if (!response.ok) {
        setError(data.error || "Failed to record earnings.");
        return;
      }
      setGrossInputs((prev) => ({ ...prev, [submissionId]: "" }));
      setNotice("Earnings recorded.");
      await loadData();
    } catch {
      setError("Failed to record earnings.");
    } finally {
      setRecordingEarnings(null);
    }
  };
  return /* @__PURE__ */ jsxs17("div", { className: "mx-auto mt-6 w-full max-w-6xl space-y-6", children: [
    /* @__PURE__ */ jsxs17("section", { className: "rounded-2xl border border-zinc-800 bg-zinc-900/70 p-5 sm:p-6", children: [
      /* @__PURE__ */ jsx19("p", { className: "text-xs font-semibold uppercase tracking-[0.16em] text-orange-200", children: "Merch Studio" }),
      /* @__PURE__ */ jsx19("h1", { className: "mt-2 text-2xl font-black text-zinc-50 sm:text-3xl", children: "Creator mockups, admin review, and payout tracking." }),
      /* @__PURE__ */ jsx19("p", { className: "mt-2 max-w-3xl text-sm text-zinc-300", children: "Submit mockups, 3D renders, product links, and embeds for WAGE Shop or your personal store. Admins can accept or deny submissions, assign split percentages, and record payouts over time." })
    ] }),
    /* @__PURE__ */ jsxs17("section", { className: "grid gap-4 sm:grid-cols-3", children: [
      /* @__PURE__ */ jsxs17("div", { className: "rounded-xl border border-zinc-800 bg-zinc-900/70 p-4", children: [
        /* @__PURE__ */ jsx19("p", { className: "text-xs uppercase tracking-[0.12em] text-zinc-400", children: "Member Due" }),
        /* @__PURE__ */ jsx19("p", { className: "mt-1 text-2xl font-bold text-emerald-300", children: centsToUsd(summary.memberDueCents) })
      ] }),
      /* @__PURE__ */ jsxs17("div", { className: "rounded-xl border border-zinc-800 bg-zinc-900/70 p-4", children: [
        /* @__PURE__ */ jsx19("p", { className: "text-xs uppercase tracking-[0.12em] text-zinc-400", children: "Member Paid" }),
        /* @__PURE__ */ jsx19("p", { className: "mt-1 text-2xl font-bold text-blue-300", children: centsToUsd(summary.memberPaidCents) })
      ] }),
      /* @__PURE__ */ jsxs17("div", { className: "rounded-xl border border-zinc-800 bg-zinc-900/70 p-4", children: [
        /* @__PURE__ */ jsx19("p", { className: "text-xs uppercase tracking-[0.12em] text-zinc-400", children: "Member Pending" }),
        /* @__PURE__ */ jsx19("p", { className: "mt-1 text-2xl font-bold text-orange-200", children: centsToUsd(summary.memberPendingCents) })
      ] })
    ] }),
    error ? /* @__PURE__ */ jsx19("p", { className: "rounded-lg border border-rose-500/40 bg-rose-500/10 px-4 py-2 text-sm text-rose-200", children: error }) : null,
    notice ? /* @__PURE__ */ jsx19("p", { className: "rounded-lg border border-emerald-500/30 bg-emerald-500/10 px-4 py-2 text-sm text-emerald-200", children: notice }) : null,
    /* @__PURE__ */ jsxs17("section", { className: "rounded-2xl border border-zinc-800 bg-zinc-900/70 p-5 sm:p-6", children: [
      /* @__PURE__ */ jsx19("h2", { className: "text-xl font-bold text-zinc-50", children: "Submit A Merch Concept" }),
      /* @__PURE__ */ jsxs17("form", { onSubmit: handleSubmit, className: "mt-4 space-y-3", children: [
        /* @__PURE__ */ jsx19(
          "input",
          {
            type: "text",
            value: title,
            onChange: (event) => setTitle(event.target.value),
            placeholder: "Title",
            className: "w-full rounded-lg border border-zinc-700 bg-zinc-950/60 px-3 py-2 text-sm text-zinc-100",
            required: true
          }
        ),
        /* @__PURE__ */ jsx19(
          "textarea",
          {
            value: description,
            onChange: (event) => setDescription(event.target.value),
            placeholder: "Describe your design, target audience, and product concept",
            className: "h-32 w-full rounded-lg border border-zinc-700 bg-zinc-950/60 px-3 py-2 text-sm text-zinc-100",
            required: true
          }
        ),
        /* @__PURE__ */ jsxs17("div", { className: "grid gap-3 sm:grid-cols-2", children: [
          /* @__PURE__ */ jsxs17("label", { className: "text-sm text-zinc-300", children: [
            /* @__PURE__ */ jsx19("span", { className: "mb-1 block text-xs uppercase tracking-[0.12em] text-zinc-400", children: "Submission target" }),
            /* @__PURE__ */ jsxs17(
              "select",
              {
                value: submissionTarget,
                onChange: (event) => setSubmissionTarget(event.target.value),
                className: "w-full rounded-lg border border-zinc-700 bg-zinc-950/60 px-3 py-2 text-sm text-zinc-100",
                children: [
                  /* @__PURE__ */ jsx19("option", { value: "wage_shop", children: "WAGE Shop" }),
                  /* @__PURE__ */ jsx19("option", { value: "personal_store", children: "Personal Store" })
                ]
              }
            )
          ] }),
          /* @__PURE__ */ jsxs17("label", { className: "text-sm text-zinc-300", children: [
            /* @__PURE__ */ jsx19("span", { className: "mb-1 block text-xs uppercase tracking-[0.12em] text-zinc-400", children: "External store URL" }),
            /* @__PURE__ */ jsx19(
              "input",
              {
                type: "url",
                value: externalStoreUrl,
                onChange: (event) => setExternalStoreUrl(event.target.value),
                placeholder: "https://",
                className: "w-full rounded-lg border border-zinc-700 bg-zinc-950/60 px-3 py-2 text-sm text-zinc-100"
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ jsxs17("label", { className: "block text-sm text-zinc-300", children: [
          /* @__PURE__ */ jsx19("span", { className: "mb-1 block text-xs uppercase tracking-[0.12em] text-zinc-400", children: "Upload media files" }),
          /* @__PURE__ */ jsx19(
            "input",
            {
              type: "file",
              multiple: true,
              accept: "image/*,video/*,.obj,.fbx,.glb,.gltf,.stl",
              onChange: (event) => setFiles(Array.from(event.target.files || [])),
              className: "w-full rounded-lg border border-zinc-700 bg-zinc-950/60 px-3 py-2 text-sm text-zinc-100"
            }
          )
        ] }),
        /* @__PURE__ */ jsx19(
          "textarea",
          {
            value: manualMediaLinks,
            onChange: (event) => setManualMediaLinks(event.target.value),
            placeholder: "Additional media URLs (one per line)",
            className: "h-24 w-full rounded-lg border border-zinc-700 bg-zinc-950/60 px-3 py-2 text-sm text-zinc-100"
          }
        ),
        /* @__PURE__ */ jsx19(
          "textarea",
          {
            value: embedLinks,
            onChange: (event) => setEmbedLinks(event.target.value),
            placeholder: "Embeds/links (YouTube, product page, inspiration links - one per line)",
            className: "h-24 w-full rounded-lg border border-zinc-700 bg-zinc-950/60 px-3 py-2 text-sm text-zinc-100"
          }
        ),
        /* @__PURE__ */ jsx19(
          "button",
          {
            type: "submit",
            disabled: submitting,
            className: "rounded-lg bg-orange-300 px-4 py-2 text-sm font-semibold text-zinc-950 transition hover:bg-orange-200 disabled:opacity-70",
            children: submitting ? "Submitting..." : "Submit Concept"
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ jsxs17("section", { className: "space-y-4", children: [
      /* @__PURE__ */ jsx19("h2", { className: "text-xl font-bold text-zinc-50", children: "Submissions" }),
      loading ? /* @__PURE__ */ jsx19("div", { className: "rounded-xl border border-zinc-800 bg-zinc-900/70 p-4 text-sm text-zinc-300", children: "Loading submissions..." }) : sortedSubmissions.length === 0 ? /* @__PURE__ */ jsx19("div", { className: "rounded-xl border border-zinc-800 bg-zinc-900/70 p-4 text-sm text-zinc-300", children: "No merch submissions yet." }) : sortedSubmissions.map((submission) => {
        const relatedEarnings = earnings.filter((entry) => entry.submissionId === submission.id);
        return /* @__PURE__ */ jsxs17("article", { className: "rounded-2xl border border-zinc-800 bg-zinc-900/70 p-5", children: [
          /* @__PURE__ */ jsxs17("div", { className: "flex flex-wrap items-center justify-between gap-3", children: [
            /* @__PURE__ */ jsxs17("div", { children: [
              /* @__PURE__ */ jsx19("h3", { className: "text-lg font-bold text-zinc-50", children: submission.title }),
              /* @__PURE__ */ jsxs17("p", { className: "text-xs uppercase tracking-[0.12em] text-zinc-400", children: [
                submission.submissionTarget === "wage_shop" ? "WAGE Shop" : "Personal Store",
                " | ",
                submission.status
              ] })
            ] }),
            /* @__PURE__ */ jsxs17("p", { className: "text-xs text-zinc-400", children: [
              "Submitted ",
              new Date(submission.createdAt).toLocaleString()
            ] })
          ] }),
          /* @__PURE__ */ jsx19("p", { className: "mt-3 whitespace-pre-line text-sm text-zinc-200", children: submission.description }),
          submission.externalStoreUrl ? /* @__PURE__ */ jsxs17("p", { className: "mt-3 text-sm text-zinc-300", children: [
            "External store:",
            " ",
            /* @__PURE__ */ jsx19("a", { href: submission.externalStoreUrl, target: "_blank", rel: "noreferrer", className: "text-blue-300 underline", children: submission.externalStoreUrl })
          ] }) : null,
          submission.mediaUrls.length > 0 ? /* @__PURE__ */ jsx19("div", { className: "mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-3", children: submission.mediaUrls.map((url) => /* @__PURE__ */ jsxs17("div", { className: "rounded-lg border border-zinc-700 bg-zinc-950/50 p-2", children: [
            looksLikeImage(url) ? /* @__PURE__ */ jsx19("img", { src: url, alt: submission.title, className: "h-44 w-full rounded object-cover" }) : null,
            looksLikeVideo(url) ? /* @__PURE__ */ jsx19("video", { src: url, controls: true, className: "h-44 w-full rounded object-cover" }) : null,
            !looksLikeImage(url) && !looksLikeVideo(url) ? /* @__PURE__ */ jsx19("a", { href: url, target: "_blank", rel: "noreferrer", className: "text-xs text-blue-300 underline break-all", children: url }) : null
          ] }, url)) }) : null,
          submission.embedLinks.length > 0 ? /* @__PURE__ */ jsx19("ul", { className: "mt-4 space-y-2 text-sm", children: submission.embedLinks.map((link) => /* @__PURE__ */ jsx19("li", { children: /* @__PURE__ */ jsx19("a", { href: link, target: "_blank", rel: "noreferrer", className: "text-blue-300 underline break-all", children: link }) }, link)) }) : null,
          /* @__PURE__ */ jsxs17("div", { className: "mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-4", children: [
            /* @__PURE__ */ jsxs17("div", { className: "rounded-lg border border-zinc-700 bg-zinc-950/50 p-3", children: [
              /* @__PURE__ */ jsx19("p", { className: "text-xs uppercase tracking-[0.12em] text-zinc-400", children: "Creator Split" }),
              /* @__PURE__ */ jsxs17("p", { className: "mt-1 text-sm font-semibold text-zinc-100", children: [
                submission.creatorSplitPercent,
                "%"
              ] })
            ] }),
            /* @__PURE__ */ jsxs17("div", { className: "rounded-lg border border-zinc-700 bg-zinc-950/50 p-3", children: [
              /* @__PURE__ */ jsx19("p", { className: "text-xs uppercase tracking-[0.12em] text-zinc-400", children: "WAGE Split" }),
              /* @__PURE__ */ jsxs17("p", { className: "mt-1 text-sm font-semibold text-zinc-100", children: [
                submission.wageSplitPercent,
                "%"
              ] })
            ] }),
            /* @__PURE__ */ jsxs17("div", { className: "rounded-lg border border-zinc-700 bg-zinc-950/50 p-3", children: [
              /* @__PURE__ */ jsx19("p", { className: "text-xs uppercase tracking-[0.12em] text-zinc-400", children: "Total Member Due" }),
              /* @__PURE__ */ jsx19("p", { className: "mt-1 text-sm font-semibold text-emerald-300", children: centsToUsd(relatedEarnings.reduce((acc, item) => acc + item.memberDueCents, 0)) })
            ] }),
            /* @__PURE__ */ jsxs17("div", { className: "rounded-lg border border-zinc-700 bg-zinc-950/50 p-3", children: [
              /* @__PURE__ */ jsx19("p", { className: "text-xs uppercase tracking-[0.12em] text-zinc-400", children: "Pending Member" }),
              /* @__PURE__ */ jsx19("p", { className: "mt-1 text-sm font-semibold text-orange-200", children: centsToUsd(
                relatedEarnings.reduce(
                  (acc, item) => acc + Math.max(0, item.memberDueCents - item.paidToMemberCents),
                  0
                )
              ) })
            ] })
          ] }),
          canReview ? /* @__PURE__ */ jsxs17("div", { className: "mt-5 space-y-3 rounded-xl border border-zinc-700 bg-zinc-950/60 p-4", children: [
            /* @__PURE__ */ jsx19("h4", { className: "text-sm font-bold uppercase tracking-[0.12em] text-zinc-300", children: "Admin Review" }),
            /* @__PURE__ */ jsxs17("div", { className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-4", children: [
              /* @__PURE__ */ jsxs17("label", { className: "text-xs text-zinc-300", children: [
                /* @__PURE__ */ jsx19("span", { className: "mb-1 block uppercase tracking-[0.12em] text-zinc-400", children: "Status" }),
                /* @__PURE__ */ jsxs17(
                  "select",
                  {
                    value: reviewStatus[submission.id] ?? submission.status,
                    onChange: (event) => setReviewStatus((prev) => ({
                      ...prev,
                      [submission.id]: event.target.value
                    })),
                    className: "w-full rounded-lg border border-zinc-700 bg-zinc-900 px-2 py-2 text-sm text-zinc-100",
                    children: [
                      /* @__PURE__ */ jsx19("option", { value: "submitted", children: "submitted" }),
                      /* @__PURE__ */ jsx19("option", { value: "under_review", children: "under_review" }),
                      /* @__PURE__ */ jsx19("option", { value: "accepted", children: "accepted" }),
                      /* @__PURE__ */ jsx19("option", { value: "denied", children: "denied" })
                    ]
                  }
                )
              ] }),
              /* @__PURE__ */ jsxs17("label", { className: "text-xs text-zinc-300", children: [
                /* @__PURE__ */ jsx19("span", { className: "mb-1 block uppercase tracking-[0.12em] text-zinc-400", children: "Creator %" }),
                /* @__PURE__ */ jsx19(
                  "input",
                  {
                    type: "number",
                    min: 0,
                    max: 100,
                    step: "0.1",
                    value: reviewCreatorSplit[submission.id] ?? submission.creatorSplitPercent,
                    onChange: (event) => setReviewCreatorSplit((prev) => ({
                      ...prev,
                      [submission.id]: Number(event.target.value)
                    })),
                    className: "w-full rounded-lg border border-zinc-700 bg-zinc-900 px-2 py-2 text-sm text-zinc-100"
                  }
                )
              ] }),
              /* @__PURE__ */ jsxs17("label", { className: "text-xs text-zinc-300", children: [
                /* @__PURE__ */ jsx19("span", { className: "mb-1 block uppercase tracking-[0.12em] text-zinc-400", children: "WAGE %" }),
                /* @__PURE__ */ jsx19(
                  "input",
                  {
                    type: "number",
                    min: 0,
                    max: 100,
                    step: "0.1",
                    value: reviewWageSplit[submission.id] ?? submission.wageSplitPercent,
                    onChange: (event) => setReviewWageSplit((prev) => ({
                      ...prev,
                      [submission.id]: Number(event.target.value)
                    })),
                    className: "w-full rounded-lg border border-zinc-700 bg-zinc-900 px-2 py-2 text-sm text-zinc-100"
                  }
                )
              ] }),
              /* @__PURE__ */ jsxs17("label", { className: "text-xs text-zinc-300", children: [
                /* @__PURE__ */ jsx19("span", { className: "mb-1 block uppercase tracking-[0.12em] text-zinc-400", children: "Gross $" }),
                /* @__PURE__ */ jsx19(
                  "input",
                  {
                    type: "number",
                    min: 0,
                    step: "0.01",
                    value: grossInputs[submission.id] ?? "",
                    onChange: (event) => setGrossInputs((prev) => ({
                      ...prev,
                      [submission.id]: event.target.value
                    })),
                    placeholder: "0.00",
                    className: "w-full rounded-lg border border-zinc-700 bg-zinc-900 px-2 py-2 text-sm text-zinc-100"
                  }
                )
              ] })
            ] }),
            /* @__PURE__ */ jsx19(
              "textarea",
              {
                value: reviewNotes[submission.id] ?? submission.adminNotes ?? "",
                onChange: (event) => setReviewNotes((prev) => ({
                  ...prev,
                  [submission.id]: event.target.value
                })),
                placeholder: "Admin notes",
                className: "h-20 w-full rounded-lg border border-zinc-700 bg-zinc-900 px-3 py-2 text-sm text-zinc-100"
              }
            ),
            /* @__PURE__ */ jsxs17("div", { className: "flex flex-wrap gap-2", children: [
              /* @__PURE__ */ jsx19(
                "button",
                {
                  type: "button",
                  onClick: () => void handleAdminReview(submission),
                  disabled: savingReviewId === submission.id,
                  className: "rounded-lg bg-orange-300 px-3 py-2 text-sm font-semibold text-zinc-950 disabled:opacity-70",
                  children: savingReviewId === submission.id ? "Saving..." : "Save Review"
                }
              ),
              /* @__PURE__ */ jsx19(
                "button",
                {
                  type: "button",
                  onClick: () => void handleRecordEarnings(submission.id),
                  disabled: recordingEarnings === submission.id,
                  className: "rounded-lg border border-zinc-500 px-3 py-2 text-sm font-semibold text-zinc-100 disabled:opacity-70",
                  children: recordingEarnings === submission.id ? "Recording..." : "Record Earnings"
                }
              )
            ] })
          ] }) : null
        ] }, submission.id);
      })
    ] })
  ] });
}
function hasSupabaseAdminConfig() {
  return Boolean(supabaseUrl$1 && serverKey);
}
function getSupabaseAdminConfigIssues() {
  const issues = [];
  if (!supabaseUrl$1) {
    issues.push("Missing Supabase URL. Set SUPABASE_URL, VITE_SUPABASE_URL, or NEXT_PUBLIC_SUPABASE_URL.");
  }
  if (!serverKey) {
    issues.push(
      "Missing service role key. Set SUPABASE_SERVICE_ROLE_KEY, SUPABASE_SERVICE_KEY, SUPABASE_SECRET_KEY, or SUPABASE_SERVICE_ROLE. The admin client requires a server-only key \u2014 do not use anon/publishable keys here."
    );
  }
  return issues;
}
function getSupabaseAdminClient() {
  if (!hasSupabaseAdminConfig()) {
    throw new Error(getSupabaseAdminConfigIssues().join(" "));
  }
  if (!adminClient) {
    adminClient = createClient(supabaseUrl$1, serverKey, {
      auth: {
        persistSession: false,
        autoRefreshToken: false
      }
    });
  }
  return adminClient;
}
function getStripeSecretKey$1() {
  return process.env.STRIPE_SECRET_KEY || process.env.STRIPE_API_KEY || process.env.STRIPE_SECRET || "";
}
function getStripeWebhookSecret() {
  return process.env.STRIPE_WEBHOOK_SECRET || process.env.STRIPE_WEBHOOK_SIGNING_SECRET || "";
}
function getStripe$1() {
  const key = getStripeSecretKey$1();
  if (!key) {
    throw new Error(
      "Billing webhook is not configured. Set STRIPE_SECRET_KEY (or STRIPE_API_KEY / STRIPE_SECRET)."
    );
  }
  return new Stripe(key, { apiVersion: "2026-03-25.dahlia" });
}
function extractPlanSlugFromSubscription(subscription) {
  const fromMeta = subscription.metadata?.membership_plan?.trim();
  if (fromMeta) return fromMeta;
  const firstItem = subscription.items.data[0];
  const fromPriceMeta = firstItem?.price?.metadata?.planSlug?.trim();
  if (fromPriceMeta) return fromPriceMeta;
  const fromProductMeta = firstItem?.price?.product;
  if (fromProductMeta && typeof fromProductMeta !== "string") {
    const slug = fromProductMeta.metadata?.planSlug?.trim();
    if (slug) return slug;
  }
  return null;
}
async function updateMembershipMetadataByEmail(email, updates) {
  const admin = getSupabaseAdminClient();
  const { data: users, error: usersError } = await admin.schema("auth").from("users").select("id, raw_user_meta_data").ilike("email", email).limit(1);
  if (usersError) throw new Error(usersError.message);
  const user = Array.isArray(users) ? users[0] : null;
  if (!user?.id) return;
  const currentMeta = user.raw_user_meta_data ?? {};
  const nextMeta = {
    ...currentMeta,
    ...updates
  };
  const { error: updateError } = await admin.auth.admin.updateUserById(user.id, {
    user_metadata: nextMeta
  });
  if (updateError) throw new Error(updateError.message);
}
function createServerClient(accessToken) {
  return createClient(supabaseUrl, publishableKey, {
    global: accessToken ? {
      headers: {
        Authorization: `Bearer ${accessToken}`
      }
    } : void 0,
    auth: {
      persistSession: false,
      autoRefreshToken: false
    }
  });
}
function getSupabaseServerPublicClient() {
  if (!supabaseUrl) {
    throw new Error("Missing Supabase URL. Set SUPABASE_URL or VITE_SUPABASE_URL.");
  }
  if (!publishableKey) {
    throw new Error(
      "Missing Supabase publishable key. Set SUPABASE_PUBLISHABLE_KEY, SUPABASE_ANON_KEY, VITE_SUPABASE_PUBLISHABLE_KEY, or NEXT_PUBLIC_SUPABASE_ANON_KEY."
    );
  }
  if (!serverPublicClient) {
    serverPublicClient = createServerClient();
  }
  return serverPublicClient;
}
function getSupabaseServerClientForToken(accessToken) {
  if (!supabaseUrl) {
    throw new Error("Missing Supabase URL. Set SUPABASE_URL or VITE_SUPABASE_URL.");
  }
  if (!publishableKey) {
    throw new Error(
      "Missing Supabase publishable key. Set SUPABASE_PUBLISHABLE_KEY, SUPABASE_ANON_KEY, VITE_SUPABASE_PUBLISHABLE_KEY, or NEXT_PUBLIC_SUPABASE_ANON_KEY."
    );
  }
  return createServerClient(accessToken);
}
function normalizeMemberUsername(value) {
  return value.trim().toLowerCase().replace(/[^a-z0-9_-]+/g, "-").replace(/-{2,}/g, "-").replace(/^-+|-+$/g, "");
}
function readUsernameFromMetadata(meta) {
  const candidates = [meta?.username, meta?.preferred_username];
  for (const candidate of candidates) {
    const normalized = normalizeMemberUsername(candidate || "");
    if (normalized) return normalized;
  }
  return null;
}
function readDisplayNameFromMetadata(meta) {
  const candidates = [meta?.full_name, meta?.name];
  for (const candidate of candidates) {
    const trimmed = candidate?.trim();
    if (trimmed) return trimmed;
  }
  return null;
}
function readAvatarFromMetadata(meta) {
  const candidates = [meta?.avatar_url, meta?.picture];
  for (const candidate of candidates) {
    const trimmed = candidate?.trim();
    if (trimmed) return trimmed;
  }
  return null;
}
function makeBaseUsername(user) {
  const fromMeta = readUsernameFromMetadata(user.user_metadata);
  if (fromMeta) return fromMeta;
  const emailLocal = String(user.email || "").toLowerCase().trim().split("@")[0];
  const fromEmail = normalizeMemberUsername(emailLocal);
  if (fromEmail) return fromEmail;
  return `member-${String(user.id || "").slice(0, 8)}`;
}
function assignDeterministicUsernames(users) {
  const sorted = [...users].sort((a, b) => {
    const aCreated = a.created_at || "";
    const bCreated = b.created_at || "";
    if (aCreated !== bCreated) return aCreated.localeCompare(bCreated);
    return String(a.id || "").localeCompare(String(b.id || ""));
  });
  const taken = /* @__PURE__ */ new Set();
  const result = /* @__PURE__ */ new Map();
  for (const user of sorted) {
    const base = makeBaseUsername(user);
    let candidate = base;
    if (taken.has(candidate)) {
      const shortId = String(user.id || "").slice(0, 6).toLowerCase();
      candidate = normalizeMemberUsername(`${base}-${shortId}`) || `${base}-member`;
      let i = 2;
      while (taken.has(candidate)) {
        candidate = `${base}-${shortId}-${i}`;
        i += 1;
      }
    }
    taken.add(candidate);
    result.set(String(user.id), candidate);
  }
  return result;
}
function normalizeEmail(value) {
  const trimmed = String(value || "").trim().toLowerCase();
  return trimmed || null;
}
function normalizeDateOrNow(value) {
  const str = String(value || "").trim();
  return str || (/* @__PURE__ */ new Date()).toISOString();
}
function normalizeRows(data) {
  const rows = Array.isArray(data) ? data : [];
  return rows.filter((row) => Boolean(row.user_id)).map((row) => ({
    id: row.user_id,
    email: normalizeEmail(row.email),
    user_metadata: row.user_metadata || null,
    created_at: normalizeDateOrNow(row.created_at),
    updated_at: normalizeDateOrNow(row.updated_at || row.created_at),
    identities: null
  }));
}
async function listDirectAuthUsers(client) {
  const listUsers = client.auth?.admin?.listUsers;
  if (!listUsers) return [];
  const collected = [];
  let page = 1;
  const perPage = 1e3;
  while (page <= 10) {
    const { data, error } = await listUsers({ page, perPage });
    if (error) break;
    const pageUsers = Array.isArray(data?.users) ? data.users : [];
    if (!pageUsers.length) break;
    for (const row of pageUsers) {
      const id = String(row.id || "").trim();
      if (!id) continue;
      const createdAt = normalizeDateOrNow(row.created_at);
      const updatedAt = normalizeDateOrNow(row.updated_at || row.created_at);
      collected.push({
        id,
        email: normalizeEmail(row.email),
        user_metadata: row.user_metadata || null,
        created_at: createdAt,
        updated_at: updatedAt,
        identities: null
      });
    }
    if (pageUsers.length < perPage) break;
    page += 1;
  }
  return collected;
}
function mergeUsers(sources) {
  const byKey = /* @__PURE__ */ new Map();
  for (const source of sources) {
    for (const user of source) {
      const id = String(user.id || "").trim();
      const email = normalizeEmail(user.email);
      const key = id || email;
      if (!key) continue;
      const existing = byKey.get(key);
      if (!existing) {
        byKey.set(key, {
          id: id || key,
          email,
          user_metadata: user.user_metadata || null,
          created_at: normalizeDateOrNow(user.created_at),
          updated_at: normalizeDateOrNow(user.updated_at || user.created_at),
          identities: null
        });
        continue;
      }
      byKey.set(key, {
        ...existing,
        id: id || existing.id,
        email: email || existing.email || null,
        user_metadata: user.user_metadata || existing.user_metadata || null,
        created_at: normalizeDateOrNow(existing.created_at || user.created_at),
        updated_at: normalizeDateOrNow(user.updated_at || existing.updated_at || user.created_at),
        identities: null
      });
    }
  }
  return Array.from(byKey.values()).sort((a, b) => {
    const aCreated = String(a.created_at || "");
    const bCreated = String(b.created_at || "");
    if (aCreated !== bCreated) return aCreated.localeCompare(bCreated);
    return String(a.id || "").localeCompare(String(b.id || ""));
  });
}
async function listAuthIndexedUsers(client, limit = 1e4) {
  const candidates = [];
  try {
    const rpcResult = await Promise.resolve(client.rpc?.("list_auth_users_index"));
    if (!rpcResult.error) {
      candidates.push(normalizeRows(rpcResult.data));
    }
  } catch {
  }
  try {
    const { data, error } = await client.from?.("org_auth_user_index")?.select("user_id, email, user_metadata, created_at, updated_at")?.order("created_at", { ascending: true })?.limit(limit);
    if (!error) {
      candidates.push(normalizeRows(data));
    }
  } catch {
  }
  try {
    const directUsers = await listDirectAuthUsers(client);
    if (directUsers.length > 0) {
      candidates.push(directUsers);
    }
  } catch {
  }
  if (candidates.length === 0) {
    return [];
  }
  const merged = mergeUsers(candidates);
  if (merged.length <= limit) {
    return merged;
  }
  return merged.slice(0, limit);
}
function normalizeUsername$1(value) {
  return value.trim().toLowerCase();
}
function providerLabel(provider) {
  switch (provider.toLowerCase()) {
    case "custom:kick":
      return "Kick";
    case "discord":
      return "Discord";
    case "google":
      return "Google";
    case "facebook":
      return "Facebook";
    case "github":
      return "GitHub";
    case "twitter":
      return "X / Twitter";
    case "twitch":
      return "Twitch";
    case "apple":
      return "Apple";
    default:
      return provider;
  }
}
function providerProfileUrl(provider, handle) {
  const normalizedHandle = handle.replace(/^@/, "");
  switch (provider.toLowerCase()) {
    case "custom:kick":
      return `https://kick.com/${normalizedHandle}`;
    case "twitter":
      return `https://x.com/${normalizedHandle}`;
    case "twitch":
      return `https://twitch.tv/${normalizedHandle}`;
    case "github":
      return `https://github.com/${normalizedHandle}`;
    case "discord":
      return `https://discord.com/users/${normalizedHandle}`;
    case "facebook":
      return `https://facebook.com/${normalizedHandle}`;
    default:
      return null;
  }
}
function normalizeUsername(value) {
  return value.trim().toLowerCase().replace(/[^a-z0-9_-]+/g, "-").replace(/-{2,}/g, "-").replace(/^-+|-+$/g, "");
}
function getBearerToken$4(request) {
  const authHeader = request.headers.get("authorization") || request.headers.get("Authorization") || "";
  if (!authHeader.toLowerCase().startsWith("bearer ")) return void 0;
  const token = authHeader.slice(7).trim();
  return token || void 0;
}
function isLocalRequest(request) {
  const host = request.headers.get("host") || "";
  return host.includes("localhost") || host.includes("127.0.0.1");
}
async function resolveRequester(request) {
  const useLocalRootHeader = request.headers.get("x-local-root-session") === "true";
  if (isLocalRequest(request) && (process.env.ALLOW_LOCALHOST_SUPERADMIN === "true" || useLocalRootHeader)) {
    return {
      email: LOCAL_SUPERADMIN_EMAIL,
      source: "localhost-bypass"
    };
  }
  const authHeader = request.headers.get("authorization") || request.headers.get("Authorization");
  const token = authHeader?.startsWith("Bearer ") ? authHeader.slice(7).trim() : "";
  if (!token) {
    throw new Response(JSON.stringify({ error: "Unauthorized" }), {
      status: 401,
      headers: { "Content-Type": "application/json" }
    });
  }
  const authClient = hasSupabaseAdminConfig() ? getSupabaseAdminClient() : getSupabaseServerPublicClient();
  const { data, error } = await authClient.auth.getUser(token);
  const email = data.user?.email?.toLowerCase();
  if (error || !email) {
    throw new Response(JSON.stringify({ error: "Unauthorized" }), {
      status: 401,
      headers: { "Content-Type": "application/json" }
    });
  }
  return {
    email,
    source: "supabase-auth"
  };
}
async function resolveOrgRole(email) {
  const normalizedEmail = email.toLowerCase();
  if (normalizedEmail === LOCAL_SUPERADMIN_EMAIL) {
    if (!hasSupabaseAdminConfig()) {
      return "superadmin";
    }
    const admin2 = getSupabaseAdminClient();
    const { error: error2 } = await admin2.rpc("set_org_member_role", {
      p_target_email: LOCAL_SUPERADMIN_EMAIL,
      p_role: "superadmin",
      p_granted_by: "system:localhost-root"
    });
    if (error2) {
      return "superadmin";
    }
    return "superadmin";
  }
  if (OWNER_SUPERADMIN_EMAILS.has(normalizedEmail)) {
    if (!hasSupabaseAdminConfig()) {
      return "superadmin";
    }
    const admin2 = getSupabaseAdminClient();
    const { error: error2 } = await admin2.rpc("set_org_member_role", {
      p_target_email: normalizedEmail,
      p_role: "superadmin",
      p_granted_by: LOCAL_SUPERADMIN_EMAIL
    });
    if (error2) {
      return "superadmin";
    }
    return "superadmin";
  }
  if (!hasSupabaseAdminConfig()) {
    return "user";
  }
  const admin = getSupabaseAdminClient();
  const { data, error } = await admin.rpc("ensure_org_member_role", {
    p_email: normalizedEmail
  });
  if (error || !data) {
    throw new Response(JSON.stringify({ error: `Role resolution failed: ${error?.message || "Unknown error"}` }), {
      status: 500,
      headers: { "Content-Type": "application/json" }
    });
  }
  if (!isOrgRole(data)) {
    throw new Response(JSON.stringify({ error: "Invalid role in role resolution" }), {
      status: 500,
      headers: { "Content-Type": "application/json" }
    });
  }
  return data;
}
async function getRolePermissions(role) {
  if (role === "banned") {
    return [];
  }
  if (!hasSupabaseAdminConfig()) {
    return role === "superadmin" ? SUPERADMIN_FALLBACK_PERMISSIONS : [];
  }
  const admin = getSupabaseAdminClient();
  const { data, error } = await admin.rpc("list_org_permissions_for_role", {
    p_role: role
  });
  if (error) {
    if (role === "superadmin") {
      return SUPERADMIN_FALLBACK_PERMISSIONS;
    }
    throw new Response(JSON.stringify({ error: `Permission lookup failed: ${error.message}` }), {
      status: 500,
      headers: { "Content-Type": "application/json" }
    });
  }
  return (data || []).map((row) => row.permission_key);
}
async function getBanRecord(email) {
  const admin = getSupabaseAdminClient();
  const { data, error } = await admin.from("org_user_roles").select("banned_by, ban_reason, banned_until").eq("email", email.toLowerCase()).maybeSingle();
  if (error) {
    throw new Response(JSON.stringify({ error: `Ban lookup failed: ${error.message}` }), {
      status: 500,
      headers: { "Content-Type": "application/json" }
    });
  }
  if (!data) {
    return null;
  }
  return {
    bannedBy: data.banned_by,
    banReason: data.ban_reason,
    bannedUntil: data.banned_until
  };
}
function resolveViewAsRole(request, actorRole) {
  const rawViewAsRole = request.headers.get("x-view-as-role")?.toLowerCase() || "";
  if (!rawViewAsRole || !isOrgRole(rawViewAsRole)) {
    return null;
  }
  if (actorRole === "banned") {
    return null;
  }
  if (actorRole === "superadmin") {
    return rawViewAsRole;
  }
  if (!canManageRole(actorRole, "user")) {
    return null;
  }
  return canManageRole(actorRole, rawViewAsRole) ? rawViewAsRole : null;
}
async function getRequesterAccess(request) {
  const requester = await resolveRequester(request);
  const actorRole = await resolveOrgRole(requester.email);
  const viewAsRole = resolveViewAsRole(request, actorRole);
  const role = viewAsRole || actorRole;
  if (actorRole === "banned") {
    return {
      requester,
      role,
      actorRole,
      viewingAs: viewAsRole,
      permissions: [],
      isSuperadmin: false,
      ban: await getBanRecord(requester.email)
    };
  }
  if (role === "superadmin") {
    const allPermissions = await getRolePermissions("superadmin");
    return {
      requester,
      role,
      actorRole,
      viewingAs: viewAsRole,
      permissions: allPermissions,
      isSuperadmin: true,
      ban: null
    };
  }
  const permissions = await getRolePermissions(role);
  return {
    requester,
    role,
    actorRole,
    viewingAs: viewAsRole,
    permissions,
    isSuperadmin: false,
    ban: null
  };
}
async function requirePermission(request, permission) {
  const access = await getRequesterAccess(request);
  if (access.role === "banned") {
    throw new Response(JSON.stringify({ error: "Banned accounts have no platform access" }), {
      status: 403,
      headers: { "Content-Type": "application/json" }
    });
  }
  if (access.isSuperadmin) {
    return access;
  }
  if (!access.permissions.includes(permission)) {
    throw new Response(JSON.stringify({ error: `Missing permission: ${permission}` }), {
      status: 403,
      headers: { "Content-Type": "application/json" }
    });
  }
  return access;
}
function getExtension$1(filename) {
  const parts = filename.toLowerCase().split(".");
  return parts.length > 1 ? parts.pop() || "" : "";
}
function getAuthToken(request) {
  const authHeader = request.headers.get("authorization") || "";
  if (!authHeader.toLowerCase().startsWith("bearer ")) return void 0;
  const token = authHeader.slice(7).trim();
  return token || void 0;
}
function isMissingBlogTableError(error) {
  const code = String(error?.code || "").toUpperCase();
  const message = String(error?.message || "").toLowerCase();
  return code === "42P01" || code === "PGRST205" || message.includes("org_blog_posts") || message.includes("schema cache");
}
function getQuarterStartIso(now) {
  const quarter = Math.floor(now.getUTCMonth() / 3);
  const quarterStartMonth = quarter * 3;
  return new Date(Date.UTC(now.getUTCFullYear(), quarterStartMonth, 1, 0, 0, 0, 0)).toISOString();
}
function average(values) {
  if (!values.length) return null;
  const total = values.reduce((sum, value) => sum + value, 0);
  return total / values.length;
}
function getRequestIp(request) {
  const forwardedFor = request.headers.get("x-forwarded-for") || "";
  const firstForwarded = forwardedFor.split(",")[0]?.trim();
  if (firstForwarded) return firstForwarded;
  return request.headers.get("x-real-ip") || "unknown";
}
function isRateLimited(request) {
  const key = getRequestIp(request);
  const now = Date.now();
  const cutoff = now - SUBSCRIBE_RATE_LIMIT_WINDOW_MS;
  const prior = subscribeRequestLog.get(key) || [];
  const active = prior.filter((value) => value >= cutoff);
  if (active.length >= SUBSCRIBE_RATE_LIMIT_MAX_REQUESTS) {
    subscribeRequestLog.set(key, active);
    return true;
  }
  active.push(now);
  subscribeRequestLog.set(key, active);
  return false;
}
function normalizePath(path) {
  if (!path) return "/";
  return path.startsWith("/") ? path : `/${path}`;
}
function normalizeAuthOrigin(origin) {
  try {
    const parsed = new URL(origin);
    if (LOCALHOST_HOSTS.has(parsed.hostname) && parsed.port !== "3000") {
      parsed.port = "3000";
    }
    return parsed.origin;
  } catch {
    return origin;
  }
}
function buildAuthRedirectUrl(origin, path) {
  return `${normalizeAuthOrigin(origin)}${normalizePath(path)}`;
}
function getClientAuthRedirectUrl(path) {
  if (typeof window === "undefined") return path;
  return buildAuthRedirectUrl(window.location.origin, path);
}
function getStripeSecretKey() {
  return process.env.STRIPE_SECRET_KEY || process.env.STRIPE_API_KEY || process.env.STRIPE_SECRET || "";
}
function getStripe() {
  const key = getStripeSecretKey();
  if (!key) {
    throw new Error(
      "Billing is not configured. Set STRIPE_SECRET_KEY (or STRIPE_API_KEY / STRIPE_SECRET) in Netlify environment variables."
    );
  }
  return new Stripe(key, { apiVersion: "2026-03-25.dahlia" });
}
function getBaseUrl(request) {
  const host = request.headers.get("x-forwarded-host") || request.headers.get("host");
  const proto = request.headers.get("x-forwarded-proto") || "http";
  if (!host) return "http://localhost:3000";
  return `${proto}://${host}`;
}
function getBearerToken$3(request) {
  const authHeader = request.headers.get("authorization") || request.headers.get("Authorization") || "";
  if (!authHeader.toLowerCase().startsWith("bearer ")) return void 0;
  const token = authHeader.slice(7).trim();
  return token || void 0;
}
function getServerClientForRequest(request) {
  if (hasSupabaseAdminConfig()) {
    return getSupabaseAdminClient();
  }
  const token = getBearerToken$3(request);
  if (token) {
    return getSupabaseServerClientForToken(token);
  }
  return getSupabaseServerPublicClient();
}
async function updateUserMembershipMetadata(request, email, updates) {
  if (hasSupabaseAdminConfig()) {
    const admin = getSupabaseAdminClient();
    const { data: users, error: usersError } = await admin.schema("auth").from("users").select("id, email, raw_user_meta_data").ilike("email", email).limit(1);
    if (usersError) throw new Error(usersError.message);
    const user2 = Array.isArray(users) ? users[0] : null;
    if (!user2?.id) return;
    const currentMeta2 = user2.raw_user_meta_data ?? {};
    const nextMeta2 = {
      ...currentMeta2,
      ...updates
    };
    const { error: updateError2 } = await admin.auth.admin.updateUserById(user2.id, {
      user_metadata: nextMeta2
    });
    if (updateError2) throw new Error(updateError2.message);
    return;
  }
  const token = getBearerToken$3(request);
  if (!token) {
    throw new Error("Missing user token for metadata update");
  }
  const userClient = getSupabaseServerClientForToken(token);
  const {
    data: { user },
    error: userError
  } = await userClient.auth.getUser(token);
  if (userError || !user?.email) {
    throw new Error(userError?.message || "Could not resolve current user");
  }
  if (user.email.toLowerCase() !== email.toLowerCase()) {
    throw new Error("Metadata update email mismatch");
  }
  const currentMeta = user.user_metadata ?? {};
  const nextMeta = {
    ...currentMeta,
    ...updates
  };
  const { error: updateError } = await userClient.auth.updateUser({
    data: nextMeta
  });
  if (updateError) throw new Error(updateError.message);
}
function resolveToolAndPermission(rawTool) {
  const parsed = toolSchema.safeParse(rawTool);
  if (!parsed.success) {
    throw new Response(JSON.stringify({ error: "Invalid tool key" }), {
      status: 400,
      headers: { "Content-Type": "application/json" }
    });
  }
  const tool = parsed.data;
  const permission = requiredPermissionByTool[tool];
  return { tool, permission };
}
function getBearerToken$2(request) {
  const authHeader = request.headers.get("authorization") || "";
  if (!authHeader.toLowerCase().startsWith("bearer ")) return void 0;
  const token = authHeader.slice(7).trim();
  return token || void 0;
}
function getDbClient(request) {
  if (hasSupabaseAdminConfig()) return getSupabaseAdminClient();
  const token = getBearerToken$2(request);
  if (token) return getSupabaseServerClientForToken(token);
  return getSupabaseServerPublicClient();
}
function errorMessage(error, fallback) {
  if (error instanceof Error && error.message.trim()) return error.message;
  return fallback;
}
async function authorizeForTool(request, rawTool) {
  const { tool, permission } = resolveToolAndPermission(rawTool);
  const access = await requirePermission(request, permission);
  return { tool, access };
}
function requesterPayload(access) {
  return {
    ...access.requester,
    role: access.role
  };
}
function getExtension(filename) {
  const name = filename.toLowerCase();
  const parts = name.split(".");
  return parts.length > 1 ? parts.pop() || "" : "";
}
function mapSubmission(row) {
  return {
    id: row.id,
    creatorEmail: row.creator_email,
    title: row.title,
    description: row.description,
    submissionTarget: row.submission_target,
    mediaUrls: row.media_urls || [],
    embedLinks: row.embed_links || [],
    externalStoreUrl: row.external_store_url,
    status: row.status,
    adminNotes: row.admin_notes,
    creatorSplitPercent: Number(row.creator_split_percent),
    wageSplitPercent: Number(row.wage_split_percent),
    approvedBy: row.approved_by,
    approvedAt: row.approved_at,
    createdAt: row.created_at,
    updatedAt: row.updated_at
  };
}
function mapEarning(row) {
  return {
    id: row.id,
    submissionId: row.submission_id,
    recordedBy: row.recorded_by,
    periodStart: row.period_start,
    periodEnd: row.period_end,
    grossCents: row.gross_cents,
    memberDueCents: row.member_due_cents,
    wageDueCents: row.wage_due_cents,
    paidToMemberCents: row.paid_to_member_cents,
    paidToWageCents: row.paid_to_wage_cents,
    notes: row.notes,
    createdAt: row.created_at,
    updatedAt: row.updated_at
  };
}
function readDisplayNameFromMeta(meta) {
  const candidates = [meta?.username, meta?.preferred_username];
  for (const candidate of candidates) {
    const trimmed = candidate?.trim();
    if (trimmed) return trimmed;
  }
  return null;
}
function getBearerToken$1(request) {
  const authHeader = request.headers.get("authorization") || "";
  if (!authHeader.toLowerCase().startsWith("bearer ")) return void 0;
  const token = authHeader.slice(7).trim();
  return token || void 0;
}
function createFallbackProfile(email, displayName) {
  return {
    email,
    display_name: displayName,
    avatar_url: null,
    bio: null,
    skills: [],
    livestream_links: [],
    updated_at: null
  };
}
function toTitleCase2(value) {
  return value.split(/[\s_-]+/).filter(Boolean).map((word) => word[0]?.toUpperCase() + word.slice(1)).join(" ");
}
function providerOptionFromKey2(key, explicitLabel) {
  const normalized = key.trim().toLowerCase();
  const builtin = BUILTIN_OAUTH_PROVIDER_META[normalized];
  if (builtin) {
    return { key: normalized, label: builtin.label, description: builtin.description };
  }
  const customName = normalized.startsWith("custom:") ? normalized.slice("custom:".length) : normalized;
  const label = (explicitLabel || "").trim() || toTitleCase2(customName) || normalized;
  return {
    key: normalized,
    label,
    description: `Link your ${label} account`
  };
}
async function getAvailableOAuthProviders(client, includeIdentityProviderScan) {
  const identityPromise = includeIdentityProviderScan ? client.schema("auth").from("identities").select("provider").neq("provider", "email") : Promise.resolve({ data: null, error: null });
  const [{ data: identityRows, error: identityError }, { data: customRows, error: customError }] = await Promise.all([
    identityPromise,
    client.schema("auth").from("custom_oauth_providers").select("identifier, name, enabled").eq("enabled", true)
  ]);
  const optionsByKey = /* @__PURE__ */ new Map();
  if (!identityError) {
    for (const row of identityRows ?? []) {
      const provider = String(row.provider || "").trim().toLowerCase();
      if (!provider) continue;
      optionsByKey.set(provider, providerOptionFromKey2(provider));
    }
  }
  if (!customError) {
    for (const row of customRows ?? []) {
      if (row.enabled === false) continue;
      const identifier = String(row.identifier || "").trim().toLowerCase();
      if (!identifier) continue;
      optionsByKey.set(identifier, providerOptionFromKey2(identifier, row.name));
    }
  }
  return Array.from(optionsByKey.values()).sort((a, b) => a.label.localeCompare(b.label));
}
function normalizeYouTubeSelection(raw) {
  const value = String(raw || "").trim();
  if (!value) return null;
  if (value.startsWith("handle:") || value.startsWith("channel:") || value.startsWith("user:") || value.startsWith("custom:")) {
    return value;
  }
  try {
    const url = new URL(value);
    const host = url.hostname.toLowerCase();
    if (host.includes("youtube.com") || host === "youtu.be") {
      const segments = url.pathname.split("/").filter(Boolean);
      if (segments[0]?.startsWith("@")) {
        return `handle:${segments[0].slice(1).toLowerCase()}`;
      }
      if (segments[0] === "channel" && segments[1]) return `channel:${segments[1]}`;
      if (segments[0] === "user" && segments[1]) return `user:${segments[1]}`;
      if (segments[0] === "c" && segments[1]) return `custom:${segments[1]}`;
    }
  } catch {
  }
  return null;
}
function streamKeyToYouTubeUrl(key) {
  if (key.startsWith("handle:")) return `https://www.youtube.com/@${key.slice("handle:".length)}`;
  if (key.startsWith("channel:")) return `https://www.youtube.com/channel/${key.slice("channel:".length)}`;
  if (key.startsWith("user:")) return `https://www.youtube.com/user/${key.slice("user:".length)}`;
  if (key.startsWith("custom:")) return `https://www.youtube.com/c/${key.slice("custom:".length)}`;
  return key;
}
function buildYouTubeOptions(meta, authUser) {
  const options = /* @__PURE__ */ new Map();
  const selected = normalizeYouTubeSelection(meta?.selected_youtube_channel);
  if (selected) {
    options.set(selected, {
      key: selected,
      label: `Selected channel (${selected})`,
      url: streamKeyToYouTubeUrl(selected)
    });
  }
  const identities = Array.isArray(authUser?.identities) ? authUser.identities : [];
  const googleIdentity = identities.find((identity) => String(identity?.provider || "").toLowerCase() === "google");
  const googleData = googleIdentity?.identity_data || {};
  const candidates = /* @__PURE__ */ new Set();
  const metaUsername = String(meta?.username || meta?.preferred_username || "").trim().replace(/^@/, "");
  if (metaUsername) candidates.add(metaUsername);
  const googleEmail = String(googleData.email || "").trim().toLowerCase();
  const emailPrefix = googleEmail.split("@")[0]?.replace(/^@/, "");
  if (emailPrefix) candidates.add(emailPrefix);
  const fullName = String(googleData.full_name || googleData.name || "").trim();
  if (fullName) {
    const compact = fullName.toLowerCase().replace(/[^a-z0-9]/g, "");
    if (compact.length >= 3) candidates.add(compact);
  }
  for (const candidate of candidates) {
    const key = `handle:${candidate.toLowerCase()}`;
    if (!options.has(key)) {
      options.set(key, {
        key,
        label: `@${candidate}`,
        url: streamKeyToYouTubeUrl(key)
      });
    }
  }
  return Array.from(options.values());
}
function buildConnectedStreamAccounts(meta, authUser) {
  const identities = Array.isArray(authUser?.identities) ? authUser.identities : [];
  const kickIdentity = identities.find((identity) => {
    const provider = String(identity?.provider || "").trim().toLowerCase();
    return provider === "kick" || provider === "custom:kick";
  });
  const googleIdentity = identities.find((identity) => String(identity?.provider || "").trim().toLowerCase() === "google");
  const kickData = kickIdentity?.identity_data || {};
  const kickUsernameCandidates = [
    meta?.kick_username,
    kickData.preferred_username,
    kickData.username,
    kickData.login
  ];
  let kickUsername = null;
  for (const candidate of kickUsernameCandidates) {
    const normalized = String(candidate || "").trim().replace(/^@/, "");
    if (normalized) {
      kickUsername = normalized;
      break;
    }
  }
  const selected = normalizeYouTubeSelection(meta?.selected_youtube_channel);
  const youtubeOptions = buildYouTubeOptions(meta, authUser);
  return {
    kick: {
      connected: Boolean(kickIdentity),
      username: kickUsername,
      url: kickUsername ? `https://kick.com/${kickUsername}` : null
    },
    youtube: {
      connected: Boolean(googleIdentity),
      selected,
      options: youtubeOptions
    }
  };
}
function isHostMatch(hostname, domain) {
  const normalizedHost = hostname.toLowerCase();
  const normalizedDomain = domain.toLowerCase();
  return normalizedHost === normalizedDomain || normalizedHost.endsWith(`.${normalizedDomain}`);
}
function extractYouTubeChannelRef(url) {
  const segments = url.pathname.split("/").filter(Boolean);
  if (segments.length === 0) return null;
  const [first, second] = segments;
  if (first.startsWith("@")) {
    return `handle:${first.toLowerCase()}`;
  }
  if (first === "channel" && second) {
    return `channel:${second}`;
  }
  if (first === "user" && second) {
    return `user:${second}`;
  }
  if (first === "c" && second) {
    return `custom:${second}`;
  }
  return null;
}
function extractTwitchChannel(url) {
  if (!isHostMatch(url.hostname, "twitch.tv")) return null;
  const slug = url.pathname.split("/").filter(Boolean)[0];
  if (!slug) return null;
  const reserved = /* @__PURE__ */ new Set(["directory", "settings", "login", "signup"]);
  if (reserved.has(slug.toLowerCase())) return null;
  return slug.toLowerCase();
}
function extractKickChannel(url) {
  if (!isHostMatch(url.hostname, "kick.com")) return null;
  const slug = url.pathname.split("/").filter(Boolean)[0];
  if (!slug) return null;
  const reserved = /* @__PURE__ */ new Set(["categories", "search", "video", "settings", "login", "signup"]);
  if (reserved.has(slug.toLowerCase())) return null;
  return slug.toLowerCase();
}
function parseLivestreamLink(rawUrl) {
  let url;
  try {
    url = new URL(rawUrl);
  } catch {
    throw new Error("Invalid URL format");
  }
  const host = url.hostname.toLowerCase();
  if (isHostMatch(host, "twitch.tv")) {
    const channel = extractTwitchChannel(url);
    if (!channel) throw new Error("Could not parse Twitch channel from link");
    return {
      platform: "twitch",
      streamKey: channel
    };
  }
  if (isHostMatch(host, "youtube.com") || host === "youtu.be") {
    const channelRef = extractYouTubeChannelRef(url);
    if (!channelRef) {
      throw new Error("Could not parse YouTube channel from link. Use a channel URL like /@handle or /channel/UC....");
    }
    return {
      platform: "youtube",
      streamKey: channelRef
    };
  }
  if (isHostMatch(host, "kick.com")) {
    const channel = extractKickChannel(url);
    if (!channel) throw new Error("Could not parse Kick channel from link");
    return {
      platform: "kick",
      streamKey: channel
    };
  }
  throw new Error("Unsupported platform. Only Twitch, YouTube, and Kick are currently supported.");
}
function parseStoredYouTubeKey(streamKey) {
  if (streamKey.startsWith("handle:")) {
    return { kind: "handle", value: streamKey.slice("handle:".length) };
  }
  if (streamKey.startsWith("channel:")) {
    return { kind: "channel", value: streamKey.slice("channel:".length) };
  }
  if (streamKey.startsWith("user:")) {
    return { kind: "user", value: streamKey.slice("user:".length) };
  }
  if (streamKey.startsWith("custom:")) {
    return { kind: "custom", value: streamKey.slice("custom:".length) };
  }
  return { kind: "video", value: streamKey };
}
async function fetchYouTubeChannelById(channelId, apiKey) {
  const channelUrl = new URL("https://www.googleapis.com/youtube/v3/channels");
  channelUrl.searchParams.set("part", "snippet,statistics");
  channelUrl.searchParams.set("id", channelId);
  channelUrl.searchParams.set("key", apiKey);
  const response = await fetch(channelUrl.toString(), { method: "GET" });
  if (!response.ok) return null;
  const data = await response.json();
  return data.items?.[0] || null;
}
async function resolveYouTubeChannel(streamKey, apiKey) {
  const parsed = parseStoredYouTubeKey(streamKey);
  if (parsed.kind === "channel") {
    const channel = await fetchYouTubeChannelById(parsed.value, apiKey);
    if (!channel?.id) return null;
    return channel;
  }
  if (parsed.kind === "handle") {
    const handle = parsed.value.startsWith("@") ? parsed.value : `@${parsed.value}`;
    const searchUrl = new URL("https://www.googleapis.com/youtube/v3/search");
    searchUrl.searchParams.set("part", "snippet");
    searchUrl.searchParams.set("type", "channel");
    searchUrl.searchParams.set("q", handle);
    searchUrl.searchParams.set("maxResults", "5");
    searchUrl.searchParams.set("key", apiKey);
    const response = await fetch(searchUrl.toString(), { method: "GET" });
    if (!response.ok) return null;
    const data = await response.json();
    const matched = data.items?.find((item) => {
      const customUrl = item.snippet?.customUrl?.toLowerCase();
      return customUrl === handle.toLowerCase();
    }) || data.items?.[0];
    const channelId = matched?.id?.channelId;
    if (!channelId) return null;
    return fetchYouTubeChannelById(channelId, apiKey);
  }
  if (parsed.kind === "user" || parsed.kind === "custom") {
    const searchUrl = new URL("https://www.googleapis.com/youtube/v3/search");
    searchUrl.searchParams.set("part", "snippet");
    searchUrl.searchParams.set("type", "channel");
    searchUrl.searchParams.set("q", parsed.value);
    searchUrl.searchParams.set("maxResults", "5");
    searchUrl.searchParams.set("key", apiKey);
    const response = await fetch(searchUrl.toString(), { method: "GET" });
    if (!response.ok) return null;
    const data = await response.json();
    const query = parsed.value.toLowerCase();
    const matched = data.items?.find((item) => {
      const title = item.snippet?.channelTitle?.toLowerCase();
      const customUrl = item.snippet?.customUrl?.replace(/^@/, "").toLowerCase();
      return title === query || customUrl === query;
    }) || data.items?.[0];
    const channelId = matched?.id?.channelId;
    if (!channelId) return null;
    return fetchYouTubeChannelById(channelId, apiKey);
  }
  return null;
}
async function getYouTubeSnapshot(videoId) {
  const apiKey = process.env.YOUTUBE_API_KEY;
  if (!apiKey) {
    return OFFLINE_SNAPSHOT;
  }
  const parsed = parseStoredYouTubeKey(videoId);
  if (parsed.kind !== "video") {
    const channel = await resolveYouTubeChannel(videoId, apiKey);
    if (!channel?.id) {
      return OFFLINE_SNAPSHOT;
    }
    const searchUrl = new URL("https://www.googleapis.com/youtube/v3/search");
    searchUrl.searchParams.set("part", "snippet");
    searchUrl.searchParams.set("channelId", channel.id);
    searchUrl.searchParams.set("eventType", "live");
    searchUrl.searchParams.set("type", "video");
    searchUrl.searchParams.set("maxResults", "1");
    searchUrl.searchParams.set("key", apiKey);
    const searchResponse = await fetch(searchUrl.toString(), {
      method: "GET"
    });
    let liveVideoId = null;
    if (searchResponse.ok) {
      const searchData = await searchResponse.json();
      liveVideoId = searchData.items?.[0]?.id?.videoId || null;
    }
    if (!liveVideoId) {
      return {
        status: "offline",
        viewerCount: null,
        followerCount: channel.statistics?.subscriberCount ? Number.parseInt(channel.statistics.subscriberCount, 10) : null,
        accountCreatedAt: channel.snippet?.publishedAt || null
      };
    }
    const liveSnapshot = await getYouTubeSnapshot(liveVideoId);
    return {
      ...liveSnapshot,
      followerCount: channel.statistics?.subscriberCount ? Number.parseInt(channel.statistics.subscriberCount, 10) : liveSnapshot.followerCount,
      accountCreatedAt: channel.snippet?.publishedAt || liveSnapshot.accountCreatedAt
    };
  }
  const apiUrl = new URL("https://www.googleapis.com/youtube/v3/videos");
  apiUrl.searchParams.set("part", "snippet,liveStreamingDetails");
  apiUrl.searchParams.set("id", parsed.value);
  apiUrl.searchParams.set("key", apiKey);
  const response = await fetch(apiUrl.toString(), {
    method: "GET"
  });
  if (!response.ok) {
    return OFFLINE_SNAPSHOT;
  }
  const data = await response.json();
  const item = data.items?.[0];
  if (!item) return OFFLINE_SNAPSHOT;
  const viewerCountRaw = item.liveStreamingDetails?.concurrentViewers;
  const viewerCount = viewerCountRaw ? Number.parseInt(viewerCountRaw, 10) : null;
  let followerCount = null;
  let accountCreatedAt = null;
  const channelId = item.snippet?.channelId;
  if (channelId) {
    const channelUrl = new URL("https://www.googleapis.com/youtube/v3/channels");
    channelUrl.searchParams.set("part", "snippet,statistics");
    channelUrl.searchParams.set("id", channelId);
    channelUrl.searchParams.set("key", apiKey);
    const channelResponse = await fetch(channelUrl.toString(), {
      method: "GET"
    });
    if (channelResponse.ok) {
      const channelData = await channelResponse.json();
      const channel = channelData.items?.[0];
      followerCount = channel?.statistics?.subscriberCount ? Number.parseInt(channel.statistics.subscriberCount, 10) : null;
      accountCreatedAt = channel?.snippet?.publishedAt || null;
    }
  }
  const started = !!item.liveStreamingDetails?.actualStartTime;
  const ended = !!item.liveStreamingDetails?.actualEndTime;
  const isLive = item.snippet?.liveBroadcastContent === "live" || started && !ended;
  return {
    status: isLive ? "live" : "offline",
    viewerCount,
    followerCount,
    accountCreatedAt
  };
}
async function getTwitchSnapshot(channelLogin) {
  const clientId = process.env.TWITCH_CLIENT_ID;
  const clientSecret = process.env.TWITCH_CLIENT_SECRET;
  if (!clientId || !clientSecret) {
    return OFFLINE_SNAPSHOT;
  }
  const tokenResponse = await fetch("https://id.twitch.tv/oauth2/token", {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded"
    },
    body: new URLSearchParams({
      client_id: clientId,
      client_secret: clientSecret,
      grant_type: "client_credentials"
    })
  });
  if (!tokenResponse.ok) {
    return OFFLINE_SNAPSHOT;
  }
  const tokenData = await tokenResponse.json();
  if (!tokenData.access_token) {
    return OFFLINE_SNAPSHOT;
  }
  const headers = {
    "Client-Id": clientId,
    Authorization: `Bearer ${tokenData.access_token}`
  };
  let userId = null;
  let accountCreatedAt = null;
  const userResponse = await fetch(`https://api.twitch.tv/helix/users?login=${encodeURIComponent(channelLogin)}`, {
    headers
  });
  if (userResponse.ok) {
    const userData = await userResponse.json();
    const user = userData.data?.[0];
    userId = user?.id || null;
    accountCreatedAt = user?.created_at || null;
  }
  const streamResponse = await fetch(`https://api.twitch.tv/helix/streams?user_login=${encodeURIComponent(channelLogin)}`, {
    headers
  });
  if (!streamResponse.ok) {
    return {
      ...OFFLINE_SNAPSHOT,
      accountCreatedAt
    };
  }
  const streamData = await streamResponse.json();
  const liveStream = streamData.data?.[0];
  const viewerCount = liveStream?.viewer_count ?? null;
  let followerCount = null;
  if (userId) {
    const followersResponse = await fetch(`https://api.twitch.tv/helix/channels/followers?broadcaster_id=${encodeURIComponent(userId)}`, {
      headers
    });
    if (followersResponse.ok) {
      const followersData = await followersResponse.json();
      followerCount = typeof followersData.total === "number" ? followersData.total : null;
    }
  }
  return {
    status: liveStream ? "live" : "offline",
    viewerCount,
    followerCount,
    accountCreatedAt
  };
}
async function getKickSnapshot(channelSlug) {
  const kickClientId = process.env.KICK_CLIENT_ID;
  const kickClientSecret = process.env.KICK_CLIENT_SECRET;
  if (kickClientId && kickClientSecret) {
    const officialSnapshot = await getKickSnapshotFromOfficialApi(channelSlug, kickClientId, kickClientSecret);
    if (officialSnapshot) {
      return officialSnapshot;
    }
  }
  const encodedSlug = encodeURIComponent(channelSlug);
  const endpoints = [
    `https://kick.com/api/v2/channels/${encodedSlug}`,
    `https://kick.com/api/v2/channels/${encodedSlug}/livestream`,
    `https://kick.com/api/v1/channels/${encodedSlug}`,
    `https://kick.com/api/v1/channels/${encodedSlug}/livestream`
  ];
  const parsedSnapshots = [];
  for (const endpoint of endpoints) {
    const response = await fetch(endpoint, {
      method: "GET",
      headers: {
        Accept: "application/json, text/plain, */*",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",
        Referer: "https://kick.com/",
        Origin: "https://kick.com"
      }
    });
    if (!response.ok) {
      continue;
    }
    const data = await response.json();
    const livestreamId = data.livestream?.id ?? data.data?.livestream?.id;
    const isLiveFlag = data.is_live ?? data.data?.is_live ?? data.livestream?.is_live ?? data.data?.livestream?.is_live;
    const viewerCount = data.livestream?.viewer_count ?? data.data?.livestream?.viewer_count ?? data.viewer_count ?? data.data?.viewer_count ?? null;
    const followerCount = data.followers_count ?? data.data?.followers_count ?? data.follower_count ?? data.data?.follower_count ?? null;
    const accountCreatedAt = data.user?.created_at ?? data.data?.user?.created_at ?? data.created_at ?? data.data?.created_at ?? null;
    parsedSnapshots.push({
      status: livestreamId || isLiveFlag === true || (viewerCount || 0) > 0 ? "live" : "offline",
      viewerCount,
      followerCount,
      accountCreatedAt
    });
  }
  if (parsedSnapshots.length > 0) {
    const liveSnapshot = parsedSnapshots.find((snapshot) => snapshot.status === "live");
    if (liveSnapshot) {
      return liveSnapshot;
    }
    const richestOffline = parsedSnapshots.reduce((best, current) => {
      const bestScore = (best.viewerCount ? 1 : 0) + (best.followerCount ? 1 : 0) + (best.accountCreatedAt ? 1 : 0);
      const currentScore = (current.viewerCount ? 1 : 0) + (current.followerCount ? 1 : 0) + (current.accountCreatedAt ? 1 : 0);
      return currentScore > bestScore ? current : best;
    }, parsedSnapshots[0]);
    return richestOffline;
  }
  const pageResponse = await fetch(`https://kick.com/${encodedSlug}`, {
    method: "GET",
    headers: {
      Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
      "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",
      Referer: "https://kick.com/"
    }
  });
  if (pageResponse.ok) {
    const html = await pageResponse.text();
    const isLive = /"is_live"\s*:\s*true/i.test(html);
    const viewerMatch = html.match(/"viewer_count"\s*:\s*(\d+)/i);
    const followerMatch = html.match(/"followers?_count"\s*:\s*(\d+)/i);
    const createdAtMatch = html.match(/"created_at"\s*:\s*"([^"]+)"/i);
    return {
      status: isLive ? "live" : "offline",
      viewerCount: viewerMatch ? Number.parseInt(viewerMatch[1], 10) : null,
      followerCount: followerMatch ? Number.parseInt(followerMatch[1], 10) : null,
      accountCreatedAt: createdAtMatch?.[1] || null
    };
  }
  return OFFLINE_SNAPSHOT;
}
async function getKickSnapshotFromOfficialApi(channelSlug, clientId, clientSecret) {
  const accessToken = await getKickAppAccessToken(clientId, clientSecret);
  if (!accessToken) {
    return null;
  }
  const channelsUrl = new URL("https://api.kick.com/public/v1/channels");
  channelsUrl.searchParams.append("slug", channelSlug);
  const response = await fetch(channelsUrl.toString(), {
    method: "GET",
    headers: {
      Authorization: `Bearer ${accessToken}`,
      "Client-Id": clientId,
      Accept: "application/json"
    }
  });
  if (!response.ok) {
    return null;
  }
  const data = await response.json();
  const channel = data.data?.[0];
  if (!channel) {
    return OFFLINE_SNAPSHOT;
  }
  const isLive = channel.stream?.is_live === true;
  const viewerCount = channel.stream?.viewer_count ?? null;
  const followerCount = channel.followers_count ?? channel.follower_count ?? null;
  const accountCreatedAt = channel.user?.created_at ?? channel.created_at ?? null;
  return {
    status: isLive || (viewerCount || 0) > 0 ? "live" : "offline",
    viewerCount,
    followerCount,
    accountCreatedAt
  };
}
async function getKickAppAccessToken(clientId, clientSecret) {
  const now = Date.now();
  if (kickTokenCache && now < kickTokenCache.expiresAt) {
    return kickTokenCache.accessToken;
  }
  const response = await fetch("https://id.kick.com/oauth/token", {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
      Accept: "application/json"
    },
    body: new URLSearchParams({
      grant_type: "client_credentials",
      client_id: clientId,
      client_secret: clientSecret
    })
  });
  if (!response.ok) {
    return null;
  }
  const data = await response.json();
  if (!data.access_token) {
    return null;
  }
  const expiresInMs = Math.max((data.expires_in || 3600) - 60, 60) * 1e3;
  kickTokenCache = {
    accessToken: data.access_token,
    expiresAt: now + expiresInMs
  };
  return data.access_token;
}
async function getLivestreamSnapshot(platform, streamKey) {
  try {
    if (platform === "youtube") {
      return await getYouTubeSnapshot(streamKey);
    }
    if (platform === "kick") {
      return await getKickSnapshot(streamKey);
    }
    return await getTwitchSnapshot(streamKey);
  } catch {
    return OFFLINE_SNAPSHOT;
  }
}
function normalizeUrl(value) {
  return value.trim().replace(/[),.;]+$/g, "");
}
function collectStringValues(input, depth = 0) {
  if (depth > 3 || input == null) return [];
  if (typeof input === "string") {
    const trimmed = input.trim();
    return trimmed ? [trimmed] : [];
  }
  if (Array.isArray(input)) {
    return input.flatMap((item) => collectStringValues(item, depth + 1));
  }
  if (typeof input === "object") {
    return Object.values(input).flatMap((value) => collectStringValues(value, depth + 1));
  }
  return [];
}
function extractUrls(input) {
  const values = collectStringValues(input);
  const urls = [];
  for (const value of values) {
    const matches = value.match(URL_REGEX);
    if (!matches) continue;
    for (const match of matches) {
      const normalized = normalizeUrl(match);
      if (normalized) urls.push(normalized);
    }
  }
  return urls;
}
function toKickUrl(value) {
  const username = String(value || "").trim().replace(/^@/, "");
  if (!username) return null;
  return `https://kick.com/${username}`;
}
function toTwitchUrl(value) {
  const username = String(value || "").trim().replace(/^@/, "");
  if (!username) return null;
  return `https://www.twitch.tv/${username}`;
}
function toYouTubeHandleUrl(value) {
  const username = String(value || "").trim().replace(/^@/, "");
  if (!username) return null;
  return `https://www.youtube.com/@${username}`;
}
function collectCandidateUrls(meta, profile) {
  const urls = /* @__PURE__ */ new Set();
  const kickFromUsername = toKickUrl(meta?.kick_username);
  if (kickFromUsername) urls.add(kickFromUsername);
  const twitchFromUsername = toTwitchUrl(meta?.twitch_username);
  if (twitchFromUsername) urls.add(twitchFromUsername);
  const selectedYouTubeChannel = String(meta?.selected_youtube_channel || "").trim();
  if (selectedYouTubeChannel) {
    if (selectedYouTubeChannel.startsWith("handle:")) {
      urls.add(`https://www.youtube.com/@${selectedYouTubeChannel.slice("handle:".length)}`);
    } else if (selectedYouTubeChannel.startsWith("channel:")) {
      urls.add(`https://www.youtube.com/channel/${selectedYouTubeChannel.slice("channel:".length)}`);
    } else if (selectedYouTubeChannel.startsWith("user:")) {
      urls.add(`https://www.youtube.com/user/${selectedYouTubeChannel.slice("user:".length)}`);
    } else if (selectedYouTubeChannel.startsWith("custom:")) {
      urls.add(`https://www.youtube.com/c/${selectedYouTubeChannel.slice("custom:".length)}`);
    } else {
      for (const url of extractUrls(selectedYouTubeChannel)) {
        urls.add(url);
      }
    }
  }
  const youtubeFromHandle = toYouTubeHandleUrl(meta?.youtube_handle);
  if (youtubeFromHandle) urls.add(youtubeFromHandle);
  return Array.from(urls);
}
function parseAutoCandidates(urls) {
  const dedupe = /* @__PURE__ */ new Set();
  const candidates = [];
  for (const url of urls) {
    try {
      const parsed = parseLivestreamLink(url);
      const key = `${parsed.platform}:${parsed.streamKey}`;
      if (dedupe.has(key)) continue;
      dedupe.add(key);
      candidates.push({
        url,
        platform: parsed.platform,
        stream_key: parsed.streamKey
      });
    } catch {
    }
  }
  return candidates;
}
function pickMostEngaged(candidates) {
  return [...candidates].sort((a, b) => {
    const aViewers = a.viewer_count || 0;
    const bViewers = b.viewer_count || 0;
    if (aViewers !== bViewers) return bViewers - aViewers;
    const aLive = a.status === "live" ? 1 : 0;
    const bLive = b.status === "live" ? 1 : 0;
    if (aLive !== bLive) return bLive - aLive;
    return new Date(b.updated_at).getTime() - new Date(a.updated_at).getTime();
  })[0] || null;
}
function normalizePlatforms(platforms) {
  const allow = /* @__PURE__ */ new Set(["x", "threads", "instagram", "kick", "twitch"]);
  return Array.from(new Set(platforms.map((p) => p.trim().toLowerCase()).filter((p) => allow.has(p))));
}
function buildAutoCaption(input) {
  const platform = input.streamPlatform ? input.streamPlatform.toUpperCase() : "LIVE";
  const key = input.streamKey ? ` @${input.streamKey}` : "";
  const timestamp = (/* @__PURE__ */ new Date()).toLocaleString("en-US", { hour: "numeric", minute: "2-digit" });
  return `Fresh ${input.clipWindowMinutes || 5}m clip from ${platform}${key}. Highlight dropped at ${timestamp}. #WAGESociety #Creator`;
}
async function createAutoclipperJob(input) {
  const admin = getSupabaseAdminClient();
  const safePlatforms = normalizePlatforms(input.platforms);
  const clipWindowMinutes = Math.max(1, Math.min(15, input.clipWindowMinutes || 5));
  const caption = input.autoCaption ? buildAutoCaption({ ...input, clipWindowMinutes }) : "";
  const clipMetadata = {
    kind: "autoclip",
    status: "queued",
    source: input.source,
    requestedBy: input.requestedBy,
    command: input.commandText,
    clipWindowMinutes,
    autoPost: input.autoPost,
    autoCaption: input.autoCaption,
    platforms: safePlatforms,
    streamPlatform: input.streamPlatform || null,
    streamKey: input.streamKey || null,
    caption,
    clipRequestedAt: (/* @__PURE__ */ new Date()).toISOString(),
    clipUrl: null
  };
  const { data: clipJob, error: clipError } = await admin.from("org_dashboard_tool_entries").insert({
    tool_key: "promotion-hub",
    title: `Autoclip requested by ${input.requestedBy}`,
    details: caption || `Processing ${clipWindowMinutes} minute clip from chat command ${input.commandText}`,
    status: "active",
    event_date: (/* @__PURE__ */ new Date()).toISOString(),
    metadata: clipMetadata,
    created_by: input.requestedBy,
    updated_by: input.requestedBy
  }).select("id, metadata, created_at, updated_at").single();
  if (clipError) throw new Error(clipError.message);
  let queuedPostId = null;
  if (input.autoPost && safePlatforms.length > 0) {
    const { data: queuedPost, error: postError } = await admin.from("org_dashboard_tool_entries").insert({
      tool_key: "promotion-hub",
      title: (caption || `New clip from ${input.streamPlatform || "live stream"}`).slice(0, 160),
      details: caption,
      status: "planned",
      event_date: (/* @__PURE__ */ new Date()).toISOString(),
      metadata: {
        kind: "autoclip-social",
        clipJobId: clipJob.id,
        autoCaption: input.autoCaption,
        autoPost: input.autoPost,
        platforms: safePlatforms
      },
      created_by: input.requestedBy,
      updated_by: input.requestedBy
    }).select("id").single();
    if (!postError && queuedPost?.id) {
      queuedPostId = queuedPost.id;
      await admin.from("org_dashboard_tool_entries").update({
        metadata: {
          ...clipJob.metadata || {},
          queuedPostId
        },
        updated_by: input.requestedBy,
        updated_at: (/* @__PURE__ */ new Date()).toISOString()
      }).eq("id", clipJob.id);
    }
  }
  return {
    clipJobId: clipJob.id,
    queuedPostId,
    caption,
    platforms: safePlatforms
  };
}
function hasWebhookSecret(request) {
  const secret = process.env.AUTOCLIPPER_WEBHOOK_SECRET;
  if (!secret) return false;
  const incoming = request.headers.get("x-autoclipper-secret") || "";
  const incomingBuffer = Buffer.from(incoming);
  const secretBuffer = Buffer.from(secret);
  if (incomingBuffer.length !== secretBuffer.length) return false;
  try {
    return timingSafeEqual(incomingBuffer, secretBuffer);
  } catch {
    return false;
  }
}
async function fetchAutoclipRows(limit = 100) {
  const admin = getSupabaseAdminClient();
  const { data, error } = await admin.from("org_dashboard_tool_entries").select("id, title, details, status, metadata, created_by, created_at, updated_at, event_date").eq("tool_key", "promotion-hub").contains("metadata", { kind: "autoclip" }).order("created_at", { ascending: false }).limit(limit);
  if (error) throw new Error(error.message);
  return data || [];
}
function mapRowsToJobs(rows) {
  return rows.map((row) => {
    const metadata = row.metadata || {};
    return {
      id: row.id,
      status: metadata.status || "queued",
      command: String(metadata.command || "!clip"),
      source: String(metadata.source || "dashboard"),
      requestedBy: String(metadata.requestedBy || row.created_by || "unknown"),
      clipWindowMinutes: Number(metadata.clipWindowMinutes || 5),
      streamPlatform: metadata.streamPlatform || null,
      streamKey: metadata.streamKey || null,
      autoPost: Boolean(metadata.autoPost),
      autoCaption: Boolean(metadata.autoCaption),
      platforms: Array.isArray(metadata.platforms) ? metadata.platforms : [],
      caption: String(metadata.caption || ""),
      clipUrl: metadata.clipUrl || null,
      queuedPostId: metadata.queuedPostId || null,
      createdAt: row.created_at,
      updatedAt: row.updated_at
    };
  });
}
async function updateAutoclipJobStatus(input) {
  const admin = getSupabaseAdminClient();
  const { data: existing, error: fetchError } = await admin.from("org_dashboard_tool_entries").select("id, metadata").eq("id", input.id).eq("tool_key", "promotion-hub").contains("metadata", { kind: "autoclip" }).maybeSingle();
  if (fetchError) throw new Error(fetchError.message);
  if (!existing) throw new Error("Clip job not found.");
  const metadata = existing.metadata || {};
  const nextMetadata = {
    ...metadata,
    status: input.status,
    clipUrl: input.clipUrl || metadata.clipUrl || null
  };
  if (input.error) nextMetadata.error = input.error;
  if (input.note) nextMetadata.discordNote = input.note;
  const { error: updateError } = await admin.from("org_dashboard_tool_entries").update({
    status: input.status === "posted" ? "done" : input.status === "failed" ? "blocked" : "active",
    metadata: nextMetadata,
    updated_by: input.updatedBy,
    updated_at: (/* @__PURE__ */ new Date()).toISOString()
  }).eq("id", input.id);
  if (updateError) throw new Error(updateError.message);
}
function getBearerToken(request) {
  const authHeader = request.headers.get("authorization") || request.headers.get("Authorization") || "";
  if (!authHeader.toLowerCase().startsWith("bearer ")) return void 0;
  const token = authHeader.slice(7).trim();
  return token || void 0;
}
function getAdminOrRequestClient(request) {
  if (hasSupabaseAdminConfig()) {
    return getSupabaseAdminClient();
  }
  const token = getBearerToken(request);
  if (token) {
    return getSupabaseServerClientForToken(token);
  }
  return getSupabaseServerPublicClient();
}
function toStringOrNull(value) {
  if (typeof value !== "string") return null;
  const trimmed = value.trim();
  return trimmed || null;
}
function getDisplayName(userMetadata) {
  return toStringOrNull(userMetadata?.full_name) || toStringOrNull(userMetadata?.name) || toStringOrNull(userMetadata?.username) || toStringOrNull(userMetadata?.preferred_username);
}
async function findAuthUserByEmail(email) {
  if (!hasSupabaseAdminConfig()) return null;
  const admin = getSupabaseAdminClient();
  let page = 1;
  const perPage = 1e3;
  while (page <= 10) {
    const { data, error } = await admin.auth.admin.listUsers({ page, perPage });
    if (error) throw new Error(error.message);
    const users = data?.users || [];
    if (!users.length) break;
    const match = users.find((user) => String(user.email || "").trim().toLowerCase() === email);
    if (match?.id) return match;
    if (users.length < perPage) break;
    page += 1;
  }
  return null;
}
function getAdminOrPublicClient$2() {
  return hasSupabaseAdminConfig() ? getSupabaseAdminClient() : getSupabaseServerPublicClient();
}
function getAdminOrPublicClient$1() {
  return hasSupabaseAdminConfig() ? getSupabaseAdminClient() : getSupabaseServerPublicClient();
}
function getAdminOrPublicClient() {
  return hasSupabaseAdminConfig() ? getSupabaseAdminClient() : getSupabaseServerPublicClient();
}
var LOCAL_ROOT_EMAIL, LOCAL_ROOT_SESSION_KEY, ORG_ROLES, ORG_ROLE_LABELS, ORG_ROLE_RANK, VIEW_AS_ROLE_STORAGE_KEY, supabaseBrowserClient, navLinks, SITE_URL, SITE_NAME, SITE_DESCRIPTION, OG_IMAGE, Route$L, $$splitComponentImporter$g, Route$K, $$splitComponentImporter$f, Route$J, $$splitComponentImporter$e, Route$I, Route$H, $$splitComponentImporter$d, Route$G, $$splitComponentImporter$c, Route$F, $$splitComponentImporter$b, Route$E, $$splitComponentImporter$a, Route$D, $$splitComponentImporter$9, Route$C, $$splitComponentImporter$8, Route$B, $$splitComponentImporter$7, Route$A, $$splitComponentImporter$6, Route$z, $$splitComponentImporter$5, Route$y, $$splitComponentImporter$4, Route$x, $$splitComponentImporter$3, Route$w, supabaseUrl$1, serverKey, adminClient, Route$v, supabaseUrl, publishableKey, serverPublicClient, Route$u, Route$t, Route$s, LOCAL_SUPERADMIN_EMAIL, OWNER_SUPERADMIN_EMAILS, SUPERADMIN_FALLBACK_PERMISSIONS, BUCKET$1, FOLDER, ALLOWED_MIME_TYPES, ALLOWED_EXTENSIONS$1, MAX_SIZE$1, Route$r, Route$q, WRITE_ROLES$1, ALLOWED_IMAGES, ALLOWED_VIDEOS, Route$p, WRITE_ROLES, NewsPostSchema, Route$o, SUBSCRIBE_RATE_LIMIT_WINDOW_MS, SUBSCRIBE_RATE_LIMIT_MAX_REQUESTS, subscribeRequestLog, subscribeSchema, Route$n, trackViewSchema, adminViewsQuerySchema, Route$m, Route$l, LOCALHOST_HOSTS, Route$k, Route$j, createSchema$1, updateSchema$3, deleteSchema, Route$i, USERNAME_REGEX$1, Route$h, $$splitComponentImporter$2, Route$g, $$splitComponentImporter$1, Route$f, toolSchema$1, $$splitComponentImporter, Route$e, toolSchema, statusSchema, baseEntrySchema, createEntrySchema, updateEntrySchema, deleteEntrySchema, requiredPermissionByTool, Route$d, BUCKET, ALLOWED_EXTENSIONS, MAX_SIZE, Route$c, createSubmissionSchema, adminReviewSchema, Route$b, createEarningSchema, updatePaidSchema, Route$a, USERNAME_REGEX2, updateSchema$2, BUILTIN_OAUTH_PROVIDER_META, Route$9, Route$8, kickTokenCache, OFFLINE_SNAPSHOT, addStreamSchema, removeStreamSchema, URL_REGEX, Route$7, createSchema, updateSchema$1, chatSchema, AUTOCLIPPER_DISABLED_MESSAGE, Route$6, applySchema, Route$5, updateSchema, Route$4, setRoleSchema, setSubscriptionSchema, Route$3, updatePermissionSchema, Route$2, planBaseSchema, createPlanSchema, updatePlanSchema, deletePlanSchema, Route$1, createMerchSchema, updateMerchSchema, deleteMerchSchema, Route, SignupRoute, OnboardingRoute, NewsRoute, MerchStudioRoute, MerchRoute, LoginRoute, LiveRoute, FaqRoute, DownloadRoute, DirectoryRoute, DashboardRoute, AppealsRoute, AdminRoute, UsernameRoute, IndexRoute, ApiStripeWebhookRoute, ApiShopRoute, ApiPublicProfileRoute, ApiPublicDirectoryRoute, ApiProfilePhotoUploadRoute, ApiProfileRoute, ApiNewsUploadRoute, ApiNewsRoute, ApiMarketingProofRoute, ApiKnowledgeVaultRoute, ApiKickLoginRoute, ApiKickCallbackRoute, ApiCreatePaymentIntentRoute, ApiCollabRoute, ApiCheckUsernameRoute, AdminUsersRoute, AdminShopRoute, DashboardToolsToolRoute, ApiToolsToolRoute, ApiMerchStudioUploadRoute, ApiMerchStudioSubmissionsRoute, ApiMerchStudioEarningsRoute, ApiMeProfileRoute, ApiMeAccessRoute, ApiLiveStreamsRoute, ApiLiveClipsRoute, ApiCollabApplyRoute, ApiCollabApplicantsRoute, ApiAdminRolesRoute, ApiAdminPermissionsRoute, ApiAdminShopPlansRoute, ApiAdminShopMerchRoute, AdminRouteChildren, AdminRouteWithChildren, DashboardRouteChildren, DashboardRouteWithChildren, ApiCollabRouteChildren, ApiCollabRouteWithChildren, rootRouteChildren, routeTree, getRouter, router;
var init_router_BDBFyAOM = __esm({
  "dist/server/assets/router-BDBFyAOM.js"() {
    "use strict";
    LOCAL_ROOT_EMAIL = "root-superadmin@localhost";
    LOCAL_ROOT_SESSION_KEY = "wage.localRootSession";
    ORG_ROLES = [
      "superadmin",
      "admin",
      "manager",
      "staff",
      "moderator",
      "helper",
      "user",
      "banned"
    ];
    ORG_ROLE_LABELS = {
      superadmin: "Superadmin",
      admin: "Admin",
      manager: "Manager",
      staff: "Staff",
      moderator: "Moderator",
      helper: "Helper",
      user: "User",
      banned: "Banned"
    };
    ORG_ROLE_RANK = {
      superadmin: 0,
      admin: 1,
      manager: 2,
      staff: 3,
      moderator: 4,
      helper: 5,
      user: 6,
      banned: 7
    };
    VIEW_AS_ROLE_STORAGE_KEY = "wage_society_view_as_role";
    supabaseBrowserClient = null;
    navLinks = [
      { label: "Shop", to: "/merch" },
      { label: "Livestream", to: "/live" },
      { label: "Directory", to: "/directory" },
      { label: "Blog", to: "/news" }
    ];
    SITE_URL = "https://playful-torte-0c9af1.netlify.app";
    SITE_NAME = "W.A.G.E. Society";
    SITE_DESCRIPTION = "A modern organization for content creators, online marketers, and entrepreneurs. Join W.A.G.E. Society for strategy, systems, and community accountability.";
    OG_IMAGE = `${SITE_URL}/og-image.svg`;
    Route$L = createRootRoute({
      head: () => ({
        meta: [
          { charSet: "utf-8" },
          { name: "viewport", content: "width=device-width, initial-scale=1" },
          { title: SITE_NAME },
          { name: "description", content: SITE_DESCRIPTION },
          { name: "robots", content: "index, follow" },
          { name: "theme-color", content: "#fb923c" },
          // Open Graph
          { property: "og:type", content: "website" },
          { property: "og:site_name", content: SITE_NAME },
          { property: "og:title", content: SITE_NAME },
          { property: "og:description", content: SITE_DESCRIPTION },
          { property: "og:image", content: OG_IMAGE },
          { property: "og:image:width", content: "1200" },
          { property: "og:image:height", content: "630" },
          { property: "og:image:alt", content: "W.A.G.E. Society \u2014 Creator Growth Organization" },
          { property: "og:url", content: SITE_URL },
          // Twitter / X
          { name: "twitter:card", content: "summary_large_image" },
          { name: "twitter:title", content: SITE_NAME },
          { name: "twitter:description", content: SITE_DESCRIPTION },
          { name: "twitter:image", content: OG_IMAGE },
          { name: "twitter:image:alt", content: "W.A.G.E. Society \u2014 Creator Growth Organization" }
        ],
        links: [
          { rel: "icon", href: "/favicon.ico", sizes: "48x48" },
          { rel: "icon", href: "/favicon.svg", type: "image/svg+xml", sizes: "any" },
          { rel: "apple-touch-icon", href: "/favicon.svg" },
          { rel: "manifest", href: "/site.webmanifest" },
          { rel: "canonical", href: SITE_URL }
        ]
      }),
      shellComponent: RootDocument
    });
    $$splitComponentImporter$g = () => Promise.resolve().then(() => (init_signup_VQo6mkN6(), signup_VQo6mkN6_exports));
    Route$K = createFileRoute("/signup")({
      head: () => ({
        meta: [{
          title: "Sign Up \u2014 W.A.G.E. Society"
        }, {
          name: "description",
          content: "Create your W.A.G.E. Society membership account."
        }, {
          name: "robots",
          content: "noindex, nofollow"
        }]
      }),
      component: lazyRouteComponent($$splitComponentImporter$g, "component")
    });
    $$splitComponentImporter$f = () => Promise.resolve().then(() => (init_onboarding_C_VsswxE(), onboarding_C_VsswxE_exports));
    Route$J = createFileRoute("/onboarding")({
      beforeLoad: async () => {
        await requireAuthenticatedRoute("/login", {
          skipOnboardingCheck: true
        });
      },
      head: () => ({
        meta: [{
          title: "Onboarding \u2014 W.A.G.E. Society"
        }, {
          name: "description",
          content: "Set up your account and choose whether to upgrade beyond the free tier."
        }, {
          name: "robots",
          content: "noindex, nofollow"
        }]
      }),
      component: lazyRouteComponent($$splitComponentImporter$f, "component")
    });
    $$splitComponentImporter$e = () => Promise.resolve().then(() => (init_news_LsgI8TbW(), news_LsgI8TbW_exports));
    Route$I = createFileRoute("/news")({
      component: lazyRouteComponent($$splitComponentImporter$e, "component"),
      head: () => ({
        meta: [{
          title: "News \u2014 W.A.G.E. Society"
        }]
      })
    });
    Route$H = createFileRoute("/merch-studio")({
      beforeLoad: async () => {
        await requireAuthenticatedRoute("/login");
      },
      head: () => ({
        meta: [
          { title: "Merch Studio \u2014 W.A.G.E. Society" },
          {
            name: "description",
            content: "Submit merch concepts, track approvals, and monitor creator payouts in the W.A.G.E. Society Merch Studio."
          },
          { name: "robots", content: "noindex, nofollow" }
        ]
      }),
      component: MerchStudioPage
    });
    $$splitComponentImporter$d = () => Promise.resolve().then(() => (init_merch_CrgHgdMh(), merch_CrgHgdMh_exports));
    Route$G = createFileRoute("/merch")({
      head: () => ({
        meta: [{
          title: "Merch \u2014 W.A.G.E. Society"
        }, {
          name: "description",
          content: "Official W.A.G.E. Society merch for creators, marketers, and entrepreneurs building in public."
        }]
      }),
      component: lazyRouteComponent($$splitComponentImporter$d, "component")
    });
    $$splitComponentImporter$c = () => Promise.resolve().then(() => (init_login_DBOozA1Y(), login_DBOozA1Y_exports));
    Route$F = createFileRoute("/login")({
      head: () => ({
        meta: [{
          title: "Login \u2014 W.A.G.E. Society"
        }, {
          name: "description",
          content: "Log in to your W.A.G.E. Society account."
        }, {
          name: "robots",
          content: "noindex, nofollow"
        }]
      }),
      component: lazyRouteComponent($$splitComponentImporter$c, "component")
    });
    $$splitComponentImporter$b = () => Promise.resolve().then(() => (init_live_DqGiignv(), live_DqGiignv_exports));
    Route$E = createFileRoute("/live")({
      head: () => ({
        meta: [{
          title: "Live Streams \u2014 W.A.G.E. Society"
        }, {
          name: "description",
          content: "View all organization livestreams in one list with live/offline status and quick open links."
        }]
      }),
      component: lazyRouteComponent($$splitComponentImporter$b, "component")
    });
    $$splitComponentImporter$a = () => Promise.resolve().then(() => (init_faq_Bcw04J07(), faq_Bcw04J07_exports));
    Route$D = createFileRoute("/faq")({
      head: () => ({
        meta: [{
          title: "Organization FAQ \u2014 W.A.G.E. Society"
        }, {
          name: "description",
          content: "Answers about W.A.G.E. Society membership tracks, creator resources, marketing systems, and entrepreneur-focused community access."
        }, {
          property: "og:title",
          content: "Organization FAQ \u2014 W.A.G.E. Society"
        }, {
          property: "og:description",
          content: "Everything you need to know about joining W.A.G.E. Society as a creator, marketer, or entrepreneur."
        }, {
          property: "og:url",
          content: "https://playful-torte-0c9af1.netlify.app/faq"
        }],
        links: [{
          rel: "canonical",
          href: "https://playful-torte-0c9af1.netlify.app/faq"
        }]
      }),
      component: lazyRouteComponent($$splitComponentImporter$a, "component")
    });
    $$splitComponentImporter$9 = () => Promise.resolve().then(() => (init_download_CCZ7f8Cx(), download_CCZ7f8Cx_exports));
    Route$C = createFileRoute("/download")({
      head: () => ({
        meta: [{
          title: "Download the App \u2014 W.A.G.E. Society"
        }, {
          name: "description",
          content: "Download the W.A.G.E. Society Android APK, and install on iPhone/iPad through Safari Add to Home Screen."
        }, {
          property: "og:title",
          content: "Download the App \u2014 W.A.G.E. Society"
        }, {
          property: "og:description",
          content: "Download the W.A.G.E. Society Android APK, and install on iPhone/iPad through Safari Add to Home Screen."
        }, {
          property: "og:url",
          content: "https://wagesociety.com/download"
        }],
        links: [{
          rel: "canonical",
          href: "https://wagesociety.com/download"
        }]
      }),
      component: lazyRouteComponent($$splitComponentImporter$9, "component")
    });
    $$splitComponentImporter$8 = () => Promise.resolve().then(() => (init_directory_j20xSbNp(), directory_j20xSbNp_exports));
    Route$B = createFileRoute("/directory")({
      head: () => ({
        meta: [{
          title: "Creator Directory \u2014 W.A.G.E. Society"
        }, {
          name: "description",
          content: "Browse all signed-up creators and visit their public W.A.G.E. Society profiles."
        }]
      }),
      component: lazyRouteComponent($$splitComponentImporter$8, "component")
    });
    $$splitComponentImporter$7 = () => Promise.resolve().then(() => (init_dashboard_BD7PNkS0(), dashboard_BD7PNkS0_exports));
    Route$A = createFileRoute("/dashboard")({
      beforeLoad: async () => {
        await requireAuthenticatedRoute("/login");
      },
      head: () => ({
        meta: [{
          title: "Organization Dashboard \u2014 W.A.G.E. Society"
        }, {
          name: "description",
          content: "Your W.A.G.E. Society organization dashboard for content creation, online marketing, and entrepreneurship execution."
        }, {
          name: "robots",
          content: "noindex, nofollow"
        }]
      }),
      component: lazyRouteComponent($$splitComponentImporter$7, "component")
    });
    $$splitComponentImporter$6 = () => Promise.resolve().then(() => (init_appeals_BbY3GHSm(), appeals_BbY3GHSm_exports));
    Route$z = createFileRoute("/appeals")({
      head: () => ({
        meta: [{
          title: "Appeals \u2014 W.A.G.E. Society"
        }, {
          name: "description",
          content: "Submit an access appeal for a restricted W.A.G.E. Society account."
        }, {
          name: "robots",
          content: "noindex, nofollow"
        }]
      }),
      component: lazyRouteComponent($$splitComponentImporter$6, "component")
    });
    $$splitComponentImporter$5 = () => Promise.resolve().then(() => (init_admin_DakHXV1g(), admin_DakHXV1g_exports));
    Route$y = createFileRoute("/admin")({
      beforeLoad: async () => {
        await requireAuthenticatedRoute();
      },
      head: () => ({
        meta: [{
          title: "Admin Hub \u2014 W.A.G.E. Society"
        }, {
          name: "description",
          content: "Central admin hub for users, shop, streams, and website feature management."
        }, {
          name: "robots",
          content: "noindex, nofollow"
        }]
      }),
      component: lazyRouteComponent($$splitComponentImporter$5, "component")
    });
    $$splitComponentImporter$4 = () => Promise.resolve().then(() => (init_username_Bqi7lS2z(), username_Bqi7lS2z_exports));
    Route$x = createFileRoute("/$username")({
      head: () => ({
        meta: [{
          title: "Creator Profile \u2014 W.A.G.E. Society"
        }, {
          name: "description",
          content: "Public creator profile on W.A.G.E. Society with connected accounts, bio, and creator details."
        }]
      }),
      component: lazyRouteComponent($$splitComponentImporter$4, "component")
    });
    $$splitComponentImporter$3 = () => Promise.resolve().then(() => (init_index_Ck_N9V5O(), index_Ck_N9V5O_exports));
    Route$w = createFileRoute("/")({
      head: () => ({
        meta: [{
          title: "W.A.G.E. Society \u2014 Creator Growth Organization"
        }, {
          name: "description",
          content: "Join W.A.G.E. Society, an organization for content creators, online marketers, and entrepreneurs building modern digital businesses together."
        }, {
          property: "og:title",
          content: "W.A.G.E. Society \u2014 Creator Growth Organization"
        }, {
          property: "og:description",
          content: "An organization for content creators, online marketers, and entrepreneurs who want tools, strategy, and community to grow."
        }, {
          property: "og:url",
          content: "https://playful-torte-0c9af1.netlify.app/"
        }],
        links: [{
          rel: "canonical",
          href: "https://playful-torte-0c9af1.netlify.app/"
        }]
      }),
      component: lazyRouteComponent($$splitComponentImporter$3, "component")
    });
    supabaseUrl$1 = process.env.SUPABASE_URL || process.env.VITE_SUPABASE_URL || process.env.NEXT_PUBLIC_SUPABASE_URL;
    serverKey = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.SUPABASE_SERVICE_KEY || process.env.SUPABASE_SECRET_KEY || process.env.SUPABASE_SERVICE_ROLE;
    adminClient = null;
    Route$v = createFileRoute("/api/stripe-webhook")({
      server: {
        handlers: {
          POST: async ({ request }) => {
            if (!getStripeSecretKey$1()) {
              return Response.json(
                {
                  error: "Billing webhook is not configured. Missing STRIPE_SECRET_KEY in server environment."
                },
                { status: 503 }
              );
            }
            const webhookSecret = getStripeWebhookSecret();
            if (!webhookSecret) {
              return Response.json(
                {
                  error: "Webhook signing secret not configured. Set STRIPE_WEBHOOK_SECRET (or STRIPE_WEBHOOK_SIGNING_SECRET)."
                },
                { status: 503 }
              );
            }
            const stripe = getStripe$1();
            let event;
            try {
              const payload = await request.text();
              const sig = request.headers.get("stripe-signature") || "";
              if (!sig) {
                return Response.json({ error: "Missing stripe-signature header." }, { status: 400 });
              }
              event = await stripe.webhooks.constructEventAsync(payload, sig, webhookSecret);
            } catch (err) {
              const msg = err instanceof Error ? err.message : "Invalid webhook payload.";
              return Response.json({ error: msg }, { status: 400 });
            }
            try {
              if (event.type === "checkout.session.completed") {
                const session = event.data.object;
                const customerEmail = session.metadata?.customerEmail || session.customer_details?.email || void 0;
                const planSlug = session.metadata?.membership_plan || void 0;
                if (customerEmail) {
                  const normalizedEmail = customerEmail.toLowerCase();
                  const admin = getSupabaseAdminClient();
                  await admin.rpc("ensure_org_member_role", {
                    p_email: normalizedEmail
                  });
                  await updateMembershipMetadataByEmail(normalizedEmail, {
                    membership_plan: planSlug || "free",
                    stripe_customer_id: typeof session.customer === "string" ? session.customer : void 0,
                    stripe_subscription_id: typeof session.subscription === "string" ? session.subscription : void 0
                  });
                }
              }
              if (event.type === "customer.subscription.updated" || event.type === "customer.subscription.created") {
                const subscription = event.data.object;
                const customerId = typeof subscription.customer === "string" ? subscription.customer : "";
                if (customerId) {
                  const customer = await stripe.customers.retrieve(customerId);
                  const customerEmail = typeof customer !== "string" && !customer.deleted ? customer.email?.toLowerCase() : void 0;
                  if (customerEmail) {
                    const planSlug = extractPlanSlugFromSubscription(subscription) || "free";
                    const admin = getSupabaseAdminClient();
                    await admin.rpc("ensure_org_member_role", {
                      p_email: customerEmail
                    });
                    await updateMembershipMetadataByEmail(customerEmail, {
                      membership_plan: planSlug,
                      stripe_customer_id: customerId,
                      stripe_subscription_id: subscription.id
                    });
                  }
                }
              }
              if (event.type === "customer.subscription.deleted") {
                const subscription = event.data.object;
                const customerId = typeof subscription.customer === "string" ? subscription.customer : "";
                if (customerId) {
                  const customer = await stripe.customers.retrieve(customerId);
                  const customerEmail = typeof customer !== "string" && !customer.deleted ? customer.email?.toLowerCase() : void 0;
                  if (customerEmail) {
                    await updateMembershipMetadataByEmail(customerEmail, {
                      membership_plan: "free",
                      stripe_customer_id: customerId,
                      stripe_subscription_id: void 0
                    });
                  }
                }
              }
            } catch {
              console.error("[stripe-webhook] fulfillment error", event.id);
            }
            return Response.json({ received: true });
          }
        }
      }
    });
    supabaseUrl = process.env.SUPABASE_URL || process.env.VITE_SUPABASE_URL || process.env.NEXT_PUBLIC_SUPABASE_URL;
    publishableKey = process.env.SUPABASE_PUBLISHABLE_KEY || process.env.SUPABASE_ANON_KEY || process.env.VITE_SUPABASE_PUBLISHABLE_KEY || process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
    serverPublicClient = null;
    Route$u = createFileRoute("/api/shop")({
      server: {
        handlers: {
          GET: async () => {
            try {
              const db = hasSupabaseAdminConfig() ? getSupabaseAdminClient() : getSupabaseServerPublicClient();
              const [{ data: merchData, error: merchError }, { data: plansData, error: plansError }] = await Promise.all([
                db.from("org_shop_merch_items").select("id, name, price, description, sort_order, is_active, created_at, updated_at").eq("is_active", true).order("sort_order", { ascending: true }).order("created_at", { ascending: true }),
                db.from("org_shop_membership_plans").select("id, slug, name, display_price, price_cents, description, features, sort_order, is_active, created_at, updated_at").eq("is_active", true).order("sort_order", { ascending: true }).order("created_at", { ascending: true })
              ]);
              if (merchError) return Response.json({ error: merchError.message }, { status: 500 });
              if (plansError) return Response.json({ error: plansError.message }, { status: 500 });
              return Response.json({
                merchItems: merchData || [],
                membershipPlans: plansData || []
              });
            } catch (error) {
              return Response.json(
                { error: error instanceof Error ? error.message : "Unexpected server error" },
                { status: 500 }
              );
            }
          }
        }
      }
    });
    Route$t = createFileRoute("/api/public-profile")({
      server: {
        handlers: {
          GET: async ({ request }) => {
            try {
              const url = new URL(request.url);
              const usernameParam = url.searchParams.get("username") || "";
              const normalizedRequestedUsername = normalizeUsername$1(usernameParam);
              if (!normalizedRequestedUsername) {
                return Response.json({ error: "username is required." }, { status: 400 });
              }
              const client = hasSupabaseAdminConfig() ? getSupabaseAdminClient() : getSupabaseServerPublicClient();
              const users = await listAuthIndexedUsers(client);
              if (users.length === 0) {
                const { data: profiles, error: profilesError } = await client.from("org_member_profiles").select("email, display_name, avatar_url, bio, skills, updated_at").limit(5e3);
                if (profilesError) {
                  return Response.json({ error: profilesError.message }, { status: 500 });
                }
                const match = (Array.isArray(profiles) ? profiles : []).find((row) => {
                  const email2 = String(row.email || "").toLowerCase().trim();
                  const emailUsername2 = email2.split("@")[0] || "";
                  const display = String(row.display_name || "").trim();
                  const candidate = normalizeUsername$1(display || emailUsername2);
                  return candidate === normalizedRequestedUsername;
                });
                if (!match) {
                  return Response.json({ error: "Profile not found." }, { status: 404 });
                }
                const email = String(match.email || "").toLowerCase().trim();
                const emailUsername = email.split("@")[0] || normalizedRequestedUsername;
                return Response.json({
                  profile: {
                    username: normalizeUsername$1(String(match.display_name || "").trim() || emailUsername),
                    displayName: String(match.display_name || "").trim() || emailUsername,
                    avatarUrl: match.avatar_url || null,
                    bio: match.bio || null,
                    skills: Array.isArray(match.skills) ? match.skills : [],
                    connectedAccounts: [],
                    updatedAt: match.updated_at || null
                  }
                });
              }
              const usernameMap = assignDeterministicUsernames(users);
              const userByUsername = /* @__PURE__ */ new Map();
              for (const user of users) {
                const username2 = usernameMap.get(String(user.id || ""));
                if (!username2) continue;
                userByUsername.set(normalizeUsername$1(username2), user);
              }
              const authUser = userByUsername.get(normalizedRequestedUsername);
              if (!authUser?.id || !authUser.email) {
                return Response.json({ error: "Profile not found." }, { status: 404 });
              }
              const admin = hasSupabaseAdminConfig() ? getSupabaseAdminClient() : null;
              const profilePromise = client.from("org_member_profiles").select("display_name, avatar_url, bio, skills, updated_at").eq("email", String(authUser.email).toLowerCase()).maybeSingle();
              const identitiesPromise = admin ? admin.schema("auth").from("identities").select("provider, identity_data").eq("user_id", authUser.id) : Promise.resolve({ data: [], error: null });
              const [{ data: rawProfile, error: profileError }, { data: rawIdentities, error: identitiesError }] = await Promise.all([profilePromise, identitiesPromise]);
              if (profileError && profileError.code !== "42P01") {
                return Response.json({ error: profileError.message }, { status: 500 });
              }
              if (identitiesError) {
                return Response.json({ error: identitiesError.message }, { status: 500 });
              }
              const profile = rawProfile || null;
              const identities = Array.isArray(rawIdentities) ? rawIdentities : [];
              const meta = authUser.user_metadata ?? null;
              const username = usernameMap.get(String(authUser.id)) || normalizedRequestedUsername;
              const connectedAccounts = identities.map((row) => {
                const handle = row.identity_data?.preferred_username || row.identity_data?.username || row.identity_data?.user_name || row.identity_data?.channel || null;
                const explicitUrl = row.identity_data?.profile_url || null;
                return {
                  provider: row.provider,
                  providerLabel: providerLabel(row.provider),
                  handle,
                  url: explicitUrl || (handle ? providerProfileUrl(row.provider, handle) : null)
                };
              }).filter((entry) => Boolean(entry.provider));
              return Response.json({
                profile: {
                  username,
                  displayName: profile?.display_name || readDisplayNameFromMetadata(meta) || username,
                  avatarUrl: profile?.avatar_url || readAvatarFromMetadata(meta),
                  bio: profile?.bio || null,
                  skills: profile?.skills || [],
                  connectedAccounts,
                  updatedAt: profile?.updated_at || null
                }
              });
            } catch (error) {
              if (error instanceof Error) {
                console.error("[public-profile] failed to load profile", error.message);
              }
              return Response.json({ error: "Could not load public profile right now." }, { status: 500 });
            }
          }
        }
      }
    });
    Route$s = createFileRoute("/api/public-directory")({
      server: {
        handlers: {
          GET: async ({ request }) => {
            try {
              const url = new URL(request.url);
              const q = (url.searchParams.get("q") || "").trim().toLowerCase();
              const limitParam = Number(url.searchParams.get("limit") || "200");
              const limit = Number.isFinite(limitParam) ? Math.max(1, Math.min(500, Math.floor(limitParam))) : 200;
              const client = hasSupabaseAdminConfig() ? getSupabaseAdminClient() : getSupabaseServerClientForToken(getBearerToken$4(request));
              let users = await listAuthIndexedUsers(client);
              if (users.length === 0 && hasSupabaseAdminConfig()) {
                const admin = getSupabaseAdminClient();
                const collected = [];
                let page = 1;
                const perPage = 1e3;
                while (page <= 10) {
                  const { data: usersData, error: usersError } = await admin.auth.admin.listUsers({ page, perPage });
                  if (usersError) break;
                  const pageUsers = usersData?.users || [];
                  if (!pageUsers.length) break;
                  collected.push(...pageUsers);
                  if (pageUsers.length < perPage) break;
                  page += 1;
                }
                users = collected.map((row) => ({
                  id: row.id,
                  email: row.email,
                  user_metadata: row.user_metadata || null,
                  created_at: row.created_at,
                  updated_at: row.updated_at || row.created_at,
                  identities: null
                }));
              }
              const { data: profiles, error: profilesError } = await client.from("org_member_profiles").select("email, display_name, avatar_url, bio").limit(1e4);
              if (profilesError) {
                return Response.json({ error: profilesError.message }, { status: 500 });
              }
              const profileRows = Array.isArray(profiles) ? profiles : [];
              const profileByEmail = new Map(profileRows.map((row) => [String(row.email || "").trim().toLowerCase(), row]));
              const usernameMap = assignDeterministicUsernames(users);
              let entries = users.map((user) => {
                const email = String(user.email || "").trim().toLowerCase();
                if (!email || !user.id) return null;
                const profile = profileByEmail.get(email);
                const username = usernameMap.get(String(user.id));
                if (!username) return null;
                const displayName = profile?.display_name?.trim() || readDisplayNameFromMetadata(user.user_metadata || null) || username;
                return {
                  username,
                  displayName,
                  avatarUrl: profile?.avatar_url || readAvatarFromMetadata(user.user_metadata || null),
                  bio: profile?.bio || null,
                  connectedCount: 0
                };
              }).filter((entry) => Boolean(entry)).filter((entry) => {
                if (!q) return true;
                const haystack = `${entry.username} ${entry.displayName} ${entry.bio || ""}`.toLowerCase();
                return haystack.includes(q);
              }).sort((a, b) => a.username.localeCompare(b.username)).slice(0, limit);
              if (entries.length === 0) {
                const { data: roleEmails } = await client.from("org_user_roles").select("email").limit(1e4);
                const roleRows = Array.isArray(roleEmails) ? roleEmails : [];
                const allEmails = /* @__PURE__ */ new Set();
                for (const profile of profileRows) {
                  const email = String(profile.email || "").trim().toLowerCase();
                  if (email) allEmails.add(email);
                }
                for (const roleRow of roleRows) {
                  const email = String(roleRow.email || "").trim().toLowerCase();
                  if (email) allEmails.add(email);
                }
                entries = Array.from(allEmails).map((email) => {
                  const profile = profileByEmail.get(email);
                  const rawUsername = profile?.display_name?.trim() || email.split("@")[0] || "";
                  const username = normalizeUsername(rawUsername);
                  if (!username) return null;
                  return {
                    username,
                    displayName: profile?.display_name?.trim() || username,
                    avatarUrl: profile?.avatar_url || null,
                    bio: profile?.bio || null,
                    connectedCount: 0
                  };
                }).filter((entry) => Boolean(entry)).filter((entry) => {
                  if (!q) return true;
                  const haystack = `${entry.username} ${entry.displayName} ${entry.bio || ""}`.toLowerCase();
                  return haystack.includes(q);
                }).sort((a, b) => a.username.localeCompare(b.username)).slice(0, limit);
              }
              return Response.json({ entries });
            } catch (error) {
              if (error instanceof Error) {
                console.error("[public-directory] failed to load directory", error.message);
              }
              return Response.json(
                { error: error instanceof Error ? error.message : "Could not load directory right now." },
                { status: 500 }
              );
            }
          }
        }
      }
    });
    LOCAL_SUPERADMIN_EMAIL = "root-superadmin@localhost";
    OWNER_SUPERADMIN_EMAILS = /* @__PURE__ */ new Set(["stotteyman@gmail.com"]);
    SUPERADMIN_FALLBACK_PERMISSIONS = [
      "view_dashboard",
      "view_creator_tools",
      "view_revenue_tracker",
      "view_live_streams",
      "use_autoclipper",
      "manage_livestreams",
      "view_merch",
      "manage_users",
      "manage_permissions",
      "access_admin_dashboard"
    ];
    BUCKET$1 = "blog-media";
    FOLDER = "profile-avatars";
    ALLOWED_MIME_TYPES = /* @__PURE__ */ new Set(["image/jpeg", "image/png", "image/webp", "image/gif"]);
    ALLOWED_EXTENSIONS$1 = /* @__PURE__ */ new Set(["jpg", "jpeg", "png", "webp", "gif"]);
    MAX_SIZE$1 = 8 * 1024 * 1024;
    Route$r = createFileRoute("/api/profile-photo-upload")({
      server: {
        handlers: {
          POST: async ({ request }) => {
            try {
              const isLocalRoot = request.headers.get("x-local-root-session") === "true" && isLocalRequest(request);
              let requesterEmail = "member";
              if (!isLocalRoot) {
                const access = await requirePermission(request, "view_dashboard");
                if (access.role === "banned") {
                  return Response.json({ error: "Banned users cannot upload profile photos." }, { status: 403 });
                }
                requesterEmail = access.requester.email;
              } else {
                requesterEmail = "root-superadmin@localhost";
              }
              const form = await request.formData();
              const file = form.get("file");
              if (!(file instanceof File)) {
                return Response.json({ error: "Image file is required." }, { status: 400 });
              }
              if (file.size <= 0) {
                return Response.json({ error: "File is empty." }, { status: 400 });
              }
              if (file.size > MAX_SIZE$1) {
                return Response.json(
                  { error: `Image is too large. Maximum size is ${Math.floor(MAX_SIZE$1 / (1024 * 1024))} MB.` },
                  { status: 413 }
                );
              }
              const ext = getExtension$1(file.name);
              const hasValidMime = ALLOWED_MIME_TYPES.has(file.type);
              const hasValidExt = ALLOWED_EXTENSIONS$1.has(ext);
              if (!hasValidMime && !hasValidExt) {
                return Response.json({ error: "Unsupported image type. Use JPG, PNG, WEBP, or GIF." }, { status: 400 });
              }
              const safeEmail = requesterEmail.replace(/[^a-z0-9._-]+/gi, "_");
              const stamp = Date.now();
              const random = Math.random().toString(36).slice(2, 10);
              const extension = hasValidExt ? ext : "jpg";
              const path = `${FOLDER}/${safeEmail}/${stamp}-${random}.${extension}`;
              const contentType = file.type || "application/octet-stream";
              const data = await file.arrayBuffer();
              if (hasSupabaseAdminConfig()) {
                const admin = getSupabaseAdminClient();
                const { error: uploadError2 } = await admin.storage.from(BUCKET$1).upload(path, data, { contentType, upsert: false });
                if (uploadError2) {
                  return Response.json({ error: uploadError2.message }, { status: 500 });
                }
                const { data: publicData2 } = admin.storage.from(BUCKET$1).getPublicUrl(path);
                return Response.json({ url: publicData2.publicUrl, path }, { status: 201 });
              }
              const token = getAuthToken(request);
              if (!token) {
                return Response.json(
                  { error: "Missing bearer token for upload in fallback mode." },
                  { status: 401 }
                );
              }
              const scopedClient = getSupabaseServerClientForToken(token);
              const { error: uploadError } = await scopedClient.storage.from(BUCKET$1).upload(path, data, { contentType, upsert: false });
              if (uploadError) {
                return Response.json({ error: uploadError.message }, { status: 500 });
              }
              const { data: publicData } = scopedClient.storage.from(BUCKET$1).getPublicUrl(path);
              return Response.json({ url: publicData.publicUrl, path }, { status: 201 });
            } catch (error) {
              if (error instanceof Response) return error;
              return Response.json(
                { error: error instanceof Error ? error.message : "Unexpected server error" },
                { status: 500 }
              );
            }
          }
        }
      }
    });
    Route$q = createFileRoute("/api/profile")({
      server: {
        handlers: {
          GET: async ({ request }) => {
            try {
              await requirePermission(request, "view_creator_tools");
              const url = new URL(request.url);
              const email = url.searchParams.get("email");
              if (!email) return Response.json({ error: "email is required" }, { status: 400 });
              const admin = getSupabaseAdminClient();
              const { data, error } = await admin.from("org_member_profiles").select("email, display_name, avatar_url, bio, skills").eq("email", email).maybeSingle();
              if (error && error.code !== "42P01") {
                return Response.json({ error: error.message }, { status: 500 });
              }
              return Response.json({ profile: data || null });
            } catch (error) {
              if (error instanceof Response) return error;
              return Response.json({ error: "Unexpected server error" }, { status: 500 });
            }
          }
        }
      }
    });
    WRITE_ROLES$1 = /* @__PURE__ */ new Set(["superadmin", "admin", "manager", "staff", "helper", "user"]);
    ALLOWED_IMAGES = /* @__PURE__ */ new Set(["jpg", "jpeg", "png", "gif", "webp"]);
    ALLOWED_VIDEOS = /* @__PURE__ */ new Set(["mp4", "webm", "mov", "avi", "mkv"]);
    Route$p = createFileRoute("/api/news-upload")({
      server: {
        handlers: {
          POST: async ({ request }) => {
            try {
              let requesterEmail = "";
              let accessToken = "";
              if (hasSupabaseAdminConfig()) {
                const access = await getRequesterAccess(request);
                if (!WRITE_ROLES$1.has(access.role)) {
                  return Response.json({ error: "Insufficient permissions" }, { status: 403 });
                }
                requesterEmail = access.requester.email;
              } else {
                const useLocalRoot = request.headers.get("x-local-root-session") === "true" && isLocalRequest(request);
                if (!useLocalRoot) {
                  const authHeader = request.headers.get("authorization") || request.headers.get("Authorization") || "";
                  const token = authHeader.startsWith("Bearer ") ? authHeader.slice(7).trim() : "";
                  if (!token) {
                    return Response.json({ error: "Unauthorized" }, { status: 401 });
                  }
                  const client = getSupabaseServerClientForToken(token);
                  const {
                    data: { user },
                    error: error2
                  } = await client.auth.getUser(token);
                  if (error2 || !user?.email) {
                    return Response.json({ error: "Unauthorized" }, { status: 401 });
                  }
                  requesterEmail = user.email.toLowerCase();
                  accessToken = token;
                } else {
                  requesterEmail = "root-superadmin@localhost";
                }
              }
              const form = await request.formData();
              const file = form.get("file");
              if (!file) {
                return Response.json({ error: "No file uploaded" }, { status: 400 });
              }
              const ext = file.name.split(".").pop()?.toLowerCase() || "bin";
              const isImage = ALLOWED_IMAGES.has(ext);
              const isVideo = ALLOWED_VIDEOS.has(ext);
              if (!isImage && !isVideo) {
                return Response.json({ error: "Invalid file type" }, { status: 400 });
              }
              const bucket = "blog-media";
              const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, "_");
              const filePath = `${requesterEmail}/${Date.now()}-${safeName}`;
              const supabase = hasSupabaseAdminConfig() ? getSupabaseAdminClient() : getSupabaseServerClientForToken(accessToken || void 0);
              const { error } = await supabase.storage.from(bucket).upload(filePath, file, {
                contentType: file.type,
                upsert: false
              });
              if (error) {
                return Response.json({ error: error.message }, { status: 500 });
              }
              const publicUrl = supabase.storage.from(bucket).getPublicUrl(filePath).data.publicUrl;
              return Response.json({ url: publicUrl, kind: isImage ? "image" : "video" }, { status: 201 });
            } catch (error) {
              if (error instanceof Response) return error;
              return Response.json(
                { error: error instanceof Error ? error.message : "Unexpected server error" },
                { status: 500 }
              );
            }
          }
        }
      }
    });
    WRITE_ROLES = /* @__PURE__ */ new Set(["superadmin", "admin", "manager", "staff", "helper", "user"]);
    NewsPostSchema = z.object({
      title: z.string().min(3).max(200),
      body: z.string().min(1).max(2e4),
      image_urls: z.array(z.string().url()).max(10).default([]),
      video_urls: z.array(z.string().url()).max(10).default([]),
      embed_links: z.array(z.string().url()).max(20).default([])
    });
    Route$o = createFileRoute("/api/news")({
      server: {
        handlers: {
          GET: async () => {
            try {
              const client = getSupabaseServerPublicClient();
              const { data, error } = await client.from("org_blog_posts").select("id, title, body, author_email, image_urls, video_urls, embed_links, created_at, updated_at").eq("is_published", true).order("created_at", { ascending: false });
              if (error) {
                if (isMissingBlogTableError(error)) {
                  return Response.json([]);
                }
                return Response.json({ error: error.message }, { status: 500 });
              }
              const posts = (data || []).map((row) => ({
                id: row.id,
                title: row.title,
                body: row.body,
                author: row.author_email,
                image_urls: row.image_urls || [],
                video_urls: row.video_urls || [],
                embed_links: row.embed_links || [],
                created_at: row.created_at,
                updated_at: row.updated_at
              }));
              return Response.json(posts);
            } catch (error) {
              if (error instanceof Response) return error;
              return Response.json(
                { error: error instanceof Error ? error.message : "Unexpected server error" },
                { status: 500 }
              );
            }
          },
          POST: async ({ request }) => {
            try {
              let authorEmail = "";
              let canContribute = false;
              if (hasSupabaseAdminConfig()) {
                const access = await getRequesterAccess(request);
                canContribute = WRITE_ROLES.has(access.role) && access.role !== "banned";
                authorEmail = access.requester.email;
              } else {
                const useLocalRoot = request.headers.get("x-local-root-session") === "true" && isLocalRequest(request);
                if (!useLocalRoot) {
                  return Response.json(
                    { error: "Blog contributions require SUPABASE_SERVICE_ROLE_KEY in this environment." },
                    { status: 503 }
                  );
                }
                await requirePermission(request, "view_creator_tools");
                authorEmail = "root-superadmin@localhost";
                canContribute = true;
              }
              if (!canContribute) {
                return Response.json({ error: "Insufficient permissions" }, { status: 403 });
              }
              const payload = NewsPostSchema.safeParse(await request.json());
              if (!payload.success) {
                return Response.json({ error: payload.error.flatten() }, { status: 400 });
              }
              const normalized = {
                title: payload.data.title.trim(),
                body: payload.data.body.trim(),
                image_urls: payload.data.image_urls,
                video_urls: payload.data.video_urls,
                embed_links: payload.data.embed_links
              };
              const db = hasSupabaseAdminConfig() ? getSupabaseAdminClient() : getSupabaseServerPublicClient();
              const { data, error } = await db.from("org_blog_posts").insert([
                {
                  ...normalized,
                  author_email: authorEmail
                }
              ]).select("id, title, body, author_email, image_urls, video_urls, embed_links, created_at, updated_at");
              if (error) {
                if (isMissingBlogTableError(error)) {
                  return Response.json(
                    { error: "Blog storage table is not set up yet. Please run the blog schema migration first." },
                    { status: 503 }
                  );
                }
                return Response.json({ error: error.message }, { status: 500 });
              }
              return Response.json((data || [])[0], { status: 201 });
            } catch (error) {
              if (error instanceof Response) return error;
              return Response.json(
                { error: error instanceof Error ? error.message : "Unexpected server error" },
                { status: 500 }
              );
            }
          },
          HEAD: async () => {
            return new Response(null, { status: 200 });
          },
          OPTIONS: async () => {
            return new Response(null, {
              status: 204,
              headers: {
                Allow: "GET, POST, HEAD, OPTIONS"
              }
            });
          }
        }
      }
    });
    SUBSCRIBE_RATE_LIMIT_WINDOW_MS = 5 * 60 * 1e3;
    SUBSCRIBE_RATE_LIMIT_MAX_REQUESTS = 10;
    subscribeRequestLog = /* @__PURE__ */ new Map();
    subscribeSchema = z.object({
      email: z.string().trim().email().max(200),
      liveAlerts: z.boolean().default(true),
      newsletter: z.boolean().default(true),
      productUpdates: z.boolean().default(false),
      communityUpdates: z.boolean().default(false),
      source: z.string().trim().max(60).optional()
    });
    Route$n = createFileRoute("/api/marketing-proof")({
      server: {
        handlers: {
          POST: async ({ request }) => {
            try {
              const access = await getRequesterAccess(request);
              if (isRateLimited(request)) {
                return Response.json(
                  { error: "Too many requests. Please wait and try again." },
                  { status: 429 }
                );
              }
              const body = await request.json();
              const parsed = subscribeSchema.safeParse(body);
              if (!parsed.success) {
                return Response.json({ error: "Invalid payload" }, { status: 400 });
              }
              const { email, liveAlerts, newsletter, productUpdates, communityUpdates, source } = parsed.data;
              const requestedEmail = email.toLowerCase();
              const accountEmail = access.requester.email.toLowerCase();
              if (requestedEmail !== accountEmail) {
                return Response.json(
                  { error: "Subscription email must match your account email." },
                  { status: 403 }
                );
              }
              if (!liveAlerts && !newsletter && !productUpdates && !communityUpdates) {
                return Response.json({ error: "Please choose at least one notification type." }, { status: 400 });
              }
              const admin = getSupabaseAdminClient();
              const { error } = await admin.from("notification_subscribers").upsert(
                {
                  email: requestedEmail,
                  live_alerts: liveAlerts,
                  newsletter,
                  product_updates: productUpdates,
                  community_updates: communityUpdates,
                  source: source || "app",
                  status: "active",
                  subscribed_at: (/* @__PURE__ */ new Date()).toISOString(),
                  unsubscribed_at: null,
                  updated_at: (/* @__PURE__ */ new Date()).toISOString()
                },
                { onConflict: "email" }
              );
              if (error) return Response.json({ error: "Could not save subscription right now." }, { status: 500 });
              return Response.json({ ok: true, subscribed: true });
            } catch (error) {
              if (error instanceof Response) return error;
              return Response.json({ error: "Unexpected server error" }, { status: 500 });
            }
          },
          GET: async ({ request }) => {
            try {
              await requirePermission(request, "access_admin_dashboard");
              const admin = getSupabaseAdminClient();
              const quarterStartIso = getQuarterStartIso(/* @__PURE__ */ new Date());
              const [
                { count: activeMembersCount, error: membersError },
                { count: winsThisQuarterCount, error: winsError },
                { data: completedEntriesData, error: completedEntriesError }
              ] = await Promise.all([
                admin.from("org_user_roles").select("email", { head: true, count: "exact" }).neq("role", "banned"),
                admin.from("org_dashboard_tool_entries").select("id", { head: true, count: "exact" }).eq("status", "done").gte("updated_at", quarterStartIso),
                admin.from("org_dashboard_tool_entries").select("created_at, updated_at").eq("status", "done").not("updated_at", "is", null).limit(1e3)
              ]);
              if (membersError) return Response.json({ error: membersError.message }, { status: 500 });
              if (winsError) return Response.json({ error: winsError.message }, { status: 500 });
              if (completedEntriesError) return Response.json({ error: completedEntriesError.message }, { status: 500 });
              const completionHours = (completedEntriesData || []).map((entry) => {
                const createdAt = new Date(entry.created_at).getTime();
                const updatedAt = new Date(entry.updated_at).getTime();
                if (!Number.isFinite(createdAt) || !Number.isFinite(updatedAt)) return null;
                const diffMs = updatedAt - createdAt;
                if (diffMs < 0) return null;
                return diffMs / (1e3 * 60 * 60);
              }).filter((value) => value !== null);
              return Response.json({
                activeMembers: activeMembersCount || 0,
                memberWinsThisQuarter: winsThisQuarterCount || 0,
                averageTimeToFirstActionHours: average(completionHours),
                sampleSize: completionHours.length,
                asOf: (/* @__PURE__ */ new Date()).toISOString()
              });
            } catch {
              return Response.json({ error: "Unexpected server error" }, { status: 500 });
            }
          }
        }
      }
    });
    trackViewSchema = z.object({
      documentId: z.string().uuid()
    });
    adminViewsQuerySchema = z.object({
      documentId: z.string().uuid().optional(),
      limit: z.coerce.number().int().min(1).max(500).default(100)
    });
    Route$m = createFileRoute("/api/knowledge-vault")({
      server: {
        handlers: {
          /**
           * POST /api/knowledge-vault
           * Body: { documentId: string }
           * Records that the authenticated user viewed a document.
           */
          POST: async ({ request }) => {
            try {
              const access = await requirePermission(request, "view_creator_tools");
              const body = await request.json();
              const parsed = trackViewSchema.safeParse(body);
              if (!parsed.success) {
                return Response.json({ error: "Invalid payload", details: parsed.error.flatten() }, { status: 400 });
              }
              const admin = getSupabaseAdminClient();
              const { error } = await admin.from("org_knowledge_vault_views").insert({
                document_id: parsed.data.documentId,
                viewer_email: access.requester.email,
                viewer_role: access.role
              });
              if (error && error.code !== "42P01") {
                return Response.json({ error: error.message }, { status: 500 });
              }
              return Response.json({ tracked: true });
            } catch (error) {
              if (error instanceof Response) return error;
              return Response.json({ error: "Unexpected server error" }, { status: 500 });
            }
          },
          /**
           * GET /api/knowledge-vault?documentId=<id>&limit=<n>
           * Admin-only: returns view history for a document or all documents.
           */
          GET: async ({ request }) => {
            try {
              const access = await requirePermission(request, "access_admin_dashboard");
              const url = new URL(request.url);
              const parsed = adminViewsQuerySchema.safeParse({
                documentId: url.searchParams.get("documentId") ?? void 0,
                limit: url.searchParams.get("limit") ?? 100
              });
              if (!parsed.success) {
                return Response.json({ error: "Invalid query" }, { status: 400 });
              }
              const admin = getSupabaseAdminClient();
              let query = admin.from("org_knowledge_vault_views").select("id, document_id, viewer_email, viewer_role, viewed_at").order("viewed_at", { ascending: false }).limit(parsed.data.limit);
              if (parsed.data.documentId) {
                query = query.eq("document_id", parsed.data.documentId);
              }
              const { data, error } = await query;
              if (error && error.code === "42P01") {
                return Response.json({ views: [], note: "Views table not yet created." });
              }
              if (error) return Response.json({ error: error.message }, { status: 500 });
              return Response.json({
                requester: { email: access.requester.email, role: access.role },
                views: data || []
              });
            } catch (error) {
              if (error instanceof Response) return error;
              return Response.json({ error: "Unexpected server error" }, { status: 500 });
            }
          }
        }
      }
    });
    Route$l = createFileRoute("/api/kick-login")({
      server: {
        handlers: {
          GET: async ({ request }) => {
            const clientId = process.env.KICK_CLIENT_ID;
            const redirectUri = process.env.KICK_REDIRECT_URI || `${new URL(request.url).origin}/api/kick-callback`;
            if (!clientId) {
              return Response.json({ error: "Kick OAuth is not configured on this server." }, { status: 500 });
            }
            const state = crypto.randomUUID();
            const params = new URLSearchParams({
              response_type: "code",
              client_id: clientId,
              redirect_uri: redirectUri,
              scope: "user:read",
              state
            });
            const authUrl = `https://kick.com/oauth/authorize?${params.toString()}`;
            const response = Response.redirect(authUrl, 302);
            response.headers.set(
              "Set-Cookie",
              `kick_oauth_state=${state}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=600`
            );
            return response;
          }
        }
      }
    });
    LOCALHOST_HOSTS = /* @__PURE__ */ new Set(["localhost", "127.0.0.1"]);
    Route$k = createFileRoute("/api/kick-callback")({
      server: {
        handlers: {
          GET: async ({ request }) => {
            const url = new URL(request.url);
            const authOrigin = normalizeAuthOrigin(url.origin);
            const code = url.searchParams.get("code");
            const state = url.searchParams.get("state");
            const errorParam = url.searchParams.get("error");
            if (errorParam) {
              return Response.redirect(buildAuthRedirectUrl(authOrigin, "/dashboard?error=kick_oauth_denied"), 302);
            }
            const cookieHeader = request.headers.get("cookie") || "";
            const cookieState = cookieHeader.split(";").map((c) => c.trim()).find((c) => c.startsWith("kick_oauth_state="))?.replace("kick_oauth_state=", "");
            if (!state || !cookieState || state !== cookieState) {
              return Response.redirect(buildAuthRedirectUrl(authOrigin, "/dashboard?error=kick_oauth_invalid_state"), 302);
            }
            if (!code) {
              return Response.redirect(buildAuthRedirectUrl(authOrigin, "/dashboard?error=kick_oauth_no_code"), 302);
            }
            const clientId = process.env.KICK_CLIENT_ID;
            const clientSecret = process.env.KICK_CLIENT_SECRET;
            const redirectUri = process.env.KICK_REDIRECT_URI || buildAuthRedirectUrl(authOrigin, "/api/kick-callback");
            if (!clientId || !clientSecret) {
              return Response.redirect(buildAuthRedirectUrl(authOrigin, "/dashboard?error=kick_not_configured"), 302);
            }
            try {
              const tokenResponse = await fetch("https://kick.com/oauth/token", {
                method: "POST",
                headers: { "Content-Type": "application/x-www-form-urlencoded" },
                body: new URLSearchParams({
                  grant_type: "authorization_code",
                  client_id: clientId,
                  client_secret: clientSecret,
                  redirect_uri: redirectUri,
                  code
                }).toString()
              });
              if (!tokenResponse.ok) {
                return Response.redirect(buildAuthRedirectUrl(authOrigin, "/dashboard?error=kick_token_exchange_failed"), 302);
              }
              const tokens = await tokenResponse.json();
              const profileResponse = await fetch("https://kick.com/api/v1/user", {
                headers: { Authorization: `Bearer ${tokens.access_token}` }
              });
              if (!profileResponse.ok) {
                return Response.redirect(buildAuthRedirectUrl(authOrigin, "/dashboard?error=kick_profile_fetch_failed"), 302);
              }
              const kickUser = await profileResponse.json();
              const email = kickUser.email || `kick_${kickUser.id}@kick.wagesociety.local`;
              const admin = getSupabaseAdminClient();
              const { data: existingUsers } = await admin.auth.admin.listUsers();
              const existing = existingUsers?.users?.find((u) => u.email === email);
              if (existing) {
                const existingMeta = existing.user_metadata ?? {};
                await admin.auth.admin.updateUserById(existing.id, {
                  user_metadata: {
                    ...existingMeta,
                    username: kickUser.username,
                    full_name: kickUser.name || kickUser.username,
                    avatar_url: kickUser.profile_pic || null,
                    kick_username: kickUser.username,
                    kick_id: kickUser.id,
                    membership_plan: String(existingMeta.membership_plan || "free")
                  }
                });
              } else {
                const { data: newUser, error: createError } = await admin.auth.admin.createUser({
                  email,
                  email_confirm: true,
                  user_metadata: {
                    username: kickUser.username,
                    full_name: kickUser.name || kickUser.username,
                    avatar_url: kickUser.profile_pic || null,
                    kick_username: kickUser.username,
                    kick_id: kickUser.id,
                    membership_plan: "free",
                    onboarding_completed: false
                  }
                });
                if (createError || !newUser.user) {
                  return Response.redirect(buildAuthRedirectUrl(authOrigin, "/dashboard?error=kick_account_create_failed"), 302);
                }
                await admin.rpc("ensure_org_member_role", {
                  p_email: email,
                  p_role: "user"
                });
              }
              const { data: linkData, error: linkError } = await admin.auth.admin.generateLink({
                type: "magiclink",
                email,
                options: { redirectTo: buildAuthRedirectUrl(authOrigin, "/dashboard") }
              });
              if (linkError || !linkData?.properties?.action_link) {
                return Response.redirect(buildAuthRedirectUrl(authOrigin, "/dashboard?error=kick_session_create_failed"), 302);
              }
              const clearCookie = "kick_oauth_state=; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=0";
              const redirect2 = Response.redirect(linkData.properties.action_link, 302);
              redirect2.headers.set("Set-Cookie", clearCookie);
              return redirect2;
            } catch {
              return Response.redirect(buildAuthRedirectUrl(authOrigin, "/dashboard?error=kick_unexpected_error"), 302);
            }
          }
        }
      }
    });
    Route$j = createFileRoute("/api/create-payment-intent")({
      server: {
        handlers: {
          POST: async ({ request }) => {
            try {
              if (!getStripeSecretKey()) {
                return Response.json(
                  {
                    error: "Billing is not configured. Missing STRIPE_SECRET_KEY in server environment."
                  },
                  { status: 503 }
                );
              }
              const access = await getRequesterAccess(request);
              const body = await request.json();
              const normalizedPlanSlug = String(body.planSlug || "").trim().toLowerCase();
              const { email, name } = body;
              if (!normalizedPlanSlug || !email) {
                return Response.json({ error: "planSlug and email are required." }, { status: 400 });
              }
              const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
              if (!EMAIL_RE.test(email)) {
                return Response.json({ error: "Invalid email address." }, { status: 400 });
              }
              if (email.toLowerCase() !== access.requester.email) {
                return Response.json({ error: "Email must match the authenticated user." }, { status: 403 });
              }
              const serverClient = getServerClientForRequest(request);
              const { data: _plan, error: planError } = await serverClient.from("org_shop_membership_plans").select("id, slug, name, price_cents, display_price").eq("slug", normalizedPlanSlug).eq("is_active", true).single();
              const plan = _plan;
              if (planError || !plan) {
                return Response.json(
                  {
                    error: "Plan not found.",
                    planSlug: normalizedPlanSlug,
                    details: planError?.message || null
                  },
                  { status: 404 }
                );
              }
              const stripe = getStripe();
              const existingCustomers = await stripe.customers.list({ email, limit: 1 });
              let customer = existingCustomers.data[0];
              if (!customer) {
                customer = await stripe.customers.create({
                  email,
                  name: name || void 0,
                  metadata: { membership_plan: plan.slug }
                });
              }
              const activeStatuses = ["active", "trialing", "past_due", "incomplete"];
              const subs = await stripe.subscriptions.list({
                customer: customer.id,
                status: "all",
                limit: 25
              });
              const existingSubscription = subs.data.find(
                (sub) => activeStatuses.includes(sub.status)
              );
              const baseUrl = getBaseUrl(request);
              if (plan.price_cents === 0) {
                if (existingSubscription) {
                  await stripe.subscriptions.cancel(existingSubscription.id);
                }
                await updateUserMembershipMetadata(request, email.toLowerCase(), {
                  membership_plan: plan.slug,
                  stripe_customer_id: customer.id,
                  stripe_subscription_id: void 0
                });
                await serverClient.rpc("ensure_org_member_role", {
                  p_email: email.toLowerCase()
                });
                return Response.json({
                  free: true,
                  planSlug: plan.slug,
                  successUrl: `${baseUrl}/dashboard?membership=${encodeURIComponent(plan.slug)}&status=success`
                });
              }
              if (existingSubscription) {
                const createdPrice = await stripe.prices.create({
                  currency: "usd",
                  unit_amount: plan.price_cents,
                  recurring: { interval: "month" },
                  product_data: {
                    name: `${plan.name} Membership`,
                    metadata: { planSlug: plan.slug }
                  },
                  metadata: { planSlug: plan.slug }
                });
                const currentItem = existingSubscription.items.data[0];
                if (!currentItem) {
                  return Response.json({ error: "Subscription item not found." }, { status: 500 });
                }
                const updatedSubscription = await stripe.subscriptions.update(existingSubscription.id, {
                  items: [
                    {
                      id: currentItem.id,
                      price: createdPrice.id
                    }
                  ],
                  proration_behavior: "always_invoice",
                  metadata: {
                    ...existingSubscription.metadata || {},
                    membership_plan: plan.slug,
                    customerEmail: email.toLowerCase()
                  }
                });
                await updateUserMembershipMetadata(request, email.toLowerCase(), {
                  membership_plan: plan.slug,
                  stripe_customer_id: customer.id,
                  stripe_subscription_id: updatedSubscription.id
                });
                await serverClient.rpc("ensure_org_member_role", {
                  p_email: email.toLowerCase()
                });
                return Response.json({
                  updated: true,
                  planSlug: plan.slug,
                  subscriptionId: updatedSubscription.id,
                  successUrl: `${baseUrl}/dashboard?membership=${encodeURIComponent(plan.slug)}&status=success`
                });
              }
              const session = await stripe.checkout.sessions.create({
                mode: "subscription",
                customer: customer.id,
                success_url: `${baseUrl}/dashboard?membership=${encodeURIComponent(plan.slug)}&status=success&session_id={CHECKOUT_SESSION_ID}`,
                cancel_url: `${baseUrl}/dashboard?membership=${encodeURIComponent(plan.slug)}&status=cancelled`,
                line_items: [
                  {
                    quantity: 1,
                    price_data: {
                      currency: "usd",
                      unit_amount: plan.price_cents,
                      recurring: { interval: "month" },
                      product_data: {
                        name: `${plan.name} Membership`,
                        metadata: {
                          planSlug: plan.slug
                        }
                      }
                    }
                  }
                ],
                subscription_data: {
                  metadata: {
                    membership_plan: plan.slug,
                    customerEmail: email.toLowerCase()
                  }
                },
                metadata: {
                  membership_plan: plan.slug,
                  customerEmail: email.toLowerCase()
                }
              });
              return Response.json({
                checkoutUrl: session.url,
                sessionId: session.id,
                customerId: customer.id,
                planName: plan.name,
                displayPrice: plan.display_price
              });
            } catch (err) {
              if (err instanceof Response) {
                return err;
              }
              const message = err instanceof Error ? err.message : "Unexpected server error.";
              return Response.json({ error: message }, { status: 500 });
            }
          }
        }
      }
    });
    createSchema$1 = z.object({
      title: z.string().trim().min(3).max(160),
      description: z.string().trim().max(2e3).default(""),
      skillsNeeded: z.array(z.string().trim().max(40)).max(20).default([]),
      spotsAvailable: z.number().int().min(1).max(20).default(1),
      projectUrl: z.string().url().optional().or(z.literal(""))
    });
    updateSchema$3 = createSchema$1.partial().extend({
      id: z.string().uuid(),
      status: z.enum(["open", "closed", "completed"]).optional()
    });
    deleteSchema = z.object({ id: z.string().uuid() });
    Route$i = createFileRoute("/api/collab")({
      server: {
        handlers: {
          GET: async ({ request }) => {
            try {
              const access = await requirePermission(request, "view_creator_tools");
              const url = new URL(request.url);
              const mine = url.searchParams.get("mine") === "1";
              const admin = getSupabaseAdminClient();
              let query = admin.from("org_collab_requests").select("id, owner_email, title, description, skills_needed, spots_available, status, project_url, created_at, updated_at").order("created_at", { ascending: false });
              if (mine) {
                query = query.eq("owner_email", access.requester.email);
              } else {
                query = query.eq("status", "open");
              }
              const { data, error } = await query;
              if (error && error.code !== "42P01") {
                return Response.json({ error: error.message }, { status: 500 });
              }
              const requests = data || [];
              const { data: myApps } = await admin.from("org_collab_applications").select("request_id").eq("applicant_email", access.requester.email);
              const myAppRequestIds = new Set(
                (myApps || []).map((a) => a.request_id)
              );
              let appCounts = {};
              if (mine && requests.length) {
                const ids = requests.map((r) => r.id);
                const { data: counts } = await admin.from("org_collab_applications").select("request_id").in("request_id", ids);
                for (const row of counts || []) {
                  appCounts[row.request_id] = (appCounts[row.request_id] || 0) + 1;
                }
              }
              return Response.json({
                requests: requests.map((r) => ({
                  ...r,
                  hasApplied: myAppRequestIds.has(r.id),
                  isOwner: r.owner_email === access.requester.email,
                  applicantCount: appCounts[r.id] || 0
                }))
              });
            } catch (error) {
              if (error instanceof Response) return error;
              return Response.json({ error: "Unexpected server error" }, { status: 500 });
            }
          },
          POST: async ({ request }) => {
            try {
              const access = await requirePermission(request, "view_creator_tools");
              const body = await request.json();
              const parsed = createSchema$1.safeParse(body);
              if (!parsed.success) {
                return Response.json({ error: "Invalid payload", details: parsed.error.flatten() }, { status: 400 });
              }
              const admin = getSupabaseAdminClient();
              const { data, error } = await admin.from("org_collab_requests").insert({
                owner_email: access.requester.email,
                title: parsed.data.title,
                description: parsed.data.description,
                skills_needed: parsed.data.skillsNeeded,
                spots_available: parsed.data.spotsAvailable,
                project_url: parsed.data.projectUrl || null
              }).select("id, owner_email, title, description, skills_needed, spots_available, status, project_url, created_at, updated_at").single();
              if (error) return Response.json({ error: error.message }, { status: 500 });
              return Response.json({ request: data });
            } catch (error) {
              if (error instanceof Response) return error;
              return Response.json({ error: "Unexpected server error" }, { status: 500 });
            }
          },
          PUT: async ({ request }) => {
            try {
              const access = await requirePermission(request, "view_creator_tools");
              const body = await request.json();
              const parsed = updateSchema$3.safeParse(body);
              if (!parsed.success) {
                return Response.json({ error: "Invalid payload" }, { status: 400 });
              }
              const { id, ...fields } = parsed.data;
              const admin = getSupabaseAdminClient();
              const { data, error } = await admin.from("org_collab_requests").update({
                ...fields.title !== void 0 && { title: fields.title },
                ...fields.description !== void 0 && { description: fields.description },
                ...fields.skillsNeeded !== void 0 && { skills_needed: fields.skillsNeeded },
                ...fields.spotsAvailable !== void 0 && { spots_available: fields.spotsAvailable },
                ...fields.status !== void 0 && { status: fields.status },
                ...fields.projectUrl !== void 0 && { project_url: fields.projectUrl || null },
                updated_at: (/* @__PURE__ */ new Date()).toISOString()
              }).eq("id", id).eq("owner_email", access.requester.email).select("id").maybeSingle();
              if (error) return Response.json({ error: error.message }, { status: 500 });
              if (!data) return Response.json({ error: "Not found or not authorized" }, { status: 403 });
              return Response.json({ updated: true });
            } catch (error) {
              if (error instanceof Response) return error;
              return Response.json({ error: "Unexpected server error" }, { status: 500 });
            }
          },
          DELETE: async ({ request }) => {
            try {
              const access = await requirePermission(request, "view_creator_tools");
              const body = await request.json();
              const parsed = deleteSchema.safeParse(body);
              if (!parsed.success) {
                return Response.json({ error: "Invalid payload" }, { status: 400 });
              }
              const admin = getSupabaseAdminClient();
              const { error } = await admin.from("org_collab_requests").delete().eq("id", parsed.data.id).eq("owner_email", access.requester.email);
              if (error) return Response.json({ error: error.message }, { status: 500 });
              return Response.json({ deleted: true });
            } catch (error) {
              if (error instanceof Response) return error;
              return Response.json({ error: "Unexpected server error" }, { status: 500 });
            }
          }
        }
      }
    });
    USERNAME_REGEX$1 = /^[a-zA-Z0-9_-]{3,20}$/;
    Route$h = createFileRoute("/api/check-username")({
      server: {
        handlers: {
          GET: async ({ request }) => {
            const url = new URL(request.url);
            const username = (url.searchParams.get("username") ?? "").trim();
            const currentEmail = (url.searchParams.get("currentEmail") ?? "").trim().toLowerCase();
            if (!USERNAME_REGEX$1.test(username)) {
              return Response.json(
                {
                  available: false,
                  username,
                  reason: "Username must be 3\u201320 characters and contain only letters, numbers, underscores, or hyphens."
                },
                { status: 200 }
              );
            }
            try {
              const client = hasSupabaseAdminConfig() ? getSupabaseAdminClient() : getSupabaseServerPublicClient();
              const { data, error } = await client.from("org_member_profiles").select("email, display_name").ilike("display_name", username).limit(1);
              if (error && error.code !== "42P01") {
                return Response.json({ available: true, username, reason: "Availability check is limited in this environment." });
              }
              let takenInMetadata = false;
              const normalized = username.toLowerCase();
              let authIndexUsers = await listAuthIndexedUsers(client);
              if (authIndexUsers.length === 0 && hasSupabaseAdminConfig()) {
                const admin = getSupabaseAdminClient();
                const { data: authUsersPage, error: authUsersError } = await admin.auth.admin.listUsers({
                  page: 1,
                  perPage: 1e3
                });
                if (!authUsersError) {
                  authIndexUsers = (authUsersPage?.users || []).map((row) => ({
                    id: row.id,
                    email: row.email,
                    user_metadata: row.user_metadata ?? null,
                    created_at: row.created_at,
                    updated_at: row.updated_at || row.created_at,
                    identities: null
                  }));
                }
              }
              takenInMetadata = authIndexUsers.some((row) => {
                const rowEmail = String(row.email || "").toLowerCase();
                if (currentEmail && rowEmail === currentEmail) return false;
                const meta = row.user_metadata ?? null;
                const candidates = [meta?.username, meta?.preferred_username];
                return candidates.some((candidate) => candidate?.trim().toLowerCase() === normalized);
              });
              const takenInProfiles = (Array.isArray(data) ? data : []).some((row) => {
                const rowEmail = String(row.email || "").toLowerCase();
                if (currentEmail && rowEmail === currentEmail) return false;
                return true;
              });
              const taken = takenInProfiles || takenInMetadata;
              return Response.json({ available: !taken, username });
            } catch {
              return Response.json({ available: true, username, reason: "Availability check is temporarily unavailable." });
            }
          }
        }
      }
    });
    $$splitComponentImporter$2 = () => Promise.resolve().then(() => (init_admin_users_CcJsv1Wm(), admin_users_CcJsv1Wm_exports));
    Route$g = createFileRoute("/admin/users")({
      beforeLoad: async () => {
        await requireAuthenticatedRoute();
      },
      head: () => ({
        meta: [{
          title: "Admin Users \u2014 W.A.G.E. Society"
        }, {
          name: "description",
          content: "Manage members, roles, and permissions."
        }, {
          name: "robots",
          content: "noindex, nofollow"
        }]
      }),
      component: lazyRouteComponent($$splitComponentImporter$2, "component")
    });
    $$splitComponentImporter$1 = () => Promise.resolve().then(() => (init_admin_shop_PTpzx7UB(), admin_shop_PTpzx7UB_exports));
    Route$f = createFileRoute("/admin/shop")({
      beforeLoad: async () => {
        await requireAuthenticatedRoute();
      },
      head: () => ({
        meta: [{
          title: "Admin Shop \u2014 W.A.G.E. Society"
        }, {
          name: "description",
          content: "Shop CRUD management center for merch and membership plans."
        }, {
          name: "robots",
          content: "noindex, nofollow"
        }]
      }),
      component: lazyRouteComponent($$splitComponentImporter$1, "component")
    });
    toolSchema$1 = z.enum(["bulletin-board", "content-calendar", "revenue-tracker", "creator-task-board", "collaboration-hub", "knowledge-vault", "promotion-hub", "merch-studio", "creator-growth-system"]);
    $$splitComponentImporter = () => Promise.resolve().then(() => (init_dashboard_tools_tool_08iLNKOK(), dashboard_tools_tool_08iLNKOK_exports));
    Route$e = createFileRoute("/dashboard/tools/$tool")({
      component: lazyRouteComponent($$splitComponentImporter, "component"),
      beforeLoad: async ({
        params
      }) => {
        await requireAuthenticatedRoute();
        const parsed = toolSchema$1.safeParse(params.tool);
        if (!parsed.success) {
          throw notFound2();
        }
      }
    });
    toolSchema = z.enum([
      "bulletin-board",
      "content-calendar",
      "revenue-tracker",
      "creator-task-board",
      "collaboration-hub",
      "knowledge-vault",
      "promotion-hub"
    ]);
    statusSchema = z.enum(["idea", "planned", "active", "blocked", "done"]);
    baseEntrySchema = z.object({
      title: z.string().trim().min(1).max(160),
      details: z.string().trim().max(4e3).default(""),
      status: statusSchema.default("active"),
      eventDate: z.string().datetime().nullable().optional(),
      amountCents: z.number().int().min(0).nullable().optional(),
      metadata: z.record(z.string(), z.unknown()).optional()
    });
    createEntrySchema = baseEntrySchema;
    updateEntrySchema = baseEntrySchema.extend({
      id: z.string().uuid()
    });
    deleteEntrySchema = z.object({
      id: z.string().uuid()
    });
    requiredPermissionByTool = {
      "bulletin-board": "view_creator_tools",
      "content-calendar": "view_creator_tools",
      "revenue-tracker": "view_revenue_tracker",
      "creator-task-board": "view_creator_tools",
      "collaboration-hub": "view_creator_tools",
      "knowledge-vault": "view_creator_tools",
      "promotion-hub": "view_creator_tools"
    };
    Route$d = createFileRoute("/api/tools/$tool")({
      server: {
        handlers: {
          GET: async ({ request, params }) => {
            try {
              const { tool, access } = await authorizeForTool(request, params.tool);
              const admin = getDbClient(request);
              const url = new URL(request.url);
              const isAdmin = access.role === "admin" || access.role === "superadmin";
              const viewAll = isAdmin && url.searchParams.get("all") === "1";
              const ownerFilter = tool === "revenue-tracker" && !viewAll ? access.requester.email : null;
              let query = admin.from("org_dashboard_tool_entries").select("id, tool_key, title, details, status, event_date, amount_cents, metadata, created_by, updated_by, created_at, updated_at").eq("tool_key", tool);
              if (ownerFilter) {
                query = query.eq("created_by", ownerFilter);
              }
              query = query.order("event_date", { ascending: false, nullsFirst: false }).order("updated_at", { ascending: false });
              const { data, error } = await query;
              if (error) return Response.json({ error: error.message }, { status: 500 });
              return Response.json({
                requester: requesterPayload(access),
                tool,
                entries: data || []
              });
            } catch (error) {
              if (error instanceof Response) return error;
              return Response.json({ error: errorMessage(error, "Unexpected server error") }, { status: 500 });
            }
          },
          POST: async ({ request, params }) => {
            try {
              const { tool, access } = await authorizeForTool(request, params.tool);
              const admin = getDbClient(request);
              const body = await request.json();
              const parsed = createEntrySchema.safeParse(body);
              if (!parsed.success) {
                return Response.json({ error: "Invalid payload", details: parsed.error.flatten() }, { status: 400 });
              }
              const { data, error } = await admin.from("org_dashboard_tool_entries").insert({
                tool_key: tool,
                title: parsed.data.title,
                details: parsed.data.details,
                status: parsed.data.status,
                event_date: parsed.data.eventDate ?? null,
                amount_cents: parsed.data.amountCents ?? null,
                metadata: parsed.data.metadata || {},
                created_by: access.requester.email,
                updated_by: access.requester.email
              }).select("id, tool_key, title, details, status, event_date, amount_cents, metadata, created_by, updated_by, created_at, updated_at").single();
              if (error) return Response.json({ error: error.message }, { status: 500 });
              return Response.json({ entry: data });
            } catch (error) {
              if (error instanceof Response) return error;
              return Response.json({ error: errorMessage(error, "Unexpected server error") }, { status: 500 });
            }
          },
          PUT: async ({ request, params }) => {
            try {
              const { tool, access } = await authorizeForTool(request, params.tool);
              const admin = getDbClient(request);
              const body = await request.json();
              const parsed = updateEntrySchema.safeParse(body);
              if (!parsed.success) {
                return Response.json({ error: "Invalid payload", details: parsed.error.flatten() }, { status: 400 });
              }
              const isAdmin = access.role === "admin" || access.role === "superadmin";
              let updateQuery = admin.from("org_dashboard_tool_entries").update({
                title: parsed.data.title,
                details: parsed.data.details,
                status: parsed.data.status,
                event_date: parsed.data.eventDate ?? null,
                amount_cents: parsed.data.amountCents ?? null,
                metadata: parsed.data.metadata || {},
                updated_by: access.requester.email,
                updated_at: (/* @__PURE__ */ new Date()).toISOString()
              }).eq("id", parsed.data.id).eq("tool_key", tool);
              if (!isAdmin) {
                updateQuery = updateQuery.eq("created_by", access.requester.email);
              }
              const { data, error } = await updateQuery.select("id, tool_key, title, details, status, event_date, amount_cents, metadata, created_by, updated_by, created_at, updated_at").maybeSingle();
              if (error) return Response.json({ error: error.message }, { status: 500 });
              if (!data) {
                return Response.json({ error: "Entry not found or not allowed." }, { status: 404 });
              }
              return Response.json({ entry: data });
            } catch (error) {
              if (error instanceof Response) return error;
              return Response.json({ error: errorMessage(error, "Unexpected server error") }, { status: 500 });
            }
          },
          DELETE: async ({ request, params }) => {
            try {
              const { tool, access } = await authorizeForTool(request, params.tool);
              const admin = getDbClient(request);
              const body = await request.json();
              const parsed = deleteEntrySchema.safeParse(body);
              if (!parsed.success) {
                return Response.json({ error: "Invalid payload", details: parsed.error.flatten() }, { status: 400 });
              }
              const isAdmin = access.role === "admin" || access.role === "superadmin";
              let deleteQuery = admin.from("org_dashboard_tool_entries").delete().eq("id", parsed.data.id).eq("tool_key", tool);
              if (!isAdmin) {
                deleteQuery = deleteQuery.eq("created_by", access.requester.email);
              }
              const { data, error } = await deleteQuery.select("id");
              if (error) return Response.json({ error: error.message }, { status: 500 });
              if (!Array.isArray(data) || data.length === 0) {
                return Response.json({ error: "Entry not found or not allowed." }, { status: 404 });
              }
              return Response.json({ deleted: true });
            } catch (error) {
              if (error instanceof Response) return error;
              return Response.json({ error: errorMessage(error, "Unexpected server error") }, { status: 500 });
            }
          }
        }
      }
    });
    BUCKET = "merch-studio-media";
    ALLOWED_EXTENSIONS = /* @__PURE__ */ new Set([
      "jpg",
      "jpeg",
      "png",
      "gif",
      "webp",
      "mp4",
      "webm",
      "mov",
      "m4v",
      "obj",
      "fbx",
      "glb",
      "gltf",
      "stl"
    ]);
    MAX_SIZE = 120 * 1024 * 1024;
    Route$c = createFileRoute("/api/merch-studio/upload")({
      server: {
        handlers: {
          POST: async ({ request }) => {
            try {
              const isLocalRoot = request.headers.get("x-local-root-session") === "true" && isLocalRequest(request);
              let requesterEmail = null;
              if (!isLocalRoot) {
                const access = await requirePermission(request, "view_merch");
                if (access.role === "banned") {
                  return Response.json({ error: "Banned users cannot upload merch studio media." }, { status: 403 });
                }
                requesterEmail = access.requester.email;
              } else {
                requesterEmail = "root-superadmin@localhost";
              }
              const form = await request.formData();
              const file = form.get("file");
              if (!(file instanceof File)) {
                return Response.json({ error: "File is required." }, { status: 400 });
              }
              if (file.size <= 0) {
                return Response.json({ error: "File is empty." }, { status: 400 });
              }
              if (file.size > MAX_SIZE) {
                return Response.json(
                  { error: `File is too large. Maximum size is ${Math.floor(MAX_SIZE / (1024 * 1024))} MB.` },
                  { status: 413 }
                );
              }
              const ext = getExtension(file.name);
              if (!ALLOWED_EXTENSIONS.has(ext)) {
                return Response.json({ error: "Unsupported file type." }, { status: 400 });
              }
              const safeEmail = (requesterEmail || "member").replace(/[^a-z0-9._-]+/gi, "_");
              const stamp = Date.now();
              const random = Math.random().toString(36).slice(2, 10);
              const path = `${safeEmail}/${stamp}-${random}.${ext}`;
              const contentType = file.type || "application/octet-stream";
              const buffer = await file.arrayBuffer();
              if (hasSupabaseAdminConfig()) {
                const admin = getSupabaseAdminClient();
                const { error: uploadError2 } = await admin.storage.from(BUCKET).upload(path, buffer, { contentType, upsert: false });
                if (uploadError2) {
                  return Response.json({ error: uploadError2.message }, { status: 500 });
                }
                const { data: pub2 } = admin.storage.from(BUCKET).getPublicUrl(path);
                return Response.json({ url: pub2.publicUrl, path }, { status: 201 });
              }
              const authHeader = request.headers.get("authorization");
              const token = authHeader?.toLowerCase().startsWith("bearer ") ? authHeader.slice(7).trim() : void 0;
              if (!isLocalRoot && !token) {
                return Response.json(
                  { error: "Missing bearer token for upload in fallback mode." },
                  { status: 401 }
                );
              }
              const scopedClient = getSupabaseServerClientForToken(token);
              const { error: uploadError } = await scopedClient.storage.from(BUCKET).upload(path, buffer, { contentType, upsert: false });
              if (uploadError) {
                return Response.json({ error: uploadError.message }, { status: 500 });
              }
              const { data: pub } = scopedClient.storage.from(BUCKET).getPublicUrl(path);
              return Response.json({ url: pub.publicUrl, path }, { status: 201 });
            } catch (error) {
              if (error instanceof Response) return error;
              return Response.json(
                { error: error instanceof Error ? error.message : "Unexpected server error" },
                { status: 500 }
              );
            }
          }
        }
      }
    });
    createSubmissionSchema = z.object({
      title: z.string().trim().min(3).max(180),
      description: z.string().trim().min(10).max(5e3),
      submissionTarget: z.enum(["personal_store", "wage_shop"]),
      mediaUrls: z.array(z.string().url()).max(30).default([]),
      embedLinks: z.array(z.string().url()).max(30).default([]),
      externalStoreUrl: z.string().url().optional().or(z.literal(""))
    });
    adminReviewSchema = z.object({
      id: z.string().uuid(),
      status: z.enum(["under_review", "accepted", "denied"]),
      adminNotes: z.string().max(5e3).optional(),
      creatorSplitPercent: z.number().min(0).max(100),
      wageSplitPercent: z.number().min(0).max(100)
    });
    Route$b = createFileRoute("/api/merch-studio/submissions")({
      server: {
        handlers: {
          GET: async ({ request }) => {
            try {
              if (hasSupabaseAdminConfig()) {
                const access = await getRequesterAccess(request);
                if (access.role === "banned") {
                  return Response.json({ error: "Banned users cannot use Merch Studio." }, { status: 403 });
                }
                const canReview = access.isSuperadmin || access.permissions.includes("access_admin_dashboard");
                const admin = getSupabaseAdminClient();
                let query = admin.from("org_merch_studio_submissions").select("*").order("created_at", { ascending: false });
                if (!canReview) {
                  query = query.eq("creator_email", access.requester.email);
                }
                const { data: data2, error: error2 } = await query;
                if (error2) return Response.json({ error: error2.message }, { status: 500 });
                return Response.json({
                  canReview,
                  submissions: (data2 || []).map((row) => mapSubmission(row))
                });
              }
              const useLocalRoot = request.headers.get("x-local-root-session") === "true" && isLocalRequest(request);
              if (!useLocalRoot) {
                return Response.json(
                  { error: "Merch Studio currently requires SUPABASE_SERVICE_ROLE_KEY in this environment." },
                  { status: 503 }
                );
              }
              const client = getSupabaseServerPublicClient();
              const { data, error } = await client.from("org_merch_studio_submissions").select("*").order("created_at", { ascending: false });
              if (error) return Response.json({ error: error.message }, { status: 500 });
              return Response.json({
                canReview: true,
                submissions: (data || []).map((row) => mapSubmission(row))
              });
            } catch (error) {
              if (error instanceof Response) return error;
              return Response.json(
                { error: error instanceof Error ? error.message : "Unexpected server error" },
                { status: 500 }
              );
            }
          },
          POST: async ({ request }) => {
            try {
              if (!hasSupabaseAdminConfig()) {
                const useLocalRoot = request.headers.get("x-local-root-session") === "true" && isLocalRequest(request);
                if (!useLocalRoot) {
                  return Response.json(
                    { error: "Merch Studio submissions require SUPABASE_SERVICE_ROLE_KEY in this environment." },
                    { status: 503 }
                  );
                }
                const payload2 = createSubmissionSchema.safeParse(await request.json());
                if (!payload2.success) {
                  return Response.json({ error: payload2.error.flatten() }, { status: 400 });
                }
                const client = getSupabaseServerPublicClient();
                const { data: data2, error: error2 } = await client.from("org_merch_studio_submissions").insert([
                  {
                    creator_email: "root-superadmin@localhost",
                    title: payload2.data.title,
                    description: payload2.data.description,
                    submission_target: payload2.data.submissionTarget,
                    media_urls: payload2.data.mediaUrls,
                    embed_links: payload2.data.embedLinks,
                    external_store_url: payload2.data.externalStoreUrl || null,
                    status: "submitted"
                  }
                ]).select("*").single();
                if (error2) return Response.json({ error: error2.message }, { status: 500 });
                return Response.json({ submission: mapSubmission(data2) }, { status: 201 });
              }
              const access = await requirePermission(request, "view_merch");
              if (access.role === "banned") {
                return Response.json({ error: "Banned users cannot use Merch Studio." }, { status: 403 });
              }
              const payload = createSubmissionSchema.safeParse(await request.json());
              if (!payload.success) {
                return Response.json({ error: payload.error.flatten() }, { status: 400 });
              }
              const admin = getSupabaseAdminClient();
              const { data, error } = await admin.from("org_merch_studio_submissions").insert([
                {
                  creator_email: access.requester.email,
                  title: payload.data.title,
                  description: payload.data.description,
                  submission_target: payload.data.submissionTarget,
                  media_urls: payload.data.mediaUrls,
                  embed_links: payload.data.embedLinks,
                  external_store_url: payload.data.externalStoreUrl || null,
                  status: "submitted"
                }
              ]).select("*").single();
              if (error) return Response.json({ error: error.message }, { status: 500 });
              return Response.json({ submission: mapSubmission(data) }, { status: 201 });
            } catch (error) {
              if (error instanceof Response) return error;
              return Response.json(
                { error: error instanceof Error ? error.message : "Unexpected server error" },
                { status: 500 }
              );
            }
          },
          PUT: async ({ request }) => {
            try {
              const payload = adminReviewSchema.safeParse(await request.json());
              if (!payload.success) {
                return Response.json({ error: payload.error.flatten() }, { status: 400 });
              }
              if (Math.round((payload.data.creatorSplitPercent + payload.data.wageSplitPercent) * 100) !== 1e4) {
                return Response.json({ error: "Creator and WAGE split must add up to 100%." }, { status: 400 });
              }
              if (!hasSupabaseAdminConfig()) {
                const useLocalRoot = request.headers.get("x-local-root-session") === "true" && isLocalRequest(request);
                if (!useLocalRoot) {
                  return Response.json(
                    { error: "Merch Studio reviews require SUPABASE_SERVICE_ROLE_KEY in this environment." },
                    { status: 503 }
                  );
                }
                const client = getSupabaseServerPublicClient();
                const updatePayload2 = {
                  status: payload.data.status,
                  admin_notes: payload.data.adminNotes || null,
                  creator_split_percent: payload.data.creatorSplitPercent,
                  wage_split_percent: payload.data.wageSplitPercent,
                  approved_by: "root-superadmin@localhost",
                  approved_at: payload.data.status === "accepted" ? (/* @__PURE__ */ new Date()).toISOString() : null,
                  updated_at: (/* @__PURE__ */ new Date()).toISOString()
                };
                const { data: data2, error: error2 } = await client.from("org_merch_studio_submissions").update(updatePayload2).eq("id", payload.data.id).select("*").single();
                if (error2) return Response.json({ error: error2.message }, { status: 500 });
                return Response.json({ submission: mapSubmission(data2) });
              }
              const access = await requirePermission(request, "access_admin_dashboard");
              const admin = getSupabaseAdminClient();
              const updatePayload = {
                status: payload.data.status,
                admin_notes: payload.data.adminNotes || null,
                creator_split_percent: payload.data.creatorSplitPercent,
                wage_split_percent: payload.data.wageSplitPercent,
                approved_by: access.requester.email,
                approved_at: payload.data.status === "accepted" ? (/* @__PURE__ */ new Date()).toISOString() : null,
                updated_at: (/* @__PURE__ */ new Date()).toISOString()
              };
              const { data, error } = await admin.from("org_merch_studio_submissions").update(updatePayload).eq("id", payload.data.id).select("*").single();
              if (error) return Response.json({ error: error.message }, { status: 500 });
              return Response.json({ submission: mapSubmission(data) });
            } catch (error) {
              if (error instanceof Response) return error;
              return Response.json(
                { error: error instanceof Error ? error.message : "Unexpected server error" },
                { status: 500 }
              );
            }
          }
        }
      }
    });
    createEarningSchema = z.object({
      submissionId: z.string().uuid(),
      grossCents: z.number().int().min(0),
      periodStart: z.string().optional(),
      periodEnd: z.string().optional(),
      notes: z.string().max(5e3).optional()
    });
    updatePaidSchema = z.object({
      id: z.string().uuid(),
      paidToMemberCents: z.number().int().min(0),
      paidToWageCents: z.number().int().min(0)
    });
    Route$a = createFileRoute("/api/merch-studio/earnings")({
      server: {
        handlers: {
          GET: async ({ request }) => {
            try {
              if (hasSupabaseAdminConfig()) {
                const access = await getRequesterAccess(request);
                if (access.role === "banned") {
                  return Response.json({ error: "Banned users cannot use Merch Studio." }, { status: 403 });
                }
                const canReview = access.isSuperadmin || access.permissions.includes("access_admin_dashboard");
                const admin = getSupabaseAdminClient();
                let query = admin.from("org_merch_studio_earnings").select("id, submission_id, recorded_by, period_start, period_end, gross_cents, member_due_cents, wage_due_cents, paid_to_member_cents, paid_to_wage_cents, notes, created_at, updated_at").order("created_at", { ascending: false });
                if (!canReview) {
                  const { data: ownSubmissions, error: ownError } = await admin.from("org_merch_studio_submissions").select("id").eq("creator_email", access.requester.email);
                  if (ownError) {
                    return Response.json({ error: ownError.message }, { status: 500 });
                  }
                  const ids = (ownSubmissions || []).map((row) => row.id);
                  if (ids.length === 0) {
                    return Response.json({ canReview, earnings: [], summary: { memberDueCents: 0, memberPaidCents: 0, memberPendingCents: 0 } });
                  }
                  query = query.in("submission_id", ids);
                }
                const { data: data2, error: error2 } = await query;
                if (error2) return Response.json({ error: error2.message }, { status: 500 });
                const rawRows2 = data2 || [];
                const mapped2 = rawRows2.map(mapEarning);
                const summary2 = { memberDueCents: 0, memberPaidCents: 0, memberPendingCents: 0 };
                for (const entry of mapped2) {
                  summary2.memberDueCents += entry.memberDueCents;
                  summary2.memberPaidCents += entry.paidToMemberCents;
                  summary2.memberPendingCents += Math.max(0, entry.memberDueCents - entry.paidToMemberCents);
                }
                return Response.json({ canReview, earnings: mapped2, summary: summary2 });
              }
              const useLocalRoot = request.headers.get("x-local-root-session") === "true" && isLocalRequest(request);
              if (!useLocalRoot) {
                return Response.json(
                  { error: "Merch Studio earnings require SUPABASE_SERVICE_ROLE_KEY in this environment." },
                  { status: 503 }
                );
              }
              const client = getSupabaseServerPublicClient();
              const { data, error } = await client.from("org_merch_studio_earnings").select("id, submission_id, recorded_by, period_start, period_end, gross_cents, member_due_cents, wage_due_cents, paid_to_member_cents, paid_to_wage_cents, notes, created_at, updated_at").order("created_at", { ascending: false });
              if (error) return Response.json({ error: error.message }, { status: 500 });
              const rawRows = data || [];
              const mapped = rawRows.map(mapEarning);
              const summary = { memberDueCents: 0, memberPaidCents: 0, memberPendingCents: 0 };
              for (const entry of mapped) {
                summary.memberDueCents += entry.memberDueCents;
                summary.memberPaidCents += entry.paidToMemberCents;
                summary.memberPendingCents += Math.max(0, entry.memberDueCents - entry.paidToMemberCents);
              }
              return Response.json({ canReview: true, earnings: mapped, summary });
            } catch (error) {
              if (error instanceof Response) return error;
              return Response.json(
                { error: error instanceof Error ? error.message : "Unexpected server error" },
                { status: 500 }
              );
            }
          },
          POST: async ({ request }) => {
            try {
              const payload = createEarningSchema.safeParse(await request.json());
              if (!payload.success) {
                return Response.json({ error: payload.error.flatten() }, { status: 400 });
              }
              if (!hasSupabaseAdminConfig()) {
                const useLocalRoot = request.headers.get("x-local-root-session") === "true" && isLocalRequest(request);
                if (!useLocalRoot) {
                  return Response.json(
                    { error: "Recording earnings requires SUPABASE_SERVICE_ROLE_KEY in this environment." },
                    { status: 503 }
                  );
                }
                const client = getSupabaseServerPublicClient();
                const { data: submission2, error: submissionError2 } = await client.from("org_merch_studio_submissions").select("id, creator_email, title, creator_split_percent, wage_split_percent").eq("id", payload.data.submissionId).single();
                if (submissionError2) return Response.json({ error: submissionError2.message }, { status: 500 });
                const submissionRow2 = submission2;
                const memberDueCents2 = Math.round(payload.data.grossCents * (Number(submissionRow2.creator_split_percent) / 100));
                const wageDueCents2 = payload.data.grossCents - memberDueCents2;
                const { data: data2, error: error2 } = await client.from("org_merch_studio_earnings").insert([
                  {
                    submission_id: payload.data.submissionId,
                    recorded_by: "root-superadmin@localhost",
                    period_start: payload.data.periodStart || null,
                    period_end: payload.data.periodEnd || null,
                    gross_cents: payload.data.grossCents,
                    member_due_cents: memberDueCents2,
                    wage_due_cents: wageDueCents2,
                    notes: payload.data.notes || null
                  }
                ]).select("*").single();
                if (error2) return Response.json({ error: error2.message }, { status: 500 });
                return Response.json({ earning: mapEarning(data2) }, { status: 201 });
              }
              const access = await requirePermission(request, "access_admin_dashboard");
              const admin = getSupabaseAdminClient();
              const { data: submission, error: submissionError } = await admin.from("org_merch_studio_submissions").select("id, creator_email, title, creator_split_percent, wage_split_percent").eq("id", payload.data.submissionId).single();
              if (submissionError) return Response.json({ error: submissionError.message }, { status: 500 });
              const submissionRow = submission;
              const memberDueCents = Math.round(payload.data.grossCents * (Number(submissionRow.creator_split_percent) / 100));
              const wageDueCents = payload.data.grossCents - memberDueCents;
              const { data, error } = await admin.from("org_merch_studio_earnings").insert([
                {
                  submission_id: payload.data.submissionId,
                  recorded_by: access.requester.email,
                  period_start: payload.data.periodStart || null,
                  period_end: payload.data.periodEnd || null,
                  gross_cents: payload.data.grossCents,
                  member_due_cents: memberDueCents,
                  wage_due_cents: wageDueCents,
                  notes: payload.data.notes || null
                }
              ]).select("*").single();
              if (error) return Response.json({ error: error.message }, { status: 500 });
              return Response.json({ earning: mapEarning(data) }, { status: 201 });
            } catch (error) {
              if (error instanceof Response) return error;
              return Response.json(
                { error: error instanceof Error ? error.message : "Unexpected server error" },
                { status: 500 }
              );
            }
          },
          PUT: async ({ request }) => {
            try {
              const payload = updatePaidSchema.safeParse(await request.json());
              if (!payload.success) {
                return Response.json({ error: payload.error.flatten() }, { status: 400 });
              }
              if (!hasSupabaseAdminConfig()) {
                const useLocalRoot = request.headers.get("x-local-root-session") === "true" && isLocalRequest(request);
                if (!useLocalRoot) {
                  return Response.json(
                    { error: "Updating payout tracking requires SUPABASE_SERVICE_ROLE_KEY in this environment." },
                    { status: 503 }
                  );
                }
                const client = getSupabaseServerPublicClient();
                const { data: data2, error: error2 } = await client.from("org_merch_studio_earnings").update({
                  paid_to_member_cents: payload.data.paidToMemberCents,
                  paid_to_wage_cents: payload.data.paidToWageCents,
                  updated_at: (/* @__PURE__ */ new Date()).toISOString()
                }).eq("id", payload.data.id).select("*").single();
                if (error2) return Response.json({ error: error2.message }, { status: 500 });
                return Response.json({ earning: mapEarning(data2) });
              }
              await requirePermission(request, "access_admin_dashboard");
              const admin = getSupabaseAdminClient();
              const { data, error } = await admin.from("org_merch_studio_earnings").update({
                paid_to_member_cents: payload.data.paidToMemberCents,
                paid_to_wage_cents: payload.data.paidToWageCents,
                updated_at: (/* @__PURE__ */ new Date()).toISOString()
              }).eq("id", payload.data.id).select("*").single();
              if (error) return Response.json({ error: error.message }, { status: 500 });
              return Response.json({ earning: mapEarning(data) });
            } catch (error) {
              if (error instanceof Response) return error;
              return Response.json(
                { error: error instanceof Error ? error.message : "Unexpected server error" },
                { status: 500 }
              );
            }
          }
        }
      }
    });
    USERNAME_REGEX2 = /^[a-zA-Z0-9_-]{3,20}$/;
    updateSchema$2 = z.object({
      displayName: z.string().trim().max(20).optional(),
      avatarUrl: z.string().url().optional().or(z.literal("")),
      bio: z.string().trim().max(500).optional(),
      skills: z.array(z.string().trim().max(40)).max(30).optional(),
      selectedYouTubeChannel: z.string().trim().max(200).nullable().optional(),
      connectedKickUsername: z.string().trim().max(120).nullable().optional()
    });
    BUILTIN_OAUTH_PROVIDER_META = {
      discord: { label: "Discord", description: "Link your Discord account" },
      google: { label: "Google / YouTube", description: "Link your Google account" },
      kick: { label: "Kick", description: "Link your Kick account" },
      "custom:kick": { label: "Kick", description: "Link your Kick account" },
      apple: { label: "Apple", description: "Link your Apple account" },
      facebook: { label: "Facebook", description: "Link your Facebook account" }
    };
    Route$9 = createFileRoute("/api/me/profile")({
      server: {
        handlers: {
          GET: async ({ request }) => {
            try {
              const access = await requirePermission(request, "view_dashboard");
              const canUseAdmin = hasSupabaseAdminConfig();
              const token = getBearerToken$1(request);
              const client = canUseAdmin ? getSupabaseAdminClient() : token ? getSupabaseServerClientForToken(token) : getSupabaseServerPublicClient();
              const profilePromise = client.from("org_member_profiles").select("email, display_name, avatar_url, bio, skills, updated_at").eq("email", access.requester.email).maybeSingle();
              const authUserPromise = canUseAdmin ? getSupabaseAdminClient().schema("auth").from("users").select("id, raw_user_meta_data").eq("email", access.requester.email).maybeSingle() : token ? getSupabaseServerClientForToken(token).auth.getUser(token) : Promise.resolve({ data: { user: null }, error: null });
              const [{ data: profileRaw, error: profileError }, { data: authUser, error: authUserError }] = await Promise.all([
                profilePromise,
                authUserPromise
              ]);
              const profile = profileRaw || null;
              if (profileError && profileError.code !== "42P01") {
                return Response.json({ error: profileError.message }, { status: 500 });
              }
              if (authUserError) {
                return Response.json({ error: authUserError.message }, { status: 500 });
              }
              const oauthProviders = await getAvailableOAuthProviders(client, canUseAdmin);
              const authUserRecord = canUseAdmin ? authUser : authUser?.user;
              if (canUseAdmin && authUserRecord?.id) {
                const { data: identityRows, error: identityError } = await getSupabaseAdminClient().schema("auth").from("identities").select("provider, identity_data").eq("user_id", authUserRecord.id);
                if (identityError) {
                  return Response.json({ error: identityError.message }, { status: 500 });
                }
                authUserRecord.identities = Array.isArray(identityRows) ? identityRows : [];
              }
              const meta = authUserRecord?.raw_user_meta_data ?? authUserRecord?.user_metadata ?? null;
              const streamAccounts = buildConnectedStreamAccounts(meta, authUserRecord);
              const authDisplayName = readDisplayNameFromMeta(meta);
              return Response.json({
                oauth_providers: oauthProviders,
                stream_accounts: streamAccounts,
                profile: profile ? {
                  ...profile,
                  display_name: profile.display_name || authDisplayName,
                  livestream_links: [
                    ...streamAccounts.kick.url ? [streamAccounts.kick.url] : [],
                    ...streamAccounts.youtube.selected ? [streamKeyToYouTubeUrl(streamAccounts.youtube.selected)] : []
                  ]
                } : {
                  ...createFallbackProfile(access.requester.email, authDisplayName),
                  livestream_links: [
                    ...streamAccounts.kick.url ? [streamAccounts.kick.url] : [],
                    ...streamAccounts.youtube.selected ? [streamKeyToYouTubeUrl(streamAccounts.youtube.selected)] : []
                  ]
                }
              });
            } catch (error) {
              if (error instanceof Response) return error;
              return Response.json(
                { error: error instanceof Error ? error.message : "Unexpected server error" },
                { status: 500 }
              );
            }
          },
          PUT: async ({ request }) => {
            try {
              const access = await requirePermission(request, "view_dashboard");
              const body = await request.json();
              const parsed = updateSchema$2.safeParse(body);
              if (!parsed.success) {
                return Response.json({ error: "Invalid payload", details: parsed.error.flatten() }, { status: 400 });
              }
              const selectedYouTubeChannel = parsed.data.selectedYouTubeChannel !== void 0 ? normalizeYouTubeSelection(parsed.data.selectedYouTubeChannel) : void 0;
              if (parsed.data.selectedYouTubeChannel !== void 0 && parsed.data.selectedYouTubeChannel !== null && !selectedYouTubeChannel) {
                return Response.json({ error: "Invalid YouTube channel selection." }, { status: 400 });
              }
              const connectedKickUsername = parsed.data.connectedKickUsername !== void 0 ? String(parsed.data.connectedKickUsername || "").trim().replace(/^@/, "") || null : void 0;
              const canUseAdmin = hasSupabaseAdminConfig();
              const token = getBearerToken$1(request);
              const client = canUseAdmin ? getSupabaseAdminClient() : getSupabaseServerClientForToken(token);
              let authUserList = [];
              if (canUseAdmin) {
                const { data: authUsers, error: authUsersError } = await getSupabaseAdminClient().schema("auth").from("users").select("id, email, raw_user_meta_data");
                if (authUsersError) {
                  return Response.json({ error: authUsersError.message }, { status: 500 });
                }
                authUserList = Array.isArray(authUsers) ? authUsers : [];
              }
              if (parsed.data.displayName !== void 0) {
                const newName = parsed.data.displayName.trim();
                if (newName && !USERNAME_REGEX2.test(newName)) {
                  return Response.json(
                    { error: "Username must be 3\u201320 characters and contain only letters, numbers, underscores, or hyphens." },
                    { status: 400 }
                  );
                }
                if (newName) {
                  const { data: existing, error: checkError } = await client.from("org_member_profiles").select("email").ilike("display_name", newName).neq("email", access.requester.email).limit(1);
                  if (checkError && checkError.code !== "42P01") {
                    return Response.json({ error: "Could not verify username availability." }, { status: 500 });
                  }
                  if (Array.isArray(existing) && existing.length > 0) {
                    return Response.json({ error: "That username is already taken. Please choose another." }, { status: 409 });
                  }
                  if (canUseAdmin) {
                    const normalized = newName.toLowerCase();
                    const takenInAuth = authUserList.some((userRow) => {
                      const rowEmail = String(userRow.email || "").toLowerCase();
                      if (!rowEmail || rowEmail === access.requester.email) return false;
                      const metadata = userRow.raw_user_meta_data ?? null;
                      const candidates = [metadata?.username, metadata?.preferred_username];
                      return candidates.some((candidate) => candidate?.trim().toLowerCase() === normalized);
                    });
                    if (takenInAuth) {
                      return Response.json({ error: "That username is already taken. Please choose another." }, { status: 409 });
                    }
                  }
                }
              }
              const currentAuthUser = authUserList.find(
                (userRow) => String(userRow.email || "").toLowerCase() === access.requester.email
              );
              if (canUseAdmin && currentAuthUser?.id && (parsed.data.displayName !== void 0 || selectedYouTubeChannel !== void 0 || connectedKickUsername !== void 0)) {
                const existingMeta = currentAuthUser.raw_user_meta_data ?? {};
                const trimmedDisplayName = parsed.data.displayName?.trim() || "";
                const nextName = trimmedDisplayName || readDisplayNameFromMeta(existingMeta) || "";
                const { error: updateAuthError } = await getSupabaseAdminClient().auth.admin.updateUserById(currentAuthUser.id, {
                  user_metadata: {
                    ...existingMeta,
                    username: nextName,
                    preferred_username: nextName,
                    selected_youtube_channel: selectedYouTubeChannel !== void 0 ? selectedYouTubeChannel : existingMeta.selected_youtube_channel || null,
                    kick_username: connectedKickUsername !== void 0 ? connectedKickUsername : existingMeta.kick_username || null
                  }
                });
                if (updateAuthError) {
                  return Response.json({ error: updateAuthError.message }, { status: 500 });
                }
              }
              if (!canUseAdmin && token && (parsed.data.displayName !== void 0 || selectedYouTubeChannel !== void 0 || connectedKickUsername !== void 0)) {
                const userClient = getSupabaseServerClientForToken(token);
                const {
                  data: { user: tokenUser },
                  error: tokenUserError
                } = await userClient.auth.getUser(token);
                if (tokenUserError || !tokenUser?.email) {
                  return Response.json({ error: tokenUserError?.message || "Could not resolve current user" }, { status: 401 });
                }
                if (String(tokenUser.email).trim().toLowerCase() !== access.requester.email) {
                  return Response.json({ error: "Metadata update email mismatch" }, { status: 403 });
                }
                const existingMeta = tokenUser.user_metadata ?? {};
                const trimmedDisplayName = parsed.data.displayName?.trim() || "";
                const nextName = trimmedDisplayName || readDisplayNameFromMeta(existingMeta) || "";
                const { error: updateAuthError } = await userClient.auth.updateUser({
                  data: {
                    ...existingMeta,
                    username: nextName,
                    preferred_username: nextName,
                    selected_youtube_channel: selectedYouTubeChannel !== void 0 ? selectedYouTubeChannel : existingMeta.selected_youtube_channel || null,
                    kick_username: connectedKickUsername !== void 0 ? connectedKickUsername : existingMeta.kick_username || null
                  }
                });
                if (updateAuthError) {
                  return Response.json({ error: updateAuthError.message }, { status: 500 });
                }
              }
              const payload = {
                email: access.requester.email,
                updated_at: (/* @__PURE__ */ new Date()).toISOString()
              };
              if (parsed.data.displayName !== void 0) {
                payload.display_name = parsed.data.displayName;
              }
              if (parsed.data.avatarUrl !== void 0) payload.avatar_url = parsed.data.avatarUrl || null;
              if (parsed.data.bio !== void 0) payload.bio = parsed.data.bio;
              if (parsed.data.skills !== void 0) payload.skills = parsed.data.skills;
              const { data, error } = await client.from("org_member_profiles").upsert(payload, { onConflict: "email" }).select("email, display_name, avatar_url, bio, skills, updated_at").single();
              if (error && error.code !== "42P01") {
                return Response.json({ error: error.message }, { status: 500 });
              }
              if (data) {
                const ownAuthMeta2 = currentAuthUser?.raw_user_meta_data ?? null;
                const streamAccounts = buildConnectedStreamAccounts(ownAuthMeta2, null);
                return Response.json({
                  profile: {
                    ...data,
                    livestream_links: [
                      ...streamAccounts.kick.url ? [streamAccounts.kick.url] : [],
                      ...streamAccounts.youtube.selected ? [streamKeyToYouTubeUrl(streamAccounts.youtube.selected)] : []
                    ]
                  }
                });
              }
              const ownAuthMeta = currentAuthUser?.raw_user_meta_data ?? null;
              const fallbackDisplayName = parsed.data.displayName?.trim() || readDisplayNameFromMeta(ownAuthMeta);
              return Response.json({
                profile: {
                  ...createFallbackProfile(access.requester.email, fallbackDisplayName || null),
                  livestream_links: [
                    ...ownAuthMeta?.kick_username ? [`https://kick.com/${String(ownAuthMeta.kick_username).replace(/^@/, "")}`] : [],
                    ...ownAuthMeta?.selected_youtube_channel ? [streamKeyToYouTubeUrl(String(ownAuthMeta.selected_youtube_channel))] : []
                  ]
                }
              });
            } catch (error) {
              if (error instanceof Response) return error;
              return Response.json(
                { error: error instanceof Error ? error.message : "Unexpected server error" },
                { status: 500 }
              );
            }
          }
        }
      }
    });
    Route$8 = createFileRoute("/api/me/access")({
      server: {
        handlers: {
          GET: async ({ request }) => {
            try {
              const access = await getRequesterAccess(request);
              return Response.json({
                requester: access.requester,
                role: access.role,
                actorRole: access.actorRole,
                viewingAs: access.viewingAs,
                permissions: access.permissions,
                isSuperadmin: access.isSuperadmin,
                ban: access.ban
              });
            } catch (error) {
              if (error instanceof Response) return error;
              return Response.json({ error: "Unexpected server error" }, { status: 500 });
            }
          }
        }
      }
    });
    kickTokenCache = null;
    OFFLINE_SNAPSHOT = {
      status: "offline",
      viewerCount: null,
      followerCount: null,
      accountCreatedAt: null
    };
    addStreamSchema = z.object({
      url: z.string().url(),
      title: z.string().max(120).optional()
    });
    removeStreamSchema = z.object({
      id: z.string().uuid()
    });
    URL_REGEX = /https?:\/\/[^\s)]+/gi;
    Route$7 = createFileRoute("/api/live/streams")({
      server: {
        handlers: {
          GET: async ({ request }) => {
            try {
              const client = hasSupabaseAdminConfig() ? getSupabaseAdminClient() : getSupabaseServerPublicClient();
              const users = await listAuthIndexedUsers(client);
              const { data: profileRows } = await client.from("org_member_profiles").select("email, display_name, bio, updated_at").limit(1e4);
              const profileByEmail = new Map(
                (profileRows || []).map((row) => [String(row.email || "").trim().toLowerCase(), row])
              );
              const autoStreams = [];
              for (const row of users) {
                const email = String(row.email || "").trim().toLowerCase();
                if (!row.id || !email) continue;
                const profile = profileByEmail.get(email);
                const candidates = parseAutoCandidates(collectCandidateUrls(row.user_metadata ?? null, profile));
                if (candidates.length === 0) continue;
                const streamCandidates = await Promise.all(
                  candidates.map(async (candidate) => {
                    const snapshot = await getLivestreamSnapshot(candidate.platform, candidate.stream_key);
                    return {
                      id: `auto-${row.id}-${candidate.platform}-${candidate.stream_key}`,
                      url: candidate.url,
                      title: profile?.display_name?.trim() || email.split("@")[0] || null,
                      platform: candidate.platform,
                      stream_key: candidate.stream_key,
                      created_by: email,
                      created_at: row.created_at || (/* @__PURE__ */ new Date()).toISOString(),
                      updated_at: profile?.updated_at || row.updated_at || row.created_at || (/* @__PURE__ */ new Date()).toISOString(),
                      status: snapshot.status,
                      viewer_count: snapshot.viewerCount,
                      follower_count: snapshot.followerCount,
                      account_created_at: snapshot.accountCreatedAt
                    };
                  })
                );
                const best = pickMostEngaged(streamCandidates);
                if (best) {
                  autoStreams.push(best);
                }
              }
              let requesterEmail = "anonymous";
              let requesterSource = "none";
              let canManage = false;
              let canUseAutoclipper = false;
              const autoclipperEnabled = hasSupabaseAdminConfig();
              const authHeader = request.headers.get("authorization") || "";
              const token = authHeader.startsWith("Bearer ") ? authHeader.slice(7).trim() : "";
              const useLocalRoot = request.headers.get("x-local-root-session") === "true" && isLocalRequest(request);
              if (useLocalRoot) {
                requesterEmail = "root-superadmin@localhost";
                requesterSource = "localhost-bypass";
                canManage = true;
                canUseAutoclipper = autoclipperEnabled;
              } else if (token) {
                try {
                  const access = await getRequesterAccess(request);
                  requesterEmail = access.requester.email;
                  requesterSource = access.requester.source;
                  canManage = access.isSuperadmin || access.permissions.includes("manage_livestreams");
                  canUseAutoclipper = autoclipperEnabled && (access.isSuperadmin || access.permissions.includes("use_autoclipper"));
                } catch {
                }
              }
              const sortedStreams = [...autoStreams].sort((a, b) => {
                const aLive = a.status === "live" ? 1 : 0;
                const bLive = b.status === "live" ? 1 : 0;
                if (aLive !== bLive) return bLive - aLive;
                const aViewers = a.viewer_count || 0;
                const bViewers = b.viewer_count || 0;
                if (aViewers !== bViewers) return bViewers - aViewers;
                return new Date(b.updated_at).getTime() - new Date(a.updated_at).getTime();
              });
              return Response.json({
                requester: {
                  email: requesterEmail,
                  source: requesterSource
                },
                canManage,
                canUseAutoclipper,
                streams: sortedStreams
              });
            } catch (error) {
              if (error instanceof Response) return error;
              return Response.json(
                { error: error instanceof Error ? error.message : "Unexpected server error" },
                { status: 500 }
              );
            }
          },
          POST: async ({ request }) => {
            try {
              const body = await request.json();
              const parsed = addStreamSchema.safeParse(body);
              if (!parsed.success) {
                return Response.json({ error: "Invalid payload", details: parsed.error.flatten() }, { status: 400 });
              }
              const stream = parseLivestreamLink(parsed.data.url);
              if (!hasSupabaseAdminConfig()) {
                const useLocalRoot = request.headers.get("x-local-root-session") === "true" && isLocalRequest(request);
                if (!useLocalRoot) {
                  return Response.json(
                    { error: "Admin livestream management requires SUPABASE_SERVICE_ROLE_KEY in this environment." },
                    { status: 503 }
                  );
                }
                const client = getSupabaseServerPublicClient();
                const { data: data2, error: error2 } = await client.rpc("add_org_livestream", {
                  p_url: parsed.data.url,
                  p_title: parsed.data.title || null,
                  p_platform: stream.platform,
                  p_stream_key: stream.streamKey,
                  p_created_by: "root-superadmin@localhost"
                });
                if (error2) {
                  return Response.json({ error: error2.message }, { status: 500 });
                }
                return Response.json({ stream: data2?.[0] || null });
              }
              const { requester } = await requirePermission(request, "manage_livestreams");
              const admin = getSupabaseAdminClient();
              const { data, error } = await admin.rpc("add_org_livestream", {
                p_url: parsed.data.url,
                p_title: parsed.data.title || null,
                p_platform: stream.platform,
                p_stream_key: stream.streamKey,
                p_created_by: requester.email
              });
              if (error) {
                return Response.json({ error: error.message }, { status: 500 });
              }
              return Response.json({ stream: data?.[0] || null });
            } catch (error) {
              if (error instanceof Response) return error;
              if (error instanceof Error) {
                return Response.json({ error: error.message }, { status: 400 });
              }
              return Response.json({ error: "Unexpected server error" }, { status: 500 });
            }
          },
          DELETE: async ({ request }) => {
            try {
              const body = await request.json();
              const parsed = removeStreamSchema.safeParse(body);
              if (!parsed.success) {
                return Response.json({ error: "Invalid payload", details: parsed.error.flatten() }, { status: 400 });
              }
              if (!hasSupabaseAdminConfig()) {
                const useLocalRoot = request.headers.get("x-local-root-session") === "true" && isLocalRequest(request);
                if (!useLocalRoot) {
                  return Response.json(
                    { error: "Admin livestream management requires SUPABASE_SERVICE_ROLE_KEY in this environment." },
                    { status: 503 }
                  );
                }
                const client = getSupabaseServerPublicClient();
                const { data: data2, error: error2 } = await client.rpc("delete_org_livestream", {
                  p_id: parsed.data.id
                });
                if (error2) {
                  return Response.json({ error: error2.message }, { status: 500 });
                }
                return Response.json({ deleted: !!data2 });
              }
              await requirePermission(request, "manage_livestreams");
              const admin = getSupabaseAdminClient();
              const { data, error } = await admin.rpc("delete_org_livestream", {
                p_id: parsed.data.id
              });
              if (error) {
                return Response.json({ error: error.message }, { status: 500 });
              }
              return Response.json({ deleted: !!data });
            } catch (error) {
              if (error instanceof Response) return error;
              return Response.json(
                { error: error instanceof Error ? error.message : "Unexpected server error" },
                { status: 500 }
              );
            }
          }
        }
      }
    });
    createSchema = z.object({
      commandText: z.string().trim().default("!clip"),
      streamPlatform: z.enum(["kick", "twitch", "youtube"]).optional(),
      streamKey: z.string().trim().max(120).optional(),
      autoPost: z.boolean().default(true),
      autoCaption: z.boolean().default(true),
      platforms: z.array(z.string()).max(10).default(["x", "kick", "instagram"]),
      clipWindowMinutes: z.number().int().min(1).max(15).default(5)
    });
    updateSchema$1 = z.object({
      id: z.string().uuid(),
      status: z.enum(["queued", "processing", "ready", "posted", "failed"]),
      clipUrl: z.string().url().optional(),
      error: z.string().max(500).optional()
    });
    chatSchema = z.object({
      message: z.string().trim().min(1),
      user: z.string().trim().min(1).default("chat-bot@system.local"),
      streamPlatform: z.enum(["kick", "twitch", "youtube"]).optional(),
      streamKey: z.string().trim().max(120).optional(),
      autoPost: z.boolean().default(true),
      autoCaption: z.boolean().default(true),
      platforms: z.array(z.string()).max(10).default(["x", "kick", "instagram"])
    });
    AUTOCLIPPER_DISABLED_MESSAGE = "Autoclipper is disabled in this environment because SUPABASE_SERVICE_ROLE_KEY is not configured.";
    Route$6 = createFileRoute("/api/live/clips")({
      server: {
        handlers: {
          GET: async ({ request }) => {
            try {
              if (!hasSupabaseAdminConfig()) {
                return Response.json({ error: AUTOCLIPPER_DISABLED_MESSAGE }, { status: 503 });
              }
              if (hasWebhookSecret(request)) {
                const rows2 = await fetchAutoclipRows(20);
                const jobs2 = mapRowsToJobs(rows2);
                return Response.json({ jobs: jobs2 });
              }
              const access = await requirePermission(request, "use_autoclipper");
              const rows = await fetchAutoclipRows(100);
              const jobs = mapRowsToJobs(rows);
              return Response.json({
                requester: {
                  ...access.requester,
                  role: access.role
                },
                jobs
              });
            } catch (error) {
              if (error instanceof Response) return error;
              const message = error instanceof Error ? error.message : "Unexpected server error";
              return Response.json({ error: message }, { status: 500 });
            }
          },
          POST: async ({ request }) => {
            try {
              if (!hasSupabaseAdminConfig()) {
                return Response.json({ error: AUTOCLIPPER_DISABLED_MESSAGE }, { status: 503 });
              }
              const body = await request.json();
              if (hasWebhookSecret(request)) {
                const parsedChat = chatSchema.safeParse(body);
                if (!parsedChat.success) {
                  return Response.json({ error: "Invalid payload", details: parsedChat.error.flatten() }, { status: 400 });
                }
                if (!parsedChat.data.message.toLowerCase().startsWith("!clip")) {
                  return Response.json({ ignored: true, reason: "Message is not a !clip command." });
                }
                const result2 = await createAutoclipperJob({
                  requestedBy: parsedChat.data.user,
                  source: "chat",
                  commandText: parsedChat.data.message,
                  streamPlatform: parsedChat.data.streamPlatform || null,
                  streamKey: parsedChat.data.streamKey || null,
                  autoPost: parsedChat.data.autoPost,
                  autoCaption: parsedChat.data.autoCaption,
                  platforms: parsedChat.data.platforms,
                  clipWindowMinutes: 5
                });
                return Response.json({ ok: true, ...result2 });
              }
              const access = await requirePermission(request, "use_autoclipper");
              const parsed = createSchema.safeParse(body);
              if (!parsed.success) {
                return Response.json({ error: "Invalid payload", details: parsed.error.flatten() }, { status: 400 });
              }
              const commandText = parsed.data.commandText || "!clip";
              if (!commandText.toLowerCase().startsWith("!clip")) {
                return Response.json({ error: "commandText must begin with !clip" }, { status: 400 });
              }
              const result = await createAutoclipperJob({
                requestedBy: access.requester.email,
                source: "dashboard",
                commandText,
                streamPlatform: parsed.data.streamPlatform || null,
                streamKey: parsed.data.streamKey || null,
                autoPost: parsed.data.autoPost,
                autoCaption: parsed.data.autoCaption,
                platforms: parsed.data.platforms,
                clipWindowMinutes: parsed.data.clipWindowMinutes
              });
              return Response.json({ ok: true, ...result });
            } catch (error) {
              if (error instanceof Response) return error;
              const message = error instanceof Error ? error.message : "Unexpected server error";
              return Response.json({ error: message }, { status: 500 });
            }
          },
          PUT: async ({ request }) => {
            try {
              if (!hasSupabaseAdminConfig()) {
                return Response.json({ error: AUTOCLIPPER_DISABLED_MESSAGE }, { status: 503 });
              }
              const body = await request.json();
              const parsed = updateSchema$1.safeParse(body);
              if (!parsed.success) {
                return Response.json({ error: "Invalid payload", details: parsed.error.flatten() }, { status: 400 });
              }
              if (hasWebhookSecret(request)) {
                await updateAutoclipJobStatus({
                  id: parsed.data.id,
                  status: parsed.data.status,
                  clipUrl: parsed.data.clipUrl,
                  error: parsed.data.error,
                  updatedBy: "discord-bot"
                });
                return Response.json({ ok: true });
              }
              const access = await requirePermission(request, "manage_livestreams");
              await updateAutoclipJobStatus({
                id: parsed.data.id,
                status: parsed.data.status,
                clipUrl: parsed.data.clipUrl,
                error: parsed.data.error,
                updatedBy: access.requester.email
              });
              return Response.json({ ok: true });
            } catch (error) {
              if (error instanceof Response) return error;
              const message = error instanceof Error ? error.message : "Unexpected server error";
              return Response.json({ error: message }, { status: 500 });
            }
          }
        }
      }
    });
    applySchema = z.object({
      requestId: z.string().uuid(),
      message: z.string().trim().max(500).default("")
    });
    Route$5 = createFileRoute("/api/collab/apply")({
      server: {
        handlers: {
          /**
           * POST /api/collab/apply
           * Body: { requestId, message? }
           * Creates or refreshes an application.
           */
          POST: async ({ request }) => {
            try {
              const access = await requirePermission(request, "view_creator_tools");
              const body = await request.json();
              const parsed = applySchema.safeParse(body);
              if (!parsed.success) {
                return Response.json({ error: "Invalid payload" }, { status: 400 });
              }
              const admin = getSupabaseAdminClient();
              const { data: req, error: reqError } = await admin.from("org_collab_requests").select("id, owner_email, status").eq("id", parsed.data.requestId).eq("status", "open").maybeSingle();
              if (reqError) return Response.json({ error: reqError.message }, { status: 500 });
              if (!req) return Response.json({ error: "Collab request not found or closed." }, { status: 404 });
              if (req.owner_email === access.requester.email) {
                return Response.json({ error: "You cannot apply to your own request." }, { status: 400 });
              }
              const { data, error } = await admin.from("org_collab_applications").upsert(
                {
                  request_id: parsed.data.requestId,
                  applicant_email: access.requester.email,
                  message: parsed.data.message,
                  status: "pending"
                },
                { onConflict: "request_id,applicant_email" }
              ).select("id, status").single();
              if (error) return Response.json({ error: error.message }, { status: 500 });
              return Response.json({ application: data });
            } catch (error) {
              if (error instanceof Response) return error;
              return Response.json({ error: "Unexpected server error" }, { status: 500 });
            }
          },
          /**
           * GET /api/collab/apply
           * Returns all applications the current user has submitted.
           */
          GET: async ({ request }) => {
            try {
              const access = await requirePermission(request, "view_creator_tools");
              const admin = getSupabaseAdminClient();
              const { data, error } = await admin.from("org_collab_applications").select("id, request_id, message, status, applied_at").eq("applicant_email", access.requester.email).order("applied_at", { ascending: false });
              if (error && error.code !== "42P01") {
                return Response.json({ error: error.message }, { status: 500 });
              }
              const apps = data || [];
              const requestIds = apps.map((a) => a.request_id);
              let requestMap = {};
              if (requestIds.length) {
                const { data: reqs } = await admin.from("org_collab_requests").select("id, title, owner_email").in("id", requestIds);
                for (const r of reqs || []) {
                  requestMap[r.id] = { title: r.title, owner_email: r.owner_email };
                }
              }
              return Response.json({
                applications: apps.map((a) => ({
                  ...a,
                  requestTitle: requestMap[a.request_id]?.title || null,
                  requestOwner: requestMap[a.request_id]?.owner_email || null
                }))
              });
            } catch (error) {
              if (error instanceof Response) return error;
              return Response.json({ error: "Unexpected server error" }, { status: 500 });
            }
          }
        }
      }
    });
    updateSchema = z.object({
      applicationId: z.string().uuid(),
      status: z.enum(["accepted", "rejected"])
    });
    Route$4 = createFileRoute("/api/collab/applicants")({
      server: {
        handlers: {
          /**
           * GET /api/collab/applicants?requestId=<uuid>
           * Returns applicants for the given request (owner/admin only).
           * Each applicant includes their public profile.
           */
          GET: async ({ request }) => {
            try {
              const access = await requirePermission(request, "view_creator_tools");
              const url = new URL(request.url);
              const requestId = url.searchParams.get("requestId");
              if (!requestId) return Response.json({ error: "requestId is required" }, { status: 400 });
              const admin = getSupabaseAdminClient();
              const isAdmin = access.role === "admin" || access.role === "superadmin";
              if (!isAdmin) {
                const { data: req } = await admin.from("org_collab_requests").select("owner_email").eq("id", requestId).maybeSingle();
                const owner = req?.owner_email;
                if (!owner || owner !== access.requester.email) {
                  return Response.json({ error: "Not authorized" }, { status: 403 });
                }
              }
              const { data, error } = await admin.from("org_collab_applications").select("id, applicant_email, message, status, applied_at").eq("request_id", requestId).order("applied_at", { ascending: true });
              if (error) return Response.json({ error: error.message }, { status: 500 });
              const applicants = data || [];
              const emails = applicants.map((a) => a.applicant_email);
              let profiles = {};
              if (emails.length) {
                const { data: profileData } = await admin.from("org_member_profiles").select("email, display_name, avatar_url, bio, skills").in("email", emails);
                for (const p of profileData || []) {
                  profiles[p.email] = p;
                }
              }
              return Response.json({
                applicants: applicants.map((a) => ({
                  ...a,
                  profile: profiles[a.applicant_email] || null
                }))
              });
            } catch (error) {
              if (error instanceof Response) return error;
              return Response.json({ error: "Unexpected server error" }, { status: 500 });
            }
          },
          /**
           * PUT /api/collab/applicants
           * Body: { applicationId, status: 'accepted' | 'rejected' }
           * Owner accepts/rejects an application.
           */
          PUT: async ({ request }) => {
            try {
              const access = await requirePermission(request, "view_creator_tools");
              const body = await request.json();
              const parsed = updateSchema.safeParse(body);
              if (!parsed.success) {
                return Response.json({ error: "Invalid payload" }, { status: 400 });
              }
              const admin = getSupabaseAdminClient();
              const isAdmin = access.role === "admin" || access.role === "superadmin";
              const { data: app } = await admin.from("org_collab_applications").select("id, request_id").eq("id", parsed.data.applicationId).maybeSingle();
              if (!app) return Response.json({ error: "Application not found" }, { status: 404 });
              if (!isAdmin) {
                const { data: req } = await admin.from("org_collab_requests").select("owner_email").eq("id", app.request_id).maybeSingle();
                const owner = req?.owner_email;
                if (!owner || owner !== access.requester.email) {
                  return Response.json({ error: "Not authorized" }, { status: 403 });
                }
              }
              const { error } = await admin.from("org_collab_applications").update({ status: parsed.data.status }).eq("id", parsed.data.applicationId);
              if (error) return Response.json({ error: error.message }, { status: 500 });
              return Response.json({ updated: true });
            } catch (error) {
              if (error instanceof Response) return error;
              return Response.json({ error: "Unexpected server error" }, { status: 500 });
            }
          }
        }
      }
    });
    setRoleSchema = z.object({
      targetEmail: z.string().email(),
      role: z.enum(ORG_ROLES),
      banReason: z.string().trim().max(500).nullable().optional(),
      bannedUntil: z.string().datetime({ offset: true }).nullable().optional()
    });
    setSubscriptionSchema = z.object({
      targetEmail: z.string().email(),
      membershipPlan: z.string().trim().min(1).max(80)
    });
    Route$3 = createFileRoute("/api/admin/roles")({
      server: {
        handlers: {
          GET: async ({ request }) => {
            try {
              const access = await getRequesterAccess(request);
              if (!access.isSuperadmin && !access.permissions.includes("manage_users")) {
                return Response.json({ error: "Manage users permission required" }, { status: 403 });
              }
              const admin = getAdminOrRequestClient(request);
              const { data, error } = await admin.rpc("list_org_member_roles");
              if (error) {
                return Response.json({ error: error.message }, { status: 500 });
              }
              const roleRows = Array.isArray(data) ? data || [] : [];
              const existingEmails = new Set(roleRows.map((row) => String(row.email || "").trim().toLowerCase()).filter(Boolean));
              let mergedRoles = [...roleRows];
              const inferredRows = [];
              let authUsers = await listAuthIndexedUsers(admin);
              if (hasSupabaseAdminConfig()) {
                const adminClient2 = getSupabaseAdminClient();
                const directAuthUsers = [];
                let page = 1;
                const perPage = 1e3;
                while (page <= 10) {
                  const { data: usersData, error: usersError } = await adminClient2.auth.admin.listUsers({ page, perPage });
                  if (usersError) break;
                  const pageUsers = usersData?.users || [];
                  if (!pageUsers.length) break;
                  directAuthUsers.push(...pageUsers);
                  if (pageUsers.length < perPage) break;
                  page += 1;
                }
                if (directAuthUsers.length > 0) {
                  const mergedAuthByEmail = /* @__PURE__ */ new Map();
                  for (const indexedUser of authUsers) {
                    const email = String(indexedUser.email || "").trim().toLowerCase();
                    if (!email) continue;
                    mergedAuthByEmail.set(email, {
                      id: String(indexedUser.id || email),
                      email,
                      created_at: indexedUser.created_at || indexedUser.updated_at || (/* @__PURE__ */ new Date()).toISOString(),
                      updated_at: indexedUser.updated_at || indexedUser.created_at || (/* @__PURE__ */ new Date()).toISOString(),
                      user_metadata: indexedUser.user_metadata
                    });
                  }
                  for (const directUser of directAuthUsers) {
                    const email = String(directUser.email || "").trim().toLowerCase();
                    if (!email) continue;
                    mergedAuthByEmail.set(email, {
                      id: String(directUser.id || email),
                      email,
                      created_at: directUser.created_at || directUser.updated_at || (/* @__PURE__ */ new Date()).toISOString(),
                      updated_at: directUser.updated_at || directUser.created_at || (/* @__PURE__ */ new Date()).toISOString(),
                      user_metadata: directUser.user_metadata || null
                    });
                  }
                  authUsers = Array.from(mergedAuthByEmail.values()).map((user) => ({
                    id: user.id,
                    email: user.email,
                    created_at: user.created_at,
                    updated_at: user.updated_at,
                    user_metadata: user.user_metadata,
                    identities: null
                  }));
                }
              }
              if (authUsers.length === 0 && hasSupabaseAdminConfig()) {
                const adminClient2 = getSupabaseAdminClient();
                const fallbackUsers = [];
                let page = 1;
                const perPage = 1e3;
                while (page <= 10) {
                  const { data: usersData, error: usersError } = await adminClient2.auth.admin.listUsers({ page, perPage });
                  if (usersError) break;
                  const pageUsers = usersData?.users || [];
                  if (!pageUsers.length) break;
                  fallbackUsers.push(...pageUsers);
                  if (pageUsers.length < perPage) break;
                  page += 1;
                }
                authUsers = fallbackUsers.map((user) => ({
                  id: String(user.id || user.email || "").toLowerCase(),
                  email: user.email,
                  created_at: user.created_at,
                  updated_at: user.updated_at || user.created_at,
                  user_metadata: user.user_metadata || null,
                  identities: null
                }));
              }
              const authUsersByEmail = new Map(
                authUsers.map((user) => [String(user.email || "").trim().toLowerCase(), user]).filter(([email]) => Boolean(email))
              );
              const permissionCache = /* @__PURE__ */ new Map();
              const collectPermissionsForRole = async (targetRole) => {
                if (permissionCache.has(targetRole)) {
                  return permissionCache.get(targetRole) || [];
                }
                const { data: permsData, error: permsError } = await admin.rpc("list_org_permissions_for_role", {
                  p_role: targetRole
                });
                if (permsError) {
                  permissionCache.set(targetRole, []);
                  return [];
                }
                const keys = Array.isArray(permsData) ? permsData.map((row) => String(row?.permission_key || "").trim()).filter(Boolean) : [];
                permissionCache.set(targetRole, keys);
                return keys;
              };
              const indexInferredRows = authUsers.map((row) => {
                const email = String(row.email || "").trim().toLowerCase();
                if (!email || existingEmails.has(email)) return null;
                existingEmails.add(email);
                const createdAt = row.created_at || row.updated_at || (/* @__PURE__ */ new Date()).toISOString();
                const updatedAt = row.updated_at || row.created_at || createdAt;
                return {
                  email,
                  role: "user",
                  granted_by: null,
                  banned_by: null,
                  ban_reason: null,
                  banned_until: null,
                  created_at: createdAt,
                  updated_at: updatedAt,
                  user_id: String(row.id || "").trim() || null,
                  display_name: getDisplayName(row.user_metadata || null),
                  membership_plan: toStringOrNull(row.user_metadata?.membership_plan),
                  stripe_customer_id: toStringOrNull(row.user_metadata?.stripe_customer_id),
                  stripe_subscription_id: toStringOrNull(row.user_metadata?.stripe_subscription_id)
                };
              }).filter((row) => Boolean(row));
              inferredRows.push(...indexInferredRows);
              if (hasSupabaseAdminConfig() && inferredRows.length > 0) {
                const adminClient2 = getSupabaseAdminClient();
                await adminClient2.from("org_user_roles").upsert(
                  inferredRows.map((row) => ({
                    email: row.email,
                    role: "user",
                    granted_by: row.granted_by
                  })),
                  { onConflict: "email", ignoreDuplicates: true }
                );
              }
              mergedRoles = [...roleRows, ...inferredRows];
              mergedRoles = await Promise.all(
                mergedRoles.map(async (row) => {
                  const email = String(row.email || "").trim().toLowerCase();
                  const authUser = authUsersByEmail.get(email);
                  const userMetadata = authUser?.user_metadata || null;
                  const effectivePermissions = await collectPermissionsForRole(row.role);
                  return {
                    ...row,
                    email,
                    user_id: row.user_id || String(authUser?.id || "").trim() || null,
                    display_name: row.display_name || getDisplayName(userMetadata),
                    membership_plan: row.membership_plan || toStringOrNull(userMetadata?.membership_plan) || "free",
                    stripe_customer_id: row.stripe_customer_id || toStringOrNull(userMetadata?.stripe_customer_id),
                    stripe_subscription_id: row.stripe_subscription_id || toStringOrNull(userMetadata?.stripe_subscription_id),
                    effective_permissions: effectivePermissions
                  };
                })
              );
              mergedRoles.sort((a, b) => a.email.localeCompare(b.email));
              return Response.json({
                requester: {
                  ...access.requester,
                  role: access.role,
                  permissions: access.permissions
                },
                roles: mergedRoles
              });
            } catch (error) {
              if (error instanceof Response) return error;
              return Response.json(
                { error: error instanceof Error ? error.message : "Unexpected server error" },
                { status: 500 }
              );
            }
          },
          POST: async ({ request }) => {
            try {
              const { requester, role } = await requirePermission(request, "manage_users");
              const admin = getAdminOrRequestClient(request);
              const body = await request.json();
              const parsed = setRoleSchema.safeParse(body);
              if (!parsed.success) {
                return Response.json({ error: "Invalid payload", details: parsed.error.flatten() }, { status: 400 });
              }
              const normalizedEmail = parsed.data.targetEmail.toLowerCase();
              const requestedRole = parsed.data.role;
              const { data: currentMember, error: currentMemberError } = await admin.from("org_user_roles").select("role").eq("email", normalizedEmail).maybeSingle();
              if (currentMemberError) {
                return Response.json({ error: currentMemberError.message }, { status: 500 });
              }
              if (currentMember?.role && !canManageRole(role, currentMember.role)) {
                return Response.json({ error: "You cannot change a member at your role level or above" }, { status: 403 });
              }
              if (!canManageRole(role, requestedRole)) {
                return Response.json({ error: "You cannot assign that role" }, { status: 403 });
              }
              if (requestedRole === "banned" && !parsed.data.banReason?.trim()) {
                return Response.json({ error: "Ban reason is required when banning a member" }, { status: 400 });
              }
              const { data, error } = await admin.rpc("set_org_member_role", {
                p_target_email: normalizedEmail,
                p_role: requestedRole,
                p_granted_by: requester.email,
                p_banned_by: requestedRole === "banned" ? requester.email : null,
                p_ban_reason: requestedRole === "banned" ? parsed.data.banReason?.trim() || null : null,
                p_banned_until: requestedRole === "banned" ? parsed.data.bannedUntil || null : null
              });
              if (error) {
                return Response.json({ error: error.message }, { status: 500 });
              }
              const updated = data?.[0] || null;
              const ban = updated?.role === "banned" ? await getBanRecord(normalizedEmail) : null;
              return Response.json({
                updated: updated ? {
                  ...updated,
                  ban
                } : null
              });
            } catch (error) {
              if (error instanceof Response) return error;
              return Response.json(
                { error: error instanceof Error ? error.message : "Unexpected server error" },
                { status: 500 }
              );
            }
          },
          PUT: async ({ request }) => {
            try {
              const access = await requirePermission(request, "manage_users");
              const admin = getAdminOrRequestClient(request);
              const body = await request.json();
              const parsed = setSubscriptionSchema.safeParse(body);
              if (!parsed.success) {
                return Response.json({ error: "Invalid payload", details: parsed.error.flatten() }, { status: 400 });
              }
              if (!hasSupabaseAdminConfig()) {
                return Response.json(
                  {
                    error: "Supabase admin configuration missing on server.",
                    details: getSupabaseAdminConfigIssues()
                  },
                  { status: 500 }
                );
              }
              const normalizedEmail = parsed.data.targetEmail.toLowerCase();
              const membershipPlan = parsed.data.membershipPlan.toLowerCase();
              const { data: currentMember, error: currentMemberError } = await admin.from("org_user_roles").select("role").eq("email", normalizedEmail).maybeSingle();
              if (currentMemberError) {
                return Response.json({ error: currentMemberError.message }, { status: 500 });
              }
              if (currentMember?.role && !canManageRole(access.role, currentMember.role)) {
                return Response.json({ error: "You cannot change a member at your role level or above" }, { status: 403 });
              }
              const { data: planRows, error: planError } = await admin.from("org_shop_membership_plans").select("slug, is_active");
              if (planError) {
                return Response.json({ error: planError.message }, { status: 500 });
              }
              const allowedPlans = Array.from(/* @__PURE__ */ new Set([
                "free",
                ...(planRows || []).filter((plan) => plan.is_active !== false).map((plan) => String(plan.slug || "").trim().toLowerCase()).filter(Boolean)
              ]));
              if (!allowedPlans.includes(membershipPlan)) {
                return Response.json({ error: "Invalid membership plan selected." }, { status: 400 });
              }
              const authUser = await findAuthUserByEmail(normalizedEmail);
              if (!authUser?.id) {
                return Response.json({ error: "Target auth user not found" }, { status: 404 });
              }
              const currentMeta = authUser.user_metadata ?? {};
              const nextMeta = {
                ...currentMeta,
                membership_plan: membershipPlan
              };
              if (membershipPlan === "free") {
                nextMeta.stripe_subscription_id = null;
              }
              const adminClient2 = getSupabaseAdminClient();
              const { error: updateError } = await adminClient2.auth.admin.updateUserById(authUser.id, {
                user_metadata: nextMeta
              });
              if (updateError) {
                return Response.json({ error: updateError.message }, { status: 500 });
              }
              return Response.json({
                updated: {
                  email: normalizedEmail,
                  membership_plan: membershipPlan,
                  stripe_subscription_id: membershipPlan === "free" ? null : nextMeta.stripe_subscription_id || null
                }
              });
            } catch (error) {
              if (error instanceof Response) return error;
              return Response.json(
                { error: error instanceof Error ? error.message : "Unexpected server error" },
                { status: 500 }
              );
            }
          }
        }
      }
    });
    updatePermissionSchema = z.object({
      role: z.enum(ORG_ROLES),
      permissionKey: z.string().min(1),
      enabled: z.boolean()
    });
    Route$2 = createFileRoute("/api/admin/permissions")({
      server: {
        handlers: {
          GET: async ({ request }) => {
            try {
              const access = await getRequesterAccess(request);
              if (!access.isSuperadmin && !access.permissions.includes("manage_permissions")) {
                return Response.json({ error: "Manage permissions permission required" }, { status: 403 });
              }
              const admin = getAdminOrPublicClient$2();
              const { data, error } = await admin.rpc("list_org_permission_matrix");
              if (error) {
                return Response.json({ error: error.message }, { status: 500 });
              }
              return Response.json({
                requester: {
                  ...access.requester,
                  role: access.role,
                  permissions: access.permissions
                },
                matrix: data || []
              });
            } catch (error) {
              if (error instanceof Response) return error;
              return Response.json(
                { error: error instanceof Error ? error.message : "Unexpected server error" },
                { status: 500 }
              );
            }
          },
          POST: async ({ request }) => {
            try {
              const access = await requirePermission(request, "manage_permissions");
              const admin = getAdminOrPublicClient$2();
              const body = await request.json();
              const parsed = updatePermissionSchema.safeParse(body);
              if (!parsed.success) {
                return Response.json({ error: "Invalid payload", details: parsed.error.flatten() }, { status: 400 });
              }
              const targetRole = parsed.data.role;
              if (!access.isSuperadmin && !canManageRole(access.role, targetRole)) {
                return Response.json({ error: "You cannot edit permissions for that role" }, { status: 403 });
              }
              const { data, error } = await admin.rpc("set_org_role_permission", {
                p_role: targetRole,
                p_permission_key: parsed.data.permissionKey,
                p_enabled: parsed.data.enabled,
                p_granted_by: access.requester.email
              });
              if (error) {
                return Response.json({ error: error.message }, { status: 500 });
              }
              return Response.json({ updated: data?.[0] || null });
            } catch (error) {
              if (error instanceof Response) return error;
              return Response.json(
                { error: error instanceof Error ? error.message : "Unexpected server error" },
                { status: 500 }
              );
            }
          }
        }
      }
    });
    planBaseSchema = z.object({
      slug: z.string().trim().min(1).max(80),
      name: z.string().trim().min(1).max(120),
      displayPrice: z.string().trim().min(1).max(40),
      priceCents: z.number().int().min(0),
      description: z.string().trim().min(1).max(600),
      features: z.array(z.string().trim().min(1).max(200)).max(20),
      sortOrder: z.number().int().min(0).default(0),
      isActive: z.boolean().default(true)
    });
    createPlanSchema = planBaseSchema;
    updatePlanSchema = planBaseSchema.extend({
      id: z.string().uuid()
    });
    deletePlanSchema = z.object({
      id: z.string().uuid()
    });
    Route$1 = createFileRoute("/api/admin/shop/plans")({
      server: {
        handlers: {
          GET: async ({ request }) => {
            try {
              const access = await requirePermission(request, "access_admin_dashboard");
              const admin = getAdminOrPublicClient$1();
              const { data, error } = await admin.from("org_shop_membership_plans").select("id, slug, name, display_price, price_cents, description, features, sort_order, is_active, created_at, updated_at").order("sort_order", { ascending: true }).order("created_at", { ascending: true });
              if (error) return Response.json({ error: error.message }, { status: 500 });
              return Response.json({
                requester: {
                  ...access.requester,
                  role: access.role
                },
                plans: data || []
              });
            } catch (error) {
              if (error instanceof Response) return error;
              return Response.json(
                { error: error instanceof Error ? error.message : "Unexpected server error" },
                { status: 500 }
              );
            }
          },
          POST: async ({ request }) => {
            try {
              await requirePermission(request, "access_admin_dashboard");
              const admin = getAdminOrPublicClient$1();
              const body = await request.json();
              const parsed = createPlanSchema.safeParse(body);
              if (!parsed.success) {
                return Response.json({ error: "Invalid payload", details: parsed.error.flatten() }, { status: 400 });
              }
              const { data, error } = await admin.from("org_shop_membership_plans").insert({
                slug: parsed.data.slug.toLowerCase(),
                name: parsed.data.name,
                display_price: parsed.data.displayPrice,
                price_cents: parsed.data.priceCents,
                description: parsed.data.description,
                features: parsed.data.features,
                sort_order: parsed.data.sortOrder,
                is_active: parsed.data.isActive
              }).select("id, slug, name, display_price, price_cents, description, features, sort_order, is_active, created_at, updated_at").single();
              if (error) return Response.json({ error: error.message }, { status: 500 });
              return Response.json({ plan: data });
            } catch (error) {
              if (error instanceof Response) return error;
              return Response.json(
                { error: error instanceof Error ? error.message : "Unexpected server error" },
                { status: 500 }
              );
            }
          },
          PUT: async ({ request }) => {
            try {
              await requirePermission(request, "access_admin_dashboard");
              const admin = getAdminOrPublicClient$1();
              const body = await request.json();
              const parsed = updatePlanSchema.safeParse(body);
              if (!parsed.success) {
                return Response.json({ error: "Invalid payload", details: parsed.error.flatten() }, { status: 400 });
              }
              const { data, error } = await admin.from("org_shop_membership_plans").update({
                slug: parsed.data.slug.toLowerCase(),
                name: parsed.data.name,
                display_price: parsed.data.displayPrice,
                price_cents: parsed.data.priceCents,
                description: parsed.data.description,
                features: parsed.data.features,
                sort_order: parsed.data.sortOrder,
                is_active: parsed.data.isActive,
                updated_at: (/* @__PURE__ */ new Date()).toISOString()
              }).eq("id", parsed.data.id).select("id, slug, name, display_price, price_cents, description, features, sort_order, is_active, created_at, updated_at").single();
              if (error) return Response.json({ error: error.message }, { status: 500 });
              return Response.json({ plan: data });
            } catch (error) {
              if (error instanceof Response) return error;
              return Response.json(
                { error: error instanceof Error ? error.message : "Unexpected server error" },
                { status: 500 }
              );
            }
          },
          DELETE: async ({ request }) => {
            try {
              await requirePermission(request, "access_admin_dashboard");
              const admin = getAdminOrPublicClient$1();
              const body = await request.json();
              const parsed = deletePlanSchema.safeParse(body);
              if (!parsed.success) {
                return Response.json({ error: "Invalid payload", details: parsed.error.flatten() }, { status: 400 });
              }
              const { error } = await admin.from("org_shop_membership_plans").delete().eq("id", parsed.data.id);
              if (error) return Response.json({ error: error.message }, { status: 500 });
              return Response.json({ deleted: true });
            } catch (error) {
              if (error instanceof Response) return error;
              return Response.json(
                { error: error instanceof Error ? error.message : "Unexpected server error" },
                { status: 500 }
              );
            }
          }
        }
      }
    });
    createMerchSchema = z.object({
      name: z.string().trim().min(1).max(120),
      price: z.string().trim().min(1).max(40),
      description: z.string().trim().min(1).max(600),
      sortOrder: z.number().int().min(0).default(0),
      isActive: z.boolean().default(true)
    });
    updateMerchSchema = createMerchSchema.extend({
      id: z.string().uuid()
    });
    deleteMerchSchema = z.object({
      id: z.string().uuid()
    });
    Route = createFileRoute("/api/admin/shop/merch")({
      server: {
        handlers: {
          GET: async ({ request }) => {
            try {
              const access = await requirePermission(request, "access_admin_dashboard");
              const admin = getAdminOrPublicClient();
              const { data, error } = await admin.from("org_shop_merch_items").select("id, name, price, description, sort_order, is_active, created_at, updated_at").order("sort_order", { ascending: true }).order("created_at", { ascending: true });
              if (error) return Response.json({ error: error.message }, { status: 500 });
              return Response.json({
                requester: {
                  ...access.requester,
                  role: access.role
                },
                items: data || []
              });
            } catch (error) {
              if (error instanceof Response) return error;
              return Response.json(
                { error: error instanceof Error ? error.message : "Unexpected server error" },
                { status: 500 }
              );
            }
          },
          POST: async ({ request }) => {
            try {
              await requirePermission(request, "access_admin_dashboard");
              const admin = getAdminOrPublicClient();
              const body = await request.json();
              const parsed = createMerchSchema.safeParse(body);
              if (!parsed.success) {
                return Response.json({ error: "Invalid payload", details: parsed.error.flatten() }, { status: 400 });
              }
              const { data, error } = await admin.from("org_shop_merch_items").insert({
                name: parsed.data.name,
                price: parsed.data.price,
                description: parsed.data.description,
                sort_order: parsed.data.sortOrder,
                is_active: parsed.data.isActive
              }).select("id, name, price, description, sort_order, is_active, created_at, updated_at").single();
              if (error) return Response.json({ error: error.message }, { status: 500 });
              return Response.json({ item: data });
            } catch (error) {
              if (error instanceof Response) return error;
              return Response.json(
                { error: error instanceof Error ? error.message : "Unexpected server error" },
                { status: 500 }
              );
            }
          },
          PUT: async ({ request }) => {
            try {
              await requirePermission(request, "access_admin_dashboard");
              const admin = getAdminOrPublicClient();
              const body = await request.json();
              const parsed = updateMerchSchema.safeParse(body);
              if (!parsed.success) {
                return Response.json({ error: "Invalid payload", details: parsed.error.flatten() }, { status: 400 });
              }
              const { data, error } = await admin.from("org_shop_merch_items").update({
                name: parsed.data.name,
                price: parsed.data.price,
                description: parsed.data.description,
                sort_order: parsed.data.sortOrder,
                is_active: parsed.data.isActive,
                updated_at: (/* @__PURE__ */ new Date()).toISOString()
              }).eq("id", parsed.data.id).select("id, name, price, description, sort_order, is_active, created_at, updated_at").single();
              if (error) return Response.json({ error: error.message }, { status: 500 });
              return Response.json({ item: data });
            } catch (error) {
              if (error instanceof Response) return error;
              return Response.json(
                { error: error instanceof Error ? error.message : "Unexpected server error" },
                { status: 500 }
              );
            }
          },
          DELETE: async ({ request }) => {
            try {
              await requirePermission(request, "access_admin_dashboard");
              const admin = getAdminOrPublicClient();
              const body = await request.json();
              const parsed = deleteMerchSchema.safeParse(body);
              if (!parsed.success) {
                return Response.json({ error: "Invalid payload", details: parsed.error.flatten() }, { status: 400 });
              }
              const { error } = await admin.from("org_shop_merch_items").delete().eq("id", parsed.data.id);
              if (error) return Response.json({ error: error.message }, { status: 500 });
              return Response.json({ deleted: true });
            } catch (error) {
              if (error instanceof Response) return error;
              return Response.json(
                { error: error instanceof Error ? error.message : "Unexpected server error" },
                { status: 500 }
              );
            }
          }
        }
      }
    });
    SignupRoute = Route$K.update({
      id: "/signup",
      path: "/signup",
      getParentRoute: () => Route$L
    });
    OnboardingRoute = Route$J.update({
      id: "/onboarding",
      path: "/onboarding",
      getParentRoute: () => Route$L
    });
    NewsRoute = Route$I.update({
      id: "/news",
      path: "/news",
      getParentRoute: () => Route$L
    });
    MerchStudioRoute = Route$H.update({
      id: "/merch-studio",
      path: "/merch-studio",
      getParentRoute: () => Route$L
    });
    MerchRoute = Route$G.update({
      id: "/merch",
      path: "/merch",
      getParentRoute: () => Route$L
    });
    LoginRoute = Route$F.update({
      id: "/login",
      path: "/login",
      getParentRoute: () => Route$L
    });
    LiveRoute = Route$E.update({
      id: "/live",
      path: "/live",
      getParentRoute: () => Route$L
    });
    FaqRoute = Route$D.update({
      id: "/faq",
      path: "/faq",
      getParentRoute: () => Route$L
    });
    DownloadRoute = Route$C.update({
      id: "/download",
      path: "/download",
      getParentRoute: () => Route$L
    });
    DirectoryRoute = Route$B.update({
      id: "/directory",
      path: "/directory",
      getParentRoute: () => Route$L
    });
    DashboardRoute = Route$A.update({
      id: "/dashboard",
      path: "/dashboard",
      getParentRoute: () => Route$L
    });
    AppealsRoute = Route$z.update({
      id: "/appeals",
      path: "/appeals",
      getParentRoute: () => Route$L
    });
    AdminRoute = Route$y.update({
      id: "/admin",
      path: "/admin",
      getParentRoute: () => Route$L
    });
    UsernameRoute = Route$x.update({
      id: "/$username",
      path: "/$username",
      getParentRoute: () => Route$L
    });
    IndexRoute = Route$w.update({
      id: "/",
      path: "/",
      getParentRoute: () => Route$L
    });
    ApiStripeWebhookRoute = Route$v.update({
      id: "/api/stripe-webhook",
      path: "/api/stripe-webhook",
      getParentRoute: () => Route$L
    });
    ApiShopRoute = Route$u.update({
      id: "/api/shop",
      path: "/api/shop",
      getParentRoute: () => Route$L
    });
    ApiPublicProfileRoute = Route$t.update({
      id: "/api/public-profile",
      path: "/api/public-profile",
      getParentRoute: () => Route$L
    });
    ApiPublicDirectoryRoute = Route$s.update({
      id: "/api/public-directory",
      path: "/api/public-directory",
      getParentRoute: () => Route$L
    });
    ApiProfilePhotoUploadRoute = Route$r.update({
      id: "/api/profile-photo-upload",
      path: "/api/profile-photo-upload",
      getParentRoute: () => Route$L
    });
    ApiProfileRoute = Route$q.update({
      id: "/api/profile",
      path: "/api/profile",
      getParentRoute: () => Route$L
    });
    ApiNewsUploadRoute = Route$p.update({
      id: "/api/news-upload",
      path: "/api/news-upload",
      getParentRoute: () => Route$L
    });
    ApiNewsRoute = Route$o.update({
      id: "/api/news",
      path: "/api/news",
      getParentRoute: () => Route$L
    });
    ApiMarketingProofRoute = Route$n.update({
      id: "/api/marketing-proof",
      path: "/api/marketing-proof",
      getParentRoute: () => Route$L
    });
    ApiKnowledgeVaultRoute = Route$m.update({
      id: "/api/knowledge-vault",
      path: "/api/knowledge-vault",
      getParentRoute: () => Route$L
    });
    ApiKickLoginRoute = Route$l.update({
      id: "/api/kick-login",
      path: "/api/kick-login",
      getParentRoute: () => Route$L
    });
    ApiKickCallbackRoute = Route$k.update({
      id: "/api/kick-callback",
      path: "/api/kick-callback",
      getParentRoute: () => Route$L
    });
    ApiCreatePaymentIntentRoute = Route$j.update({
      id: "/api/create-payment-intent",
      path: "/api/create-payment-intent",
      getParentRoute: () => Route$L
    });
    ApiCollabRoute = Route$i.update({
      id: "/api/collab",
      path: "/api/collab",
      getParentRoute: () => Route$L
    });
    ApiCheckUsernameRoute = Route$h.update({
      id: "/api/check-username",
      path: "/api/check-username",
      getParentRoute: () => Route$L
    });
    AdminUsersRoute = Route$g.update({
      id: "/users",
      path: "/users",
      getParentRoute: () => AdminRoute
    });
    AdminShopRoute = Route$f.update({
      id: "/shop",
      path: "/shop",
      getParentRoute: () => AdminRoute
    });
    DashboardToolsToolRoute = Route$e.update({
      id: "/tools/$tool",
      path: "/tools/$tool",
      getParentRoute: () => DashboardRoute
    });
    ApiToolsToolRoute = Route$d.update({
      id: "/api/tools/$tool",
      path: "/api/tools/$tool",
      getParentRoute: () => Route$L
    });
    ApiMerchStudioUploadRoute = Route$c.update({
      id: "/api/merch-studio/upload",
      path: "/api/merch-studio/upload",
      getParentRoute: () => Route$L
    });
    ApiMerchStudioSubmissionsRoute = Route$b.update({
      id: "/api/merch-studio/submissions",
      path: "/api/merch-studio/submissions",
      getParentRoute: () => Route$L
    });
    ApiMerchStudioEarningsRoute = Route$a.update({
      id: "/api/merch-studio/earnings",
      path: "/api/merch-studio/earnings",
      getParentRoute: () => Route$L
    });
    ApiMeProfileRoute = Route$9.update({
      id: "/api/me/profile",
      path: "/api/me/profile",
      getParentRoute: () => Route$L
    });
    ApiMeAccessRoute = Route$8.update({
      id: "/api/me/access",
      path: "/api/me/access",
      getParentRoute: () => Route$L
    });
    ApiLiveStreamsRoute = Route$7.update({
      id: "/api/live/streams",
      path: "/api/live/streams",
      getParentRoute: () => Route$L
    });
    ApiLiveClipsRoute = Route$6.update({
      id: "/api/live/clips",
      path: "/api/live/clips",
      getParentRoute: () => Route$L
    });
    ApiCollabApplyRoute = Route$5.update({
      id: "/apply",
      path: "/apply",
      getParentRoute: () => ApiCollabRoute
    });
    ApiCollabApplicantsRoute = Route$4.update({
      id: "/applicants",
      path: "/applicants",
      getParentRoute: () => ApiCollabRoute
    });
    ApiAdminRolesRoute = Route$3.update({
      id: "/api/admin/roles",
      path: "/api/admin/roles",
      getParentRoute: () => Route$L
    });
    ApiAdminPermissionsRoute = Route$2.update({
      id: "/api/admin/permissions",
      path: "/api/admin/permissions",
      getParentRoute: () => Route$L
    });
    ApiAdminShopPlansRoute = Route$1.update({
      id: "/api/admin/shop/plans",
      path: "/api/admin/shop/plans",
      getParentRoute: () => Route$L
    });
    ApiAdminShopMerchRoute = Route.update({
      id: "/api/admin/shop/merch",
      path: "/api/admin/shop/merch",
      getParentRoute: () => Route$L
    });
    AdminRouteChildren = {
      AdminShopRoute,
      AdminUsersRoute
    };
    AdminRouteWithChildren = AdminRoute._addFileChildren(AdminRouteChildren);
    DashboardRouteChildren = {
      DashboardToolsToolRoute
    };
    DashboardRouteWithChildren = DashboardRoute._addFileChildren(
      DashboardRouteChildren
    );
    ApiCollabRouteChildren = {
      ApiCollabApplicantsRoute,
      ApiCollabApplyRoute
    };
    ApiCollabRouteWithChildren = ApiCollabRoute._addFileChildren(
      ApiCollabRouteChildren
    );
    rootRouteChildren = {
      IndexRoute,
      UsernameRoute,
      AdminRoute: AdminRouteWithChildren,
      AppealsRoute,
      DashboardRoute: DashboardRouteWithChildren,
      DirectoryRoute,
      DownloadRoute,
      FaqRoute,
      LiveRoute,
      LoginRoute,
      MerchRoute,
      MerchStudioRoute,
      NewsRoute,
      OnboardingRoute,
      SignupRoute,
      ApiCheckUsernameRoute,
      ApiCollabRoute: ApiCollabRouteWithChildren,
      ApiCreatePaymentIntentRoute,
      ApiKickCallbackRoute,
      ApiKickLoginRoute,
      ApiKnowledgeVaultRoute,
      ApiMarketingProofRoute,
      ApiNewsRoute,
      ApiNewsUploadRoute,
      ApiProfileRoute,
      ApiProfilePhotoUploadRoute,
      ApiPublicDirectoryRoute,
      ApiPublicProfileRoute,
      ApiShopRoute,
      ApiStripeWebhookRoute,
      ApiAdminPermissionsRoute,
      ApiAdminRolesRoute,
      ApiLiveClipsRoute,
      ApiLiveStreamsRoute,
      ApiMeAccessRoute,
      ApiMeProfileRoute,
      ApiMerchStudioEarningsRoute,
      ApiMerchStudioSubmissionsRoute,
      ApiMerchStudioUploadRoute,
      ApiToolsToolRoute,
      ApiAdminShopMerchRoute,
      ApiAdminShopPlansRoute
    };
    routeTree = Route$L._addFileChildren(rootRouteChildren)._addFileTypes();
    getRouter = () => {
      const router2 = createRouter({
        routeTree,
        scrollRestoration: true,
        defaultPreloadStaleTime: 0
      });
      return router2;
    };
    router = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
      __proto__: null,
      getRouter
    }, Symbol.toStringTag, { value: "Module" }));
  }
});

// dist/server/assets/start-HYkvq4Ni.js
var start_HYkvq4Ni_exports = {};
__export(start_HYkvq4Ni_exports, {
  startInstance: () => startInstance
});
var startInstance;
var init_start_HYkvq4Ni = __esm({
  "dist/server/assets/start-HYkvq4Ni.js"() {
    "use strict";
    startInstance = void 0;
  }
});

// dist/server/assets/__23tanstack-start-plugin-adapters-Cwee5PKy.js
var tanstack_start_plugin_adapters_Cwee5PKy_exports = {};
__export(tanstack_start_plugin_adapters_Cwee5PKy_exports, {
  hasPluginAdapters: () => hasPluginAdapters,
  pluginSerializationAdapters: () => pluginSerializationAdapters
});
var pluginSerializationAdapters, hasPluginAdapters;
var init_tanstack_start_plugin_adapters_Cwee5PKy = __esm({
  "dist/server/assets/__23tanstack-start-plugin-adapters-Cwee5PKy.js"() {
    "use strict";
    pluginSerializationAdapters = [];
    hasPluginAdapters = false;
  }
});

// dist/server/server.js
import { AsyncLocalStorage } from "node:async_hooks";
import { H3Event, toResponse } from "h3-v2";
import { rootRouteId, defaultSerovalPlugins, makeSerovalPlugin, createRawStreamRPCPlugin, invariant, isNotFound, isRedirect, resolveManifestAssetLink, getStylesheetHref, createSerializationAdapter, isResolvedRedirect, executeRewriteInput } from "@tanstack/router-core";
import { toCrossJSONStream, fromJSON, toCrossJSONAsync } from "seroval";
import { createMemoryHistory } from "@tanstack/history";
import { mergeHeaders } from "@tanstack/router-core/ssr/client";
import { getNormalizedURL, getOrigin, attachRouterServerSsrUtils } from "@tanstack/router-core/ssr/server";
import "react";
import { RouterProvider } from "@tanstack/react-router";
import { jsx as jsx20 } from "react/jsx-runtime";
import { defineHandlerCallback, renderRouterToStream } from "@tanstack/react-router/ssr/server";
function StartServer(props) {
  return /* @__PURE__ */ jsx20(RouterProvider, { router: props.router });
}
var defaultStreamHandler = defineHandlerCallback(({ request, router: router2, responseHeaders }) => renderRouterToStream({
  request,
  router: router2,
  responseHeaders,
  children: /* @__PURE__ */ jsx20(StartServer, { router: router2 })
}));
var GLOBAL_EVENT_STORAGE_KEY = /* @__PURE__ */ Symbol.for("tanstack-start:event-storage");
var globalObj$1 = globalThis;
if (!globalObj$1[GLOBAL_EVENT_STORAGE_KEY]) globalObj$1[GLOBAL_EVENT_STORAGE_KEY] = new AsyncLocalStorage();
var eventStorage = globalObj$1[GLOBAL_EVENT_STORAGE_KEY];
function isPromiseLike(value) {
  return typeof value.then === "function";
}
function getSetCookieValues(headers) {
  const headersWithSetCookie = headers;
  if (typeof headersWithSetCookie.getSetCookie === "function") return headersWithSetCookie.getSetCookie();
  const value = headers.get("set-cookie");
  return value ? [value] : [];
}
function mergeEventResponseHeaders(response, event) {
  if (response.ok) return;
  const eventSetCookies = getSetCookieValues(event.res.headers);
  if (eventSetCookies.length === 0) return;
  const responseSetCookies = getSetCookieValues(response.headers);
  response.headers.delete("set-cookie");
  for (const cookie of responseSetCookies) response.headers.append("set-cookie", cookie);
  for (const cookie of eventSetCookies) response.headers.append("set-cookie", cookie);
}
function attachResponseHeaders(value, event) {
  if (isPromiseLike(value)) return value.then((resolved) => {
    if (resolved instanceof Response) mergeEventResponseHeaders(resolved, event);
    return resolved;
  });
  if (value instanceof Response) mergeEventResponseHeaders(value, event);
  return value;
}
function requestHandler(handler) {
  return (request, requestOpts) => {
    let h3Event;
    try {
      h3Event = new H3Event(request);
    } catch (error) {
      if (error instanceof URIError) return new Response(null, {
        status: 400,
        statusText: "Bad Request"
      });
      throw error;
    }
    return toResponse(attachResponseHeaders(eventStorage.run({ h3Event }, () => handler(request, requestOpts)), h3Event), h3Event);
  };
}
function getH3Event() {
  const event = eventStorage.getStore();
  if (!event) throw new Error(`No StartEvent found in AsyncLocalStorage. Make sure you are using the function within the server runtime.`);
  return event.h3Event;
}
function getResponse() {
  return getH3Event().res;
}
var HEADERS = { TSS_SHELL: "X-TSS_SHELL" };
async function getStartManifest(matchedRoutes) {
  const { tsrStartManifest: tsrStartManifest2 } = await Promise.resolve().then(() => (init_tanstack_start_manifest_v_CJtY7xJJ(), tanstack_start_manifest_v_CJtY7xJJ_exports));
  const startManifest = tsrStartManifest2();
  const rootRoute = startManifest.routes[rootRouteId] = startManifest.routes[rootRouteId] || {};
  rootRoute.assets = rootRoute.assets || [];
  let injectedHeadScripts;
  return {
    manifest: {
      inlineCss: startManifest.inlineCss,
      routes: Object.fromEntries(Object.entries(startManifest.routes).flatMap(([k, v]) => {
        const result = {};
        let hasData = false;
        if (v.preloads && v.preloads.length > 0) {
          result["preloads"] = v.preloads;
          hasData = true;
        }
        if (v.assets && v.assets.length > 0) {
          result["assets"] = v.assets;
          hasData = true;
        }
        if (!hasData) return [];
        return [[k, result]];
      }))
    },
    clientEntry: startManifest.clientEntry,
    injectedHeadScripts
  };
}
var manifest = {};
async function getServerFnById(id, access) {
  const serverFnInfo = manifest[id];
  if (!serverFnInfo) {
    throw new Error("Server function info not found for " + id);
  }
  const fnModule = serverFnInfo.module ?? await serverFnInfo.importer();
  if (!fnModule) {
    throw new Error("Server function module not resolved for " + id);
  }
  const action = fnModule[serverFnInfo.functionName];
  if (!action) {
    throw new Error("Server function module export not resolved for serverFn ID: " + id);
  }
  return action;
}
var TSS_FORMDATA_CONTEXT = "__TSS_CONTEXT";
var TSS_SERVER_FUNCTION = /* @__PURE__ */ Symbol.for("TSS_SERVER_FUNCTION");
var X_TSS_SERIALIZED = "x-tss-serialized";
var X_TSS_RAW_RESPONSE = "x-tss-raw";
var TSS_CONTENT_TYPE_FRAMED = "application/x-tss-framed";
var FrameType = {
  JSON: 0,
  CHUNK: 1,
  END: 2,
  ERROR: 3
};
var FRAME_HEADER_SIZE = 9;
var TSS_CONTENT_TYPE_FRAMED_VERSIONED = `${TSS_CONTENT_TYPE_FRAMED}; v=1`;
function isSafeKey(key) {
  return key !== "__proto__" && key !== "constructor" && key !== "prototype";
}
function safeObjectMerge(target, source) {
  const result = /* @__PURE__ */ Object.create(null);
  if (target) {
    for (const key of Object.keys(target)) if (isSafeKey(key)) result[key] = target[key];
  }
  if (source && typeof source === "object") {
    for (const key of Object.keys(source)) if (isSafeKey(key)) result[key] = source[key];
  }
  return result;
}
function createNullProtoObject(source) {
  if (!source) return /* @__PURE__ */ Object.create(null);
  const obj = /* @__PURE__ */ Object.create(null);
  for (const key of Object.keys(source)) if (isSafeKey(key)) obj[key] = source[key];
  return obj;
}
var GLOBAL_STORAGE_KEY = /* @__PURE__ */ Symbol.for("tanstack-start:start-storage-context");
var globalObj = globalThis;
if (!globalObj[GLOBAL_STORAGE_KEY]) globalObj[GLOBAL_STORAGE_KEY] = new AsyncLocalStorage();
var startStorage = globalObj[GLOBAL_STORAGE_KEY];
async function runWithStartContext(context, fn) {
  return startStorage.run(context, fn);
}
function getStartContext(opts) {
  const context = startStorage.getStore();
  if (!context && opts?.throwIfNotFound !== false) throw new Error(`No Start context found in AsyncLocalStorage. Make sure you are using the function within the server runtime.`);
  return context;
}
var getStartOptions = () => getStartContext().startOptions;
function flattenMiddlewares(middlewares, maxDepth = 100) {
  const seen = /* @__PURE__ */ new Set();
  const flattened = [];
  const recurse = (middleware, depth) => {
    if (depth > maxDepth) throw new Error(`Middleware nesting depth exceeded maximum of ${maxDepth}. Check for circular references.`);
    middleware.forEach((m) => {
      if (m.options.middleware) recurse(m.options.middleware, depth + 1);
      if (!seen.has(m)) {
        seen.add(m);
        flattened.push(m);
      }
    });
  };
  recurse(middlewares, 0);
  return flattened;
}
function getDefaultSerovalPlugins() {
  return [...getStartOptions()?.serializationAdapters?.map(makeSerovalPlugin) ?? [], ...defaultSerovalPlugins];
}
var textEncoder = new TextEncoder();
var EMPTY_PAYLOAD = new Uint8Array(0);
function encodeFrame(type, streamId, payload) {
  const frame = new Uint8Array(FRAME_HEADER_SIZE + payload.length);
  frame[0] = type;
  frame[1] = streamId >>> 24 & 255;
  frame[2] = streamId >>> 16 & 255;
  frame[3] = streamId >>> 8 & 255;
  frame[4] = streamId & 255;
  frame[5] = payload.length >>> 24 & 255;
  frame[6] = payload.length >>> 16 & 255;
  frame[7] = payload.length >>> 8 & 255;
  frame[8] = payload.length & 255;
  frame.set(payload, FRAME_HEADER_SIZE);
  return frame;
}
function encodeJSONFrame(json) {
  return encodeFrame(FrameType.JSON, 0, textEncoder.encode(json));
}
function encodeChunkFrame(streamId, chunk) {
  return encodeFrame(FrameType.CHUNK, streamId, chunk);
}
function encodeEndFrame(streamId) {
  return encodeFrame(FrameType.END, streamId, EMPTY_PAYLOAD);
}
function encodeErrorFrame(streamId, error) {
  const message = error instanceof Error ? error.message : String(error ?? "Unknown error");
  return encodeFrame(FrameType.ERROR, streamId, textEncoder.encode(message));
}
function createMultiplexedStream(jsonStream, rawStreams, lateStreamSource) {
  let controller;
  let cancelled = false;
  const readers = [];
  const enqueue = (frame) => {
    if (cancelled) return false;
    try {
      controller.enqueue(frame);
      return true;
    } catch {
      return false;
    }
  };
  const errorOutput = (error) => {
    if (cancelled) return;
    cancelled = true;
    try {
      controller.error(error);
    } catch {
    }
    for (const reader of readers) reader.cancel().catch(() => {
    });
  };
  async function pumpRawStream(streamId, stream) {
    const reader = stream.getReader();
    readers.push(reader);
    try {
      while (!cancelled) {
        const { done, value } = await reader.read();
        if (done) {
          enqueue(encodeEndFrame(streamId));
          return;
        }
        if (!enqueue(encodeChunkFrame(streamId, value))) return;
      }
    } catch (error) {
      enqueue(encodeErrorFrame(streamId, error));
    } finally {
      reader.releaseLock();
    }
  }
  async function pumpJSON() {
    const reader = jsonStream.getReader();
    readers.push(reader);
    try {
      while (!cancelled) {
        const { done, value } = await reader.read();
        if (done) return;
        if (!enqueue(encodeJSONFrame(value))) return;
      }
    } catch (error) {
      errorOutput(error);
      throw error;
    } finally {
      reader.releaseLock();
    }
  }
  async function pumpLateStreams() {
    if (!lateStreamSource) return [];
    const lateStreamPumps = [];
    const reader = lateStreamSource.getReader();
    readers.push(reader);
    try {
      while (!cancelled) {
        const { done, value } = await reader.read();
        if (done) break;
        lateStreamPumps.push(pumpRawStream(value.id, value.stream));
      }
    } finally {
      reader.releaseLock();
    }
    return lateStreamPumps;
  }
  return new ReadableStream({
    async start(ctrl) {
      controller = ctrl;
      const pumps = [pumpJSON()];
      for (const [streamId, stream] of rawStreams) pumps.push(pumpRawStream(streamId, stream));
      if (lateStreamSource) pumps.push(pumpLateStreams());
      try {
        const latePumps = (await Promise.all(pumps)).find(Array.isArray);
        if (latePumps && latePumps.length > 0) await Promise.all(latePumps);
        if (!cancelled) try {
          controller.close();
        } catch {
        }
      } catch {
      }
    },
    cancel() {
      cancelled = true;
      for (const reader of readers) reader.cancel().catch(() => {
      });
      readers.length = 0;
    }
  });
}
var serovalPlugins = void 0;
var FORM_DATA_CONTENT_TYPES = ["multipart/form-data", "application/x-www-form-urlencoded"];
var MAX_PAYLOAD_SIZE = 1e6;
var handleServerAction = async ({ request, context, serverFnId }) => {
  const methodUpper = request.method.toUpperCase();
  const url = new URL(request.url);
  const action = await getServerFnById(serverFnId);
  if (action.method && methodUpper !== action.method) return new Response(`expected ${action.method} method. Got ${methodUpper}`, {
    status: 405,
    headers: { Allow: action.method }
  });
  const isServerFn = request.headers.get("x-tsr-serverFn") === "true";
  if (!serovalPlugins) serovalPlugins = getDefaultSerovalPlugins();
  const contentType = request.headers.get("Content-Type");
  function parsePayload(payload) {
    return fromJSON(payload, { plugins: serovalPlugins });
  }
  return await (async () => {
    try {
      let serializeResult = function(res2) {
        let nonStreamingBody = void 0;
        const alsResponse = getResponse();
        if (res2 !== void 0) {
          const rawStreams = /* @__PURE__ */ new Map();
          let initialPhase = true;
          let lateStreamWriter;
          let lateStreamReadable = void 0;
          const pendingLateStreams = [];
          const plugins = [createRawStreamRPCPlugin((id, stream) => {
            if (initialPhase) {
              rawStreams.set(id, stream);
              return;
            }
            if (lateStreamWriter) {
              lateStreamWriter.write({
                id,
                stream
              }).catch(() => {
              });
              return;
            }
            pendingLateStreams.push({
              id,
              stream
            });
          }), ...serovalPlugins || []];
          let done = false;
          const callbacks = {
            onParse: (value) => {
              nonStreamingBody = value;
            },
            onDone: () => {
              done = true;
            },
            onError: (error) => {
              throw error;
            }
          };
          toCrossJSONStream(res2, {
            refs: /* @__PURE__ */ new Map(),
            plugins,
            onParse(value) {
              callbacks.onParse(value);
            },
            onDone() {
              callbacks.onDone();
            },
            onError: (error) => {
              callbacks.onError(error);
            }
          });
          initialPhase = false;
          if (done && rawStreams.size === 0) return new Response(nonStreamingBody ? JSON.stringify(nonStreamingBody) : void 0, {
            status: alsResponse.status,
            statusText: alsResponse.statusText,
            headers: {
              "Content-Type": "application/json",
              [X_TSS_SERIALIZED]: "true"
            }
          });
          const { readable, writable } = new TransformStream();
          lateStreamReadable = readable;
          lateStreamWriter = writable.getWriter();
          for (const registration of pendingLateStreams) lateStreamWriter.write(registration).catch(() => {
          });
          pendingLateStreams.length = 0;
          const multiplexedStream = createMultiplexedStream(new ReadableStream({
            start(controller) {
              callbacks.onParse = (value) => {
                controller.enqueue(JSON.stringify(value) + "\n");
              };
              callbacks.onDone = () => {
                try {
                  controller.close();
                } catch {
                }
                lateStreamWriter?.close().catch(() => {
                }).finally(() => {
                  lateStreamWriter = void 0;
                });
              };
              callbacks.onError = (error) => {
                controller.error(error);
                lateStreamWriter?.abort(error).catch(() => {
                }).finally(() => {
                  lateStreamWriter = void 0;
                });
              };
              if (nonStreamingBody !== void 0) callbacks.onParse(nonStreamingBody);
              if (done) callbacks.onDone();
            },
            cancel() {
              lateStreamWriter?.abort().catch(() => {
              });
              lateStreamWriter = void 0;
            }
          }), rawStreams, lateStreamReadable);
          return new Response(multiplexedStream, {
            status: alsResponse.status,
            statusText: alsResponse.statusText,
            headers: {
              "Content-Type": TSS_CONTENT_TYPE_FRAMED_VERSIONED,
              [X_TSS_SERIALIZED]: "true"
            }
          });
        }
        return new Response(void 0, {
          status: alsResponse.status,
          statusText: alsResponse.statusText
        });
      };
      let res = await (async () => {
        if (FORM_DATA_CONTENT_TYPES.some((type) => contentType && contentType.includes(type))) {
          if (methodUpper === "GET") {
            if (false) ;
            invariant();
          }
          const formData = await request.formData();
          const serializedContext = formData.get(TSS_FORMDATA_CONTEXT);
          formData.delete(TSS_FORMDATA_CONTEXT);
          const params = {
            context,
            data: formData,
            method: methodUpper
          };
          if (typeof serializedContext === "string") try {
            const deserializedContext = fromJSON(JSON.parse(serializedContext), { plugins: serovalPlugins });
            if (typeof deserializedContext === "object" && deserializedContext) params.context = safeObjectMerge(deserializedContext, context);
          } catch (e) {
            if (false) ;
          }
          return await action(params);
        }
        if (methodUpper === "GET") {
          const payloadParam = url.searchParams.get("payload");
          if (payloadParam && payloadParam.length > MAX_PAYLOAD_SIZE) throw new Error("Payload too large");
          const payload2 = payloadParam ? parsePayload(JSON.parse(payloadParam)) : {};
          payload2.context = safeObjectMerge(payload2.context, context);
          payload2.method = methodUpper;
          return await action(payload2);
        }
        let jsonPayload;
        if (contentType?.includes("application/json")) jsonPayload = await request.json();
        const payload = jsonPayload ? parsePayload(jsonPayload) : {};
        payload.context = safeObjectMerge(payload.context, context);
        payload.method = methodUpper;
        return await action(payload);
      })();
      const unwrapped = res.result || res.error;
      if (isNotFound(res)) res = isNotFoundResponse(res);
      if (!isServerFn) return unwrapped;
      if (unwrapped instanceof Response) {
        if (isRedirect(unwrapped)) return unwrapped;
        unwrapped.headers.set(X_TSS_RAW_RESPONSE, "true");
        return unwrapped;
      }
      return serializeResult(res);
    } catch (error) {
      if (error instanceof Response) return error;
      if (isNotFound(error)) return isNotFoundResponse(error);
      console.info();
      console.info("Server Fn Error!");
      console.info();
      console.error(error);
      console.info();
      const serializedError = JSON.stringify(await Promise.resolve(toCrossJSONAsync(error, {
        refs: /* @__PURE__ */ new Map(),
        plugins: serovalPlugins
      })));
      const response = getResponse();
      return new Response(serializedError, {
        status: response.status ?? 500,
        statusText: response.statusText,
        headers: {
          "Content-Type": "application/json",
          [X_TSS_SERIALIZED]: "true"
        }
      });
    }
  })();
};
function isNotFoundResponse(error) {
  const { headers, ...rest } = error;
  return new Response(JSON.stringify(rest), {
    status: 404,
    headers: {
      "Content-Type": "application/json",
      ...headers || {}
    }
  });
}
function normalizeTransformAssetResult(result) {
  if (typeof result === "string") return { href: result };
  return result;
}
function resolveTransformAssetsCrossOrigin(config2, kind) {
  if (!config2) return void 0;
  if (typeof config2 === "string") return config2;
  return config2[kind];
}
function isObjectShorthand(transform) {
  return "prefix" in transform;
}
function resolveTransformAssetsConfig(transform) {
  if (typeof transform === "string") {
    const prefix = transform;
    return {
      type: "transform",
      transformFn: ({ url }) => ({ href: `${prefix}${url}` }),
      cache: true
    };
  }
  if (typeof transform === "function") return {
    type: "transform",
    transformFn: transform,
    cache: true
  };
  if (isObjectShorthand(transform)) {
    const { prefix, crossOrigin } = transform;
    return {
      type: "transform",
      transformFn: ({ url, kind }) => {
        const href = `${prefix}${url}`;
        if (kind === "clientEntry") return { href };
        const co = resolveTransformAssetsCrossOrigin(crossOrigin, kind);
        return co ? {
          href,
          crossOrigin: co
        } : { href };
      },
      cache: true
    };
  }
  if ("createTransform" in transform && transform.createTransform) return {
    type: "createTransform",
    createTransform: transform.createTransform,
    cache: transform.cache !== false
  };
  return {
    type: "transform",
    transformFn: typeof transform.transform === "string" ? (({ url }) => ({ href: `${transform.transform}${url}` })) : transform.transform,
    cache: transform.cache !== false
  };
}
function adaptTransformAssetUrlsToTransformAssets(transformFn) {
  return async ({ url, kind }) => ({ href: await transformFn({
    url,
    type: kind
  }) });
}
function adaptTransformAssetUrlsConfigToTransformAssets(transform) {
  if (typeof transform === "string") return transform;
  if (typeof transform === "function") return adaptTransformAssetUrlsToTransformAssets(transform);
  if ("createTransform" in transform && transform.createTransform) return {
    createTransform: async (ctx) => adaptTransformAssetUrlsToTransformAssets(await transform.createTransform(ctx)),
    cache: transform.cache,
    warmup: transform.warmup
  };
  return {
    transform: typeof transform.transform === "string" ? transform.transform : adaptTransformAssetUrlsToTransformAssets(transform.transform),
    cache: transform.cache,
    warmup: transform.warmup
  };
}
function buildClientEntryScriptTag(clientEntry, injectedHeadScripts) {
  let script = `import(${JSON.stringify(clientEntry)})`;
  if (injectedHeadScripts) script = `${injectedHeadScripts};${script}`;
  return {
    tag: "script",
    attrs: {
      type: "module",
      async: true
    },
    children: script
  };
}
function assignManifestAssetLink(link, next) {
  if (typeof link === "string") return next.crossOrigin ? next : next.href;
  return next.crossOrigin ? next : { href: next.href };
}
async function transformManifestAssets(source, transformFn, _opts) {
  const manifest2 = structuredClone(source.manifest);
  for (const route of Object.values(manifest2.routes)) {
    if (route.preloads) route.preloads = await Promise.all(route.preloads.map(async (link) => {
      const result = normalizeTransformAssetResult(await transformFn({
        url: resolveManifestAssetLink(link).href,
        kind: "modulepreload"
      }));
      return assignManifestAssetLink(link, {
        href: result.href,
        crossOrigin: result.crossOrigin
      });
    }));
    if (route.assets && !source.manifest.inlineCss) {
      for (const asset of route.assets) if (asset.tag === "link" && asset.attrs?.href) {
        const rel = asset.attrs.rel;
        if (!(typeof rel === "string" ? rel.split(/\s+/) : []).includes("stylesheet")) continue;
        const result = normalizeTransformAssetResult(await transformFn({
          url: asset.attrs.href,
          kind: "stylesheet"
        }));
        asset.attrs.href = result.href;
        if (result.crossOrigin) asset.attrs.crossOrigin = result.crossOrigin;
        else delete asset.attrs.crossOrigin;
      }
    }
  }
  const transformedClientEntry = normalizeTransformAssetResult(await transformFn({
    url: source.clientEntry,
    kind: "clientEntry"
  }));
  const rootRoute = manifest2.routes[rootRouteId] = manifest2.routes[rootRouteId] || {};
  rootRoute.assets = rootRoute.assets || [];
  rootRoute.assets.push(buildClientEntryScriptTag(transformedClientEntry.href, source.injectedHeadScripts));
  return manifest2;
}
function buildManifestWithClientEntry(source) {
  const scriptTag = buildClientEntryScriptTag(source.clientEntry, source.injectedHeadScripts);
  const baseRootRoute = source.manifest.routes[rootRouteId];
  const routes = {
    ...source.manifest.routes,
    [rootRouteId]: {
      ...baseRootRoute,
      assets: [...baseRootRoute?.assets || [], scriptTag]
    }
  };
  return {
    inlineCss: source.manifest.inlineCss,
    routes
  };
}
var LINK_PARAM_TOKEN_RE = /^[!#$%&'*+\-.^_`|~0-9A-Za-z]+$/;
var PRELOAD_AS_VALUES = /* @__PURE__ */ new Set([
  "fetch",
  "font",
  "image",
  "script",
  "style",
  "track"
]);
function buildLinkParam(name, value) {
  if (value === void 0) return name;
  if (LINK_PARAM_TOKEN_RE.test(value)) return `${name}=${value}`;
  return `${name}=${JSON.stringify(value)}`;
}
function serializeEarlyHint(hint) {
  const parts = [`<${hint.href}>`, buildLinkParam("rel", hint.rel)];
  if (hint.as) parts.push(buildLinkParam("as", hint.as));
  if (hint.crossOrigin !== void 0) parts.push(buildLinkParam("crossorigin", hint.crossOrigin || void 0));
  if (hint.type) parts.push(buildLinkParam("type", hint.type));
  if (hint.integrity) parts.push(buildLinkParam("integrity", hint.integrity));
  if (hint.referrerPolicy) parts.push(buildLinkParam("referrerpolicy", hint.referrerPolicy));
  if (hint.fetchPriority) parts.push(buildLinkParam("fetchpriority", hint.fetchPriority));
  return parts.join("; ");
}
function getStringAttr(attrs, name, fallbackName) {
  const value = attrs?.[name] ?? (fallbackName ? attrs?.[fallbackName] : void 0);
  return typeof value === "string" ? value : void 0;
}
function getPreloadAs(attrs) {
  const as = getStringAttr(attrs, "as");
  return as && PRELOAD_AS_VALUES.has(as) ? as : void 0;
}
function addEarlyHintFetchAttrs(hint, attrs) {
  const crossOrigin = getStringAttr(attrs, "crossOrigin", "crossorigin");
  const type = getStringAttr(attrs, "type");
  const integrity = getStringAttr(attrs, "integrity");
  const referrerPolicy = getStringAttr(attrs, "referrerPolicy", "referrerpolicy");
  const fetchPriority = getStringAttr(attrs, "fetchPriority", "fetchpriority");
  if (crossOrigin !== void 0) hint.crossOrigin = crossOrigin;
  if (type) hint.type = type;
  if (integrity) hint.integrity = integrity;
  if (referrerPolicy) hint.referrerPolicy = referrerPolicy;
  if (fetchPriority) hint.fetchPriority = fetchPriority;
}
function linkAttrsToEarlyHint(attrs) {
  const href = getStringAttr(attrs, "href");
  const rel = getStringAttr(attrs, "rel");
  if (!href || !rel) return void 0;
  const relTokens = rel.split(/\s+/);
  let hintRel;
  let hintAs;
  if (relTokens.includes("modulepreload")) {
    hintRel = "modulepreload";
    hintAs = "script";
  } else if (relTokens.includes("stylesheet")) {
    hintRel = "preload";
    hintAs = "style";
  } else if (relTokens.includes("preload")) {
    hintAs = getPreloadAs(attrs);
    if (!hintAs) return void 0;
    hintRel = "preload";
  } else if (relTokens.includes("preconnect")) {
    hintRel = "preconnect";
    hintAs = void 0;
  } else if (relTokens.includes("dns-prefetch")) {
    hintRel = "dns-prefetch";
    hintAs = void 0;
  }
  if (!hintRel) return void 0;
  const hint = {
    href,
    rel: hintRel
  };
  if (hintAs) hint.as = hintAs;
  addEarlyHintFetchAttrs(hint, attrs);
  return hint;
}
function collectStaticHintsFromManifest(manifest2, matchedRoutes) {
  const hints = [];
  for (const route of matchedRoutes) {
    const routeManifest = manifest2.routes[route.id];
    if (!routeManifest) continue;
    for (const link of routeManifest.preloads ?? []) {
      const { href, crossOrigin } = resolveManifestAssetLink(link);
      const hint = {
        href,
        rel: "modulepreload",
        as: "script"
      };
      if (crossOrigin !== void 0) hint.crossOrigin = crossOrigin;
      hints.push(hint);
    }
    for (const asset of routeManifest.assets ?? []) {
      if (asset.tag !== "link") continue;
      const stylesheetHref = getStylesheetHref(asset);
      if (stylesheetHref) {
        if (manifest2.inlineCss?.styles[stylesheetHref] !== void 0) continue;
        const hint2 = {
          href: stylesheetHref,
          rel: "preload",
          as: "style"
        };
        addEarlyHintFetchAttrs(hint2, asset.attrs);
        hints.push(hint2);
        continue;
      }
      const hint = linkAttrsToEarlyHint(asset.attrs);
      if (hint) hints.push(hint);
    }
  }
  return hints;
}
function collectDynamicHintsFromMatches(matches) {
  const hints = [];
  for (const match of matches) {
    const links = match.links;
    if (!Array.isArray(links)) continue;
    for (const link of links) {
      const hint = linkAttrsToEarlyHint(link);
      if (hint) hints.push(hint);
    }
  }
  return hints;
}
function createEarlyHintsEvent(opts) {
  const nextHints = [];
  const nextLinks = [];
  for (const hint of opts.hints) {
    const link = serializeEarlyHint(hint);
    if (opts.sentLinks.has(link)) continue;
    opts.sentLinks.add(link);
    opts.sentHints.push(hint);
    nextHints.push(hint);
    nextLinks.push(link);
  }
  if (!nextHints.length && opts.phase !== "dynamic") return void 0;
  return {
    phase: opts.phase,
    hints: nextHints,
    links: nextLinks,
    allHints: opts.sentHints.slice(),
    allLinks: Array.from(opts.sentLinks)
  };
}
function createResponseLinkHeaderEntries(opts) {
  for (const hint of opts.hints) {
    const link = serializeEarlyHint(hint);
    if (opts.sentLinks.has(link)) continue;
    opts.sentLinks.add(link);
    opts.entries.push({
      phase: opts.phase,
      hint,
      link
    });
  }
}
function getResponseLinkHeaderEntries(opts) {
  if (!opts.filter) return opts.entries.map((entry) => entry.link);
  try {
    const links = [];
    for (const entry of opts.entries) if (opts.filter(entry)) links.push(entry.link);
    return links;
  } catch (err) {
    console.error("Error filtering response Link headers:", err);
    return [];
  }
}
var ServerFunctionSerializationAdapter = createSerializationAdapter({
  key: "$TSS/serverfn",
  test: (v) => {
    if (typeof v !== "function") return false;
    if (!(TSS_SERVER_FUNCTION in v)) return false;
    return !!v[TSS_SERVER_FUNCTION];
  },
  toSerializable: ({ serverFnMeta }) => ({ functionId: serverFnMeta.id }),
  fromSerializable: ({ functionId }) => {
    const fn = async (opts, signal) => {
      return (await (await getServerFnById(functionId))(opts ?? {}, signal)).result;
    };
    return fn;
  }
});
function getStartResponseHeaders(opts) {
  return mergeHeaders({ "Content-Type": "text/html; charset=utf-8" }, ...opts.router.stores.matches.get().map((match) => {
    return match.headers;
  }));
}
function notifyEarlyHints(phase, event, onEarlyHints) {
  try {
    const result = onEarlyHints(event);
    if (result) Promise.resolve(result).catch((err) => {
      console.error(`Error sending ${phase} early hints:`, err);
    });
  } catch (err) {
    console.error(`Error sending ${phase} early hints:`, err);
  }
}
function getResponseLinkHeaderFilter(responseLinkHeader) {
  if (typeof responseLinkHeader !== "object") return;
  return responseLinkHeader.filter;
}
function appendResponseLinkHeaders(opts) {
  if (!opts.filter) {
    for (const entry of opts.entries) opts.responseHeaders.append("Link", entry.link);
    return;
  }
  const links = getResponseLinkHeaderEntries(opts);
  for (const link of links) opts.responseHeaders.append("Link", link);
}
function collectResponseLinkHeaderEntries(opts) {
  for (let index = 0; index < opts.event.hints.length; index++) opts.entries.push({
    phase: opts.phase,
    hint: opts.event.hints[index],
    link: opts.event.links[index]
  });
}
function handleCollectedEarlyHints(opts) {
  const event = opts.onEarlyHints ? createEarlyHintsEvent({
    phase: opts.phase,
    hints: opts.hints,
    sentLinks: opts.sentLinks,
    sentHints: opts.sentHints
  }) : void 0;
  if (event) notifyEarlyHints(opts.phase, event, opts.onEarlyHints);
  if (!opts.responseLinkHeaderEntries) return;
  if (event) {
    collectResponseLinkHeaderEntries({
      phase: opts.phase,
      event,
      entries: opts.responseLinkHeaderEntries
    });
    return;
  }
  createResponseLinkHeaderEntries({
    phase: opts.phase,
    hints: opts.hints,
    sentLinks: opts.sentLinks,
    entries: opts.responseLinkHeaderEntries
  });
}
var entriesPromise;
var baseManifestPromise;
var cachedFinalManifestPromise;
async function loadEntries() {
  const [routerEntry, startEntry, pluginAdapters] = await Promise.all([
    Promise.resolve().then(() => (init_router_BDBFyAOM(), router_BDBFyAOM_exports)).then((n) => n.r),
    Promise.resolve().then(() => (init_start_HYkvq4Ni(), start_HYkvq4Ni_exports)),
    Promise.resolve().then(() => (init_tanstack_start_plugin_adapters_Cwee5PKy(), tanstack_start_plugin_adapters_Cwee5PKy_exports))
  ]);
  return {
    routerEntry,
    startEntry,
    pluginAdapters
  };
}
function getEntries() {
  if (!entriesPromise) entriesPromise = loadEntries();
  return entriesPromise;
}
function getBaseManifest(matchedRoutes) {
  if (!baseManifestPromise) baseManifestPromise = getStartManifest();
  return baseManifestPromise;
}
async function resolveManifest(matchedRoutes, transformFn, cache) {
  const base = await getBaseManifest();
  const computeFinalManifest = async () => {
    return transformFn ? await transformManifestAssets(base, transformFn) : buildManifestWithClientEntry(base);
  };
  if (!transformFn || cache) {
    if (!cachedFinalManifestPromise) cachedFinalManifestPromise = computeFinalManifest();
    return cachedFinalManifestPromise;
  }
  return computeFinalManifest();
}
var ROUTER_BASEPATH = "/";
var SERVER_FN_BASE = "/_serverFn/";
var IS_PRERENDERING = process.env.TSS_PRERENDERING === "true";
var IS_SHELL_ENV = process.env.TSS_SHELL === "true";
var ERR_NO_RESPONSE = "Internal Server Error";
var ERR_NO_DEFER = "Internal Server Error";
function throwRouteHandlerError() {
  throw new Error(ERR_NO_RESPONSE);
}
function throwIfMayNotDefer() {
  throw new Error(ERR_NO_DEFER);
}
function isSpecialResponse(value) {
  return value instanceof Response || isRedirect(value);
}
function handleCtxResult(result) {
  if (isSpecialResponse(result)) return { response: result };
  return result;
}
function executeMiddleware(middlewares, ctx) {
  let index = -1;
  const next = async (nextCtx) => {
    if (nextCtx) {
      if (nextCtx.context) ctx.context = safeObjectMerge(ctx.context, nextCtx.context);
      for (const key of Object.keys(nextCtx)) if (key !== "context") ctx[key] = nextCtx[key];
    }
    index++;
    const middleware = middlewares[index];
    if (!middleware) return ctx;
    let result;
    try {
      result = await middleware({
        ...ctx,
        next
      });
    } catch (err) {
      if (isSpecialResponse(err)) {
        ctx.response = err;
        return ctx;
      }
      throw err;
    }
    const normalized = handleCtxResult(result);
    if (normalized) {
      if (normalized.response !== void 0) ctx.response = normalized.response;
      if (normalized.context) ctx.context = safeObjectMerge(ctx.context, normalized.context);
    }
    return ctx;
  };
  return next();
}
function handlerToMiddleware(handler, mayDefer = false) {
  if (mayDefer) return handler;
  return async (ctx) => {
    const response = await handler({
      ...ctx,
      next: throwIfMayNotDefer
    });
    if (!response) throwRouteHandlerError();
    return response;
  };
}
function createStartHandler(cbOrOptions) {
  const cb = typeof cbOrOptions === "function" ? cbOrOptions : cbOrOptions.handler;
  const transformAssetsOption = typeof cbOrOptions === "function" ? void 0 : cbOrOptions.transformAssets;
  const transformAssetUrlsOption = typeof cbOrOptions === "function" ? void 0 : cbOrOptions.transformAssetUrls;
  const transformOption = transformAssetsOption !== void 0 ? resolveTransformAssetsConfig(transformAssetsOption) : transformAssetUrlsOption !== void 0 ? resolveTransformAssetsConfig(adaptTransformAssetUrlsConfigToTransformAssets(transformAssetUrlsOption)) : void 0;
  const warmupTransformManifest = !!transformAssetsOption && typeof transformAssetsOption === "object" && "warmup" in transformAssetsOption && transformAssetsOption.warmup === true || !!transformAssetUrlsOption && typeof transformAssetUrlsOption === "object" && transformAssetUrlsOption.warmup === true;
  const resolvedTransformConfig = transformOption;
  const cache = resolvedTransformConfig ? resolvedTransformConfig.cache : true;
  const shouldCacheCreateTransform = cache && true;
  let cachedCreateTransformPromise;
  const getTransformFn = async (opts) => {
    if (!resolvedTransformConfig) return void 0;
    if (resolvedTransformConfig.type === "createTransform") {
      if (shouldCacheCreateTransform) {
        if (!cachedCreateTransformPromise) cachedCreateTransformPromise = Promise.resolve(resolvedTransformConfig.createTransform(opts)).catch((error) => {
          cachedCreateTransformPromise = void 0;
          throw error;
        });
        return cachedCreateTransformPromise;
      }
      return resolvedTransformConfig.createTransform(opts);
    }
    return resolvedTransformConfig.transformFn;
  };
  if (warmupTransformManifest && cache && true && !cachedFinalManifestPromise) {
    const warmupPromise = (async () => {
      const base = await getBaseManifest();
      const transformFn = await getTransformFn({ warmup: true });
      return transformFn ? await transformManifestAssets(base, transformFn) : buildManifestWithClientEntry(base);
    })();
    cachedFinalManifestPromise = warmupPromise;
    warmupPromise.catch(() => {
      if (cachedFinalManifestPromise === warmupPromise) cachedFinalManifestPromise = void 0;
      cachedCreateTransformPromise = void 0;
    });
  }
  const startRequestResolver = async (request, requestOpts) => {
    let router2 = null;
    let cbWillCleanup = false;
    try {
      const { url, handledProtocolRelativeURL } = getNormalizedURL(request.url);
      const href = url.pathname + url.search + url.hash;
      const origin = getOrigin(request);
      if (handledProtocolRelativeURL) return Response.redirect(url, 308);
      const entries = await getEntries();
      const startOptions = await entries.startEntry.startInstance?.getOptions() || {};
      const { hasPluginAdapters: hasPluginAdapters2, pluginSerializationAdapters: pluginSerializationAdapters2 } = entries.pluginAdapters;
      const serializationAdapters = [
        ...startOptions.serializationAdapters || [],
        ...hasPluginAdapters2 ? pluginSerializationAdapters2 : [],
        ServerFunctionSerializationAdapter
      ];
      const requestStartOptions = {
        ...startOptions,
        serializationAdapters
      };
      const flattenedRequestMiddlewares = startOptions.requestMiddleware ? flattenMiddlewares(startOptions.requestMiddleware) : [];
      const executedRequestMiddlewares = new Set(flattenedRequestMiddlewares);
      const getRouter2 = async () => {
        if (router2) return router2;
        router2 = await entries.routerEntry.getRouter();
        let isShell = IS_SHELL_ENV;
        if (IS_PRERENDERING && !isShell) isShell = request.headers.get(HEADERS.TSS_SHELL) === "true";
        const history = createMemoryHistory({ initialEntries: [href] });
        router2.update({
          history,
          isShell,
          isPrerendering: IS_PRERENDERING,
          origin: router2.options.origin ?? origin,
          defaultSsr: requestStartOptions.defaultSsr,
          serializationAdapters: [...requestStartOptions.serializationAdapters, ...router2.options.serializationAdapters || []],
          basepath: ROUTER_BASEPATH
        });
        return router2;
      };
      if (SERVER_FN_BASE && url.pathname.startsWith(SERVER_FN_BASE)) {
        const serverFnId = url.pathname.slice(SERVER_FN_BASE.length).split("/")[0];
        if (!serverFnId) throw new Error("Invalid server action param for serverFnId");
        const serverFnHandler = async ({ context }) => {
          return runWithStartContext({
            getRouter: getRouter2,
            startOptions: requestStartOptions,
            contextAfterGlobalMiddlewares: context,
            request,
            executedRequestMiddlewares,
            handlerType: "serverFn"
          }, () => handleServerAction({
            request,
            context: requestOpts?.context,
            serverFnId
          }));
        };
        return handleRedirectResponse((await executeMiddleware([...flattenedRequestMiddlewares.map((d) => d.options.server), serverFnHandler], {
          request,
          pathname: url.pathname,
          context: createNullProtoObject(requestOpts?.context)
        })).response, request, getRouter2);
      }
      const executeRouter = async (serverContext, matchedRoutes) => {
        const acceptParts = (request.headers.get("Accept") || "*/*").split(",");
        if (!["*/*", "text/html"].some((mimeType) => acceptParts.some((part) => part.trim().startsWith(mimeType)))) return Response.json({ error: "Only HTML requests are supported here" }, { status: 500 });
        const manifest2 = await resolveManifest(matchedRoutes, await getTransformFn({
          warmup: false,
          request
        }), cache);
        const onEarlyHints = requestOpts?.onEarlyHints;
        const responseLinkHeader = requestOpts?.responseLinkHeader;
        const shouldCollectEarlyHints = !!onEarlyHints || !!responseLinkHeader;
        const sentEarlyHintLinks = shouldCollectEarlyHints ? /* @__PURE__ */ new Set() : void 0;
        const sentEarlyHints = onEarlyHints ? new Array() : void 0;
        const responseLinkHeaderEntries = shouldCollectEarlyHints && responseLinkHeader ? new Array() : void 0;
        const responseLinkHeaderFilter = shouldCollectEarlyHints ? getResponseLinkHeaderFilter(responseLinkHeader) : void 0;
        if (shouldCollectEarlyHints && sentEarlyHintLinks && matchedRoutes?.length) handleCollectedEarlyHints({
          phase: "static",
          hints: collectStaticHintsFromManifest(manifest2, matchedRoutes),
          sentLinks: sentEarlyHintLinks,
          sentHints: sentEarlyHints,
          onEarlyHints,
          responseLinkHeaderEntries
        });
        const routerInstance = await getRouter2();
        attachRouterServerSsrUtils({
          router: routerInstance,
          manifest: manifest2,
          getRequestAssets: () => getStartContext({ throwIfNotFound: false })?.requestAssets,
          includeUnmatchedRouteAssets: false
        });
        routerInstance.update({ additionalContext: { serverContext } });
        await routerInstance.load();
        if (routerInstance.state.redirect) return routerInstance.state.redirect;
        if (shouldCollectEarlyHints && sentEarlyHintLinks) handleCollectedEarlyHints({
          phase: "dynamic",
          hints: collectDynamicHintsFromMatches(routerInstance.stores.matches.get()),
          sentLinks: sentEarlyHintLinks,
          sentHints: sentEarlyHints,
          onEarlyHints,
          responseLinkHeaderEntries
        });
        const ctx = getStartContext({ throwIfNotFound: false });
        await routerInstance.serverSsr.dehydrate({ requestAssets: ctx?.requestAssets });
        const responseHeaders = getStartResponseHeaders({ router: routerInstance });
        if (responseLinkHeaderEntries?.length) appendResponseLinkHeaders({
          responseHeaders,
          entries: responseLinkHeaderEntries,
          filter: responseLinkHeaderFilter
        });
        cbWillCleanup = true;
        return cb({
          request,
          router: routerInstance,
          responseHeaders
        });
      };
      const requestHandlerMiddleware = async ({ context }) => {
        return runWithStartContext({
          getRouter: getRouter2,
          startOptions: requestStartOptions,
          contextAfterGlobalMiddlewares: context,
          request,
          executedRequestMiddlewares,
          handlerType: "router"
        }, async () => {
          try {
            return await handleServerRoutes({
              getRouter: getRouter2,
              request,
              url,
              executeRouter,
              context,
              executedRequestMiddlewares
            });
          } catch (err) {
            if (err instanceof Response) return err;
            throw err;
          }
        });
      };
      return handleRedirectResponse((await executeMiddleware([...flattenedRequestMiddlewares.map((d) => d.options.server), requestHandlerMiddleware], {
        request,
        pathname: url.pathname,
        context: createNullProtoObject(requestOpts?.context)
      })).response, request, getRouter2);
    } finally {
      if (router2 && !cbWillCleanup) router2.serverSsr?.cleanup();
      router2 = null;
    }
  };
  return requestHandler(startRequestResolver);
}
async function handleRedirectResponse(response, request, getRouter2) {
  if (!isRedirect(response)) return response;
  if (isResolvedRedirect(response)) {
    if (request.headers.get("x-tsr-serverFn") === "true") return Response.json({
      ...response.options,
      isSerializedRedirect: true
    }, { headers: response.headers });
    return response;
  }
  const opts = response.options;
  if (opts.to && typeof opts.to === "string" && !opts.to.startsWith("/")) throw new Error(`Server side redirects must use absolute paths via the 'href' or 'to' options. The redirect() method's "to" property accepts an internal path only. Use the "href" property to provide an external URL. Received: ${JSON.stringify(opts)}`);
  if ([
    "params",
    "search",
    "hash"
  ].some((d) => typeof opts[d] === "function")) throw new Error(`Server side redirects must use static search, params, and hash values and do not support functional values. Received functional values for: ${Object.keys(opts).filter((d) => typeof opts[d] === "function").map((d) => `"${d}"`).join(", ")}`);
  const redirect2 = (await getRouter2()).resolveRedirect(response);
  if (request.headers.get("x-tsr-serverFn") === "true") return Response.json({
    ...response.options,
    isSerializedRedirect: true
  }, { headers: response.headers });
  return redirect2;
}
async function handleServerRoutes({ getRouter: getRouter2, request, url, executeRouter, context, executedRequestMiddlewares }) {
  const router2 = await getRouter2();
  const pathname = executeRewriteInput(router2.rewrite, url).pathname;
  const { matchedRoutes, foundRoute, routeParams } = router2.getMatchedRoutes(pathname);
  const isExactMatch = foundRoute && routeParams["**"] === void 0;
  const routeMiddlewares = [];
  for (const route of matchedRoutes) {
    const serverMiddleware = route.options.server?.middleware;
    if (serverMiddleware) {
      const flattened = flattenMiddlewares(serverMiddleware);
      for (const m of flattened) if (!executedRequestMiddlewares.has(m)) routeMiddlewares.push(m.options.server);
    }
  }
  const server2 = foundRoute?.options.server;
  if (server2?.handlers && isExactMatch) {
    const handlers = typeof server2.handlers === "function" ? server2.handlers({ createHandlers: (d) => d }) : server2.handlers;
    const handler = handlers[request.method.toUpperCase()] ?? handlers["ANY"];
    if (handler) {
      const mayDefer = !!foundRoute.options.component;
      if (typeof handler === "function") routeMiddlewares.push(handlerToMiddleware(handler, mayDefer));
      else {
        if (handler.middleware?.length) {
          const handlerMiddlewares = flattenMiddlewares(handler.middleware);
          for (const m of handlerMiddlewares) routeMiddlewares.push(m.options.server);
        }
        if (handler.handler) routeMiddlewares.push(handlerToMiddleware(handler.handler, mayDefer));
      }
    }
  }
  routeMiddlewares.push((ctx) => executeRouter(ctx.context, matchedRoutes));
  return (await executeMiddleware(routeMiddlewares, {
    request,
    context,
    params: routeParams,
    pathname
  })).response;
}
var fetch2 = createStartHandler(defaultStreamHandler);
function createServerEntry(entry) {
  return {
    async fetch(...args) {
      return await entry.fetch(...args);
    }
  };
}
var server = createServerEntry({ fetch: fetch2 });

// .netlify/v1/functions/server.mjs
if (typeof server?.fetch !== "function") {
  console.error("The server entry point must have a default export with a property `fetch: (req: Request) => Promise<Response>`");
}
var server_default = server.fetch;
var config = {
  name: "@netlify/vite-plugin server handler",
  generator: "@netlify/vite-plugin@2.12.1",
  path: "/*",
  preferStatic: true
};
export {
  config,
  server_default as default
};
